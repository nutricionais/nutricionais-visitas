/* eslint-disable */
// =============================================================
// TELA 1 — Dashboard Geral
// =============================================================

function DashboardScreen() {
  return (
    <div style={{ display: 'flex', flexDirection: 'row', gap: 24, padding: 24, alignItems: 'flex-start' }}>
      {/* Coluna principal */}
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 20, minWidth: 0 }}>
        <KPIRow />
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20 }}>
          <ChartCard
            title="Visitas por nutricionista"
            subtitle="Top 10 — abril/2026"
          >
            <RankingBars />
          </ChartCard>
          <ChartCard
            title="Visitas por semana"
            subtitle="Últimas 12 semanas"
            right={<LegendDot color={DS.lime} label="Visitas aprovadas" />}
          >
            <AreaLineChart />
          </ChartCard>
          <ChartCard
            title="Distribuição por objetivo"
            subtitle="Tipo declarado em cada visita"
          >
            <DonutChart />
          </ChartCard>
          <ChartCard
            title="Dias × horários mais frequentes"
            subtitle="Heatmap · últimos 90 dias"
          >
            <Heatmap />
          </ChartCard>
        </div>
      </div>

      {/* Widget lateral */}
      <PendingActions />
    </div>
  );
}

// ---------- KPI Row ----------
function KPIRow() {
  return (
    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16 }}>
      <KPICard
        icon="location_on"
        label="Visitas este mês"
        value="247"
        deltaLabel="vs. mês anterior"
        delta="+18%"
        deltaSign="up"
      />
      <KPICard
        icon="rule"
        label="Em revisão"
        value="7"
        sublabel={<><span style={{ color: DS.danger, fontWeight: 700 }}>3 críticas</span> · 4 atenção</>}
        accent="danger"
        badge
      />
      <KPICard
        icon="groups"
        label="Nutricionistas ativos"
        value={<>12<span style={{ fontSize: 18, color: DS.n400, fontWeight: 500 }}> / 14</span></>}
        sublabel="2 de férias"
      />
      <KPICard
        icon="local_hospital"
        label="Instituições ativas"
        value="143"
        deltaLabel="este mês"
        delta="+2 novas"
        deltaSign="up"
      />
    </div>
  );
}

function KPICard({ icon, label, value, delta, deltaSign = 'up', deltaLabel, sublabel, accent = 'lime', badge = false }) {
  const deltaColor = deltaSign === 'up' ? DS.success : DS.danger;
  const circleBg = accent === 'danger' ? DS.danger : DS.lime;
  return (
    <div style={{
      background: '#fff', borderRadius: 12, padding: '18px 20px',
      boxShadow: '0 1px 3px rgba(10,31,92,0.04), 0 1px 2px rgba(10,31,92,0.04)',
      border: `1px solid ${DS.n200}`,
      display: 'flex', flexDirection: 'column', gap: 14, position: 'relative',
    }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div style={{
          width: 44, height: 44, borderRadius: '50%', background: circleBg,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          boxShadow: accent === 'danger' ? 'none' : `0 4px 10px ${DS.lime}33`,
        }}>
          <MI name={icon} size={22} color="#fff" weight={500} />
        </div>
        {badge && (
          <span style={{
            background: DS.danger50, color: DS.danger, fontSize: 10.5, fontWeight: 700,
            padding: '3px 8px', borderRadius: 9999, textTransform: 'uppercase', letterSpacing: '0.04em',
          }}>Crítico</span>
        )}
      </div>
      <div>
        <div style={{
          fontFamily: 'Poppins, sans-serif', fontSize: 32, fontWeight: 700,
          color: DS.navy, lineHeight: 1, fontVariantNumeric: 'tabular-nums',
          letterSpacing: '-0.02em',
        }}>{value}</div>
        <div style={{ fontSize: 12.5, fontWeight: 600, color: DS.n600, marginTop: 8 }}>{label}</div>
        {delta && (
          <div style={{ display: 'flex', alignItems: 'center', gap: 4, marginTop: 6, fontSize: 11.5 }}>
            <MI name={deltaSign === 'up' ? 'trending_up' : 'trending_down'} size={14} color={deltaColor} weight={600} />
            <span style={{ color: deltaColor, fontWeight: 700 }}>{delta}</span>
            <span style={{ color: DS.n500 }}>{deltaLabel}</span>
          </div>
        )}
        {sublabel && !delta && (
          <div style={{ marginTop: 6, fontSize: 11.5, color: DS.n500 }}>{sublabel}</div>
        )}
      </div>
    </div>
  );
}

// ---------- Chart frame ----------
function ChartCard({ title, subtitle, right, children }) {
  return (
    <div style={{
      background: '#fff', borderRadius: 12, padding: 20,
      boxShadow: '0 1px 3px rgba(10,31,92,0.04)',
      border: `1px solid ${DS.n200}`,
      display: 'flex', flexDirection: 'column',
    }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 16, gap: 12 }}>
        <div>
          <div style={{ fontFamily: 'Poppins, sans-serif', fontSize: 15, fontWeight: 600, color: DS.navy }}>{title}</div>
          {subtitle && <div style={{ fontSize: 11.5, color: DS.n500, marginTop: 2 }}>{subtitle}</div>}
        </div>
        {right}
      </div>
      {children}
    </div>
  );
}

function LegendDot({ color, label }) {
  return (
    <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6, fontSize: 11.5, color: DS.n600, fontWeight: 500 }}>
      <span style={{ width: 9, height: 9, borderRadius: 3, background: color }} />{label}
    </span>
  );
}

// ---------- Ranking (barras horizontais) ----------
function RankingBars() {
  const data = [
    { name: 'Maria Silva', count: 34, initials: 'MS' },
    { name: 'João Pereira', count: 31, initials: 'JP' },
    { name: 'Ana Costa', count: 28, initials: 'AC' },
    { name: 'Bruno Lima', count: 26, initials: 'BL' },
    { name: 'Carla Mendes', count: 22, initials: 'CM' },
    { name: 'Diego Alves', count: 21, initials: 'DA' },
    { name: 'Pedro Santos', count: 19, initials: 'PS' },
    { name: 'Eduarda Reis', count: 17, initials: 'ER' },
    { name: 'Fábio Rocha', count: 14, initials: 'FR' },
    { name: 'Giovana Luz', count: 12, initials: 'GL' },
  ];
  const max = Math.max(...data.map(d => d.count));
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
      {data.map((d, i) => (
        <div key={d.name} style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{ width: 14, fontSize: 11, fontFamily: 'JetBrains Mono', color: DS.n400, textAlign: 'right', fontWeight: 600 }}>{i + 1}</div>
          <div style={{
            width: 24, height: 24, borderRadius: '50%',
            background: i < 3 ? DS.navy : DS.navy100,
            color: i < 3 ? '#fff' : DS.navy,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: 10, fontWeight: 700, fontFamily: 'Poppins',
          }}>{d.initials}</div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontSize: 12, color: DS.n700, fontWeight: 500, marginBottom: 3, whiteSpace: 'nowrap' }}>{d.name}</div>
            <div style={{ height: 6, background: DS.n100, borderRadius: 3, overflow: 'hidden' }}>
              <div style={{
                width: `${(d.count / max) * 100}%`, height: '100%',
                background: DS.navy, borderRadius: 3,
              }} />
            </div>
          </div>
          <div style={{ fontFamily: 'JetBrains Mono', fontSize: 12, fontWeight: 600, color: DS.navy, width: 24, textAlign: 'right' }}>{d.count}</div>
        </div>
      ))}
    </div>
  );
}

// ---------- Area / line chart ----------
function AreaLineChart() {
  const data = [168, 175, 162, 188, 194, 182, 201, 215, 205, 228, 234, 247];
  const weeks = data.map((_, i) => `S${i + 1}`);
  const max = 260;
  const min = 140;
  const W = 420, H = 220, PL = 28, PR = 12, PT = 12, PB = 28;
  const innerW = W - PL - PR;
  const innerH = H - PT - PB;
  const xs = data.map((_, i) => PL + (i / (data.length - 1)) * innerW);
  const ys = data.map(v => PT + (1 - (v - min) / (max - min)) * innerH);
  const pathLine = xs.map((x, i) => `${i === 0 ? 'M' : 'L'} ${x} ${ys[i]}`).join(' ');
  const pathArea = `${pathLine} L ${xs[xs.length - 1]} ${PT + innerH} L ${xs[0]} ${PT + innerH} Z`;
  const gridY = [140, 180, 220, 260];
  return (
    <svg viewBox={`0 0 ${W} ${H}`} style={{ width: '100%', height: 220, overflow: 'visible' }}>
      <defs>
        <linearGradient id="lineFill" x1="0" x2="0" y1="0" y2="1">
          <stop offset="0%" stopColor={DS.lime} stopOpacity="0.35" />
          <stop offset="100%" stopColor={DS.lime} stopOpacity="0.02" />
        </linearGradient>
      </defs>
      {gridY.map(g => {
        const y = PT + (1 - (g - min) / (max - min)) * innerH;
        return (
          <g key={g}>
            <line x1={PL} x2={W - PR} y1={y} y2={y} stroke={DS.n100} strokeDasharray="3 3" />
            <text x={PL - 6} y={y + 4} fontSize="9" fill={DS.n400} textAnchor="end" fontFamily="JetBrains Mono">{g}</text>
          </g>
        );
      })}
      <path d={pathArea} fill="url(#lineFill)" />
      <path d={pathLine} fill="none" stroke={DS.lime} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
      {xs.map((x, i) => (
        <g key={i}>
          {i === data.length - 1 && (
            <>
              <circle cx={x} cy={ys[i]} r="10" fill={DS.lime} fillOpacity="0.15" />
              <circle cx={x} cy={ys[i]} r="4.5" fill="#fff" stroke={DS.lime} strokeWidth="2.5" />
              <g transform={`translate(${x - 36} ${ys[i] - 30})`}>
                <rect width="72" height="22" rx="6" fill={DS.navy} />
                <text x="36" y="14" fontSize="11" fontWeight="700" fill="#fff" textAnchor="middle" fontFamily="JetBrains Mono">{data[i]} visitas</text>
              </g>
            </>
          )}
          <text x={x} y={H - 8} fontSize="9" fill={DS.n400} textAnchor="middle" fontFamily="JetBrains Mono">{weeks[i]}</text>
        </g>
      ))}
    </svg>
  );
}

// ---------- Donut ----------
function DonutChart() {
  const slices = [
    { label: 'Padronização',      value: 28, color: '#0A1F5C' },
    { label: 'Dieta oncológica',   value: 18, color: '#1E3A8A' },
    { label: 'Nutrição infantil',  value: 14, color: '#0891B2' },
    { label: 'UTI adulto',         value: 12, color: '#14B8A6' },
    { label: 'Geriátrica',         value: 10, color: '#22C55E' },
    { label: 'Cardiológica',       value: 8,  color: '#8BC63F' },
    { label: 'Bariátrica',         value: 6,  color: '#BEF264' },
    { label: 'Outros',             value: 4,  color: '#D1D5DB' },
  ];
  const total = slices.reduce((s, v) => s + v.value, 0);
  const R = 58, r = 38, cx = 80, cy = 80;
  let acc = -Math.PI / 2;
  const paths = slices.map(s => {
    const ang = (s.value / total) * Math.PI * 2;
    const a0 = acc, a1 = acc + ang;
    acc = a1;
    const x0 = cx + R * Math.cos(a0), y0 = cy + R * Math.sin(a0);
    const x1 = cx + R * Math.cos(a1), y1 = cy + R * Math.sin(a1);
    const xi1 = cx + r * Math.cos(a1), yi1 = cy + r * Math.sin(a1);
    const xi0 = cx + r * Math.cos(a0), yi0 = cy + r * Math.sin(a0);
    const large = ang > Math.PI ? 1 : 0;
    const d = `M ${x0} ${y0} A ${R} ${R} 0 ${large} 1 ${x1} ${y1} L ${xi1} ${yi1} A ${r} ${r} 0 ${large} 0 ${xi0} ${yi0} Z`;
    return { d, color: s.color };
  });
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 20 }}>
      <svg width="160" height="160" viewBox="0 0 160 160" style={{ flexShrink: 0 }}>
        {paths.map((p, i) => <path key={i} d={p.d} fill={p.color} stroke="#fff" strokeWidth="1.5" />)}
        <text x="80" y="76" fontSize="10" fill={DS.n500} textAnchor="middle" fontFamily="Inter" fontWeight="600">TOTAL</text>
        <text x="80" y="94" fontSize="20" fill={DS.navy} textAnchor="middle" fontFamily="Poppins" fontWeight="700">247</text>
      </svg>
      <div style={{ flex: 1, display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '6px 12px', minWidth: 0 }}>
        {slices.map(s => (
          <div key={s.label} style={{ display: 'flex', alignItems: 'center', gap: 7, fontSize: 11.5, color: DS.n700, minWidth: 0 }}>
            <span style={{ width: 9, height: 9, borderRadius: 3, background: s.color, flexShrink: 0 }} />
            <span style={{ flex: 1, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{s.label}</span>
            <span style={{ fontFamily: 'JetBrains Mono', fontWeight: 600, color: DS.navy, fontSize: 11 }}>{s.value}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

// ---------- Heatmap ----------
function Heatmap() {
  const days = ['Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb', 'Dom'];
  const hours = Array.from({ length: 12 }, (_, i) => 8 + i); // 8..19
  // deterministic fake data: matrix[day][hour]
  const matrix = days.map((_, d) => hours.map((h, hi) => {
    if (d >= 5) return Math.max(0, Math.round(Math.sin(hi * 0.9 + d) * 2));
    // weekday: peak 9-11 and 14-16
    const peak1 = Math.exp(-Math.pow((h - 10), 2) / 4);
    const peak2 = Math.exp(-Math.pow((h - 15), 2) / 3);
    return Math.round((peak1 + peak2) * 9 + ((d + hi) % 3));
  }));
  const max = Math.max(...matrix.flat());
  const cellW = 28, cellH = 22, gap = 3;
  return (
    <div style={{ overflowX: 'hidden' }}>
      <div style={{ display: 'flex', flexDirection: 'column', gap }}>
        {/* Hour labels */}
        <div style={{ display: 'grid', gridTemplateColumns: `32px repeat(${hours.length}, ${cellW}px)`, gap, alignItems: 'center' }}>
          <div />
          {hours.map(h => (
            <div key={h} style={{ fontSize: 9, color: DS.n400, textAlign: 'center', fontFamily: 'JetBrains Mono' }}>{h}h</div>
          ))}
        </div>
        {days.map((dn, d) => (
          <div key={dn} style={{ display: 'grid', gridTemplateColumns: `32px repeat(${hours.length}, ${cellW}px)`, gap, alignItems: 'center' }}>
            <div style={{ fontSize: 10.5, color: DS.n500, fontWeight: 600, fontFamily: 'Inter' }}>{dn}</div>
            {hours.map((h, hi) => {
              const v = matrix[d][hi];
              const t = v / max;
              const bg = v === 0
                ? DS.n100
                : `rgba(139, 198, 63, ${0.15 + t * 0.85})`;
              return (
                <div key={h} title={`${dn} ${h}h · ${v} visitas`} style={{
                  height: cellH, borderRadius: 4, background: bg,
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontSize: 9, fontFamily: 'JetBrains Mono', fontWeight: 600,
                  color: t > 0.55 ? '#fff' : DS.n500,
                }}>
                  {v > 0 ? v : ''}
                </div>
              );
            })}
          </div>
        ))}
      </div>
      {/* Legend */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginTop: 10, fontSize: 10, color: DS.n500 }}>
        <span>Menos</span>
        {[0.1, 0.3, 0.5, 0.7, 0.95].map(t => (
          <span key={t} style={{ width: 14, height: 12, borderRadius: 3, background: t === 0.1 ? DS.n100 : `rgba(139, 198, 63, ${t})` }} />
        ))}
        <span>Mais</span>
      </div>
    </div>
  );
}

// ---------- Pending actions widget ----------
function PendingActions() {
  const items = [
    {
      tint: DS.warning, tintBg: DS.warning50, icon: 'rule',
      title: '7 visitas aguardando revisão',
      sub: '3 críticas · relatórios prontos',
      cta: 'Ver fila',
    },
    {
      tint: DS.orange, tintBg: DS.orange50, icon: 'medical_services',
      title: '3 profissões a padronizar',
      sub: 'Novas descrições em uso',
      cta: 'Revisar',
    },
    {
      tint: DS.info, tintBg: DS.info50, icon: 'person_add',
      title: '2 usuários aguardando aprovação',
      sub: 'Camila R. · Thiago B.',
      cta: 'Aprovar',
    },
    {
      tint: DS.n500, tintBg: DS.n100, icon: 'cloud_upload',
      title: 'Importação de faturamento',
      sub: 'Última: 05/Abr · 12 dias atrás',
      cta: 'Importar agora',
    },
  ];
  return (
    <aside style={{
      width: 300, background: '#fff', borderRadius: 12,
      border: `1px solid ${DS.n200}`,
      boxShadow: '0 1px 3px rgba(10,31,92,0.04)',
      padding: 18, position: 'sticky', top: 24, flexShrink: 0,
      display: 'flex', flexDirection: 'column', gap: 12,
    }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', paddingBottom: 12, borderBottom: `1px solid ${DS.n100}` }}>
        <div>
          <div style={{ fontFamily: 'Poppins, sans-serif', fontSize: 15, fontWeight: 600, color: DS.navy }}>Ações pendentes</div>
          <div style={{ fontSize: 11, color: DS.n500, marginTop: 2 }}>Requerem sua atenção</div>
        </div>
        <span style={{
          background: DS.navy, color: '#fff', fontFamily: 'Poppins',
          fontWeight: 700, fontSize: 13, width: 28, height: 28, borderRadius: 8,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>12</span>
      </div>

      {items.map((it, i) => (
        <div key={i} style={{
          background: it.tintBg, borderRadius: 10,
          padding: '12px 14px',
          display: 'flex', flexDirection: 'column', gap: 10,
          border: `1px solid ${it.tint}22`,
        }}>
          <div style={{ display: 'flex', alignItems: 'flex-start', gap: 10 }}>
            <div style={{
              width: 32, height: 32, borderRadius: 9, background: '#fff',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              flexShrink: 0, boxShadow: `0 0 0 1px ${it.tint}33`,
            }}>
              <MI name={it.icon} size={17} color={it.tint} weight={600} />
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontSize: 13, fontWeight: 600, color: DS.navy, lineHeight: 1.3 }}>{it.title}</div>
              <div style={{ fontSize: 11.5, color: DS.n600, marginTop: 2 }}>{it.sub}</div>
            </div>
          </div>
          <button style={{
            height: 30, borderRadius: 9999, border: 0,
            background: it.tint, color: '#fff', fontSize: 12, fontWeight: 600,
            fontFamily: 'Inter', cursor: 'pointer', display: 'inline-flex',
            alignItems: 'center', justifyContent: 'center', gap: 4,
            alignSelf: 'flex-start', padding: '0 14px',
          }}>
            {it.cta}
            <MI name="arrow_forward" size={14} weight={600} />
          </button>
        </div>
      ))}
    </aside>
  );
}

Object.assign(window, { DashboardScreen });
