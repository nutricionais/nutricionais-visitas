/* eslint-disable */
// =============================================================
// TELA 2 — Fila de revisão de visitas
// =============================================================

function ReviewQueueScreen() {
  const [flagFilters, setFlagFilters] = React.useState(new Set(['noCheckin', 'gps', 'time', 'manual']));
  const [nut, setNut] = React.useState('Todos');

  return (
    <div style={{ padding: 24, display: 'flex', flexDirection: 'column', gap: 20 }}>
      <ReviewFilters
        flagFilters={flagFilters}
        setFlagFilters={setFlagFilters}
        nut={nut}
        setNut={setNut}
      />

      <div style={{
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        fontSize: 12.5, color: DS.n600, padding: '0 4px',
      }}>
        <div>
          Exibindo <strong style={{ color: DS.navy }}>4 de 7</strong> visitas ·
          ordenadas por <strong style={{ color: DS.navy }}>severidade</strong>
          <span style={{ color: DS.n400 }}> ↓</span>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
          <button style={ghostBtn}><MI name="sort" size={15} />Ordenar</button>
          <button style={ghostBtn}><MI name="download" size={15} />Exportar</button>
          <button style={{ ...ghostBtn, background: DS.navy, color: '#fff', padding: '7px 14px', borderRadius: 9999 }}>
            <MI name="done_all" size={15} />Aprovar tudo sem flags críticas
          </button>
        </div>
      </div>

      {/* Cards */}
      <VisitCard1 />
      <VisitCard2 />
      <VisitCard3 />
      <VisitCard4 />
    </div>
  );
}

const ghostBtn = {
  display: 'inline-flex', alignItems: 'center', gap: 5,
  background: 'transparent', border: 0, color: DS.n600,
  fontSize: 12.5, fontWeight: 600, fontFamily: 'Inter', cursor: 'pointer',
  padding: '6px 8px',
};

// ---------- Filters bar ----------
function ReviewFilters({ flagFilters, setFlagFilters, nut, setNut }) {
  const toggleFlag = (k) => {
    const s = new Set(flagFilters);
    if (s.has(k)) s.delete(k); else s.add(k);
    setFlagFilters(s);
  };
  const chips = [
    { k: 'noCheckin', color: DS.danger,  bg: DS.danger50,  label: 'Sem check-in',    n: 1 },
    { k: 'gps',       color: DS.warning, bg: DS.warning50, label: 'GPS divergente',  n: 2 },
    { k: 'time',      color: DS.orange,  bg: DS.orange50,  label: 'Fora da margem',  n: 2 },
    { k: 'manual',    color: DS.info,    bg: DS.info50,    label: 'Check-in manual', n: 2 },
  ];
  return (
    <div style={{
      background: '#fff', borderRadius: 12, padding: '14px 18px',
      border: `1px solid ${DS.n200}`,
      boxShadow: '0 1px 3px rgba(10,31,92,0.04)',
      display: 'flex', alignItems: 'center', gap: 16, flexWrap: 'wrap',
    }}>
      {/* Nutri select */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
        <div style={{ fontSize: 10.5, fontWeight: 600, color: DS.n500, textTransform: 'uppercase', letterSpacing: '0.05em' }}>Nutricionista</div>
        <button style={{
          height: 36, padding: '0 12px 0 14px', borderRadius: 10,
          border: `1px solid ${DS.n200}`, background: '#fff',
          display: 'flex', alignItems: 'center', gap: 8, fontSize: 13,
          fontFamily: 'Inter', fontWeight: 500, color: DS.navy, cursor: 'pointer', minWidth: 200,
        }}>
          <MI name="person" size={16} color={DS.n500} />
          <span style={{ flex: 1, textAlign: 'left' }}>{nut}</span>
          <MI name="expand_more" size={18} color={DS.n500} />
        </button>
      </div>

      <div style={{ width: 1, height: 42, background: DS.n200 }} />

      {/* Flag chips */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
        <div style={{ fontSize: 10.5, fontWeight: 600, color: DS.n500, textTransform: 'uppercase', letterSpacing: '0.05em' }}>Tipo de flag</div>
        <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
          {chips.map(c => {
            const on = flagFilters.has(c.k);
            return (
              <button key={c.k} onClick={() => toggleFlag(c.k)} style={{
                height: 36, padding: '0 12px', borderRadius: 9999,
                border: `1px solid ${on ? c.color + '55' : DS.n200}`,
                background: on ? c.bg : '#fff',
                color: on ? c.color : DS.n500,
                display: 'inline-flex', alignItems: 'center', gap: 6,
                fontSize: 12, fontWeight: 600, fontFamily: 'Inter', cursor: 'pointer',
                transition: 'all 120ms',
              }}>
                <span style={{ width: 8, height: 8, borderRadius: '50%', background: c.color }} />
                {c.label}
                <span style={{
                  fontFamily: 'JetBrains Mono', fontSize: 10.5,
                  background: on ? '#fff' : DS.n100,
                  padding: '1px 6px', borderRadius: 9999, marginLeft: 2,
                }}>{c.n}</span>
                {on && <MI name="close" size={14} color={c.color} />}
              </button>
            );
          })}
        </div>
      </div>

      <div style={{ width: 1, height: 42, background: DS.n200 }} />

      {/* Date range */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
        <div style={{ fontSize: 10.5, fontWeight: 600, color: DS.n500, textTransform: 'uppercase', letterSpacing: '0.05em' }}>Período</div>
        <button style={{
          height: 36, padding: '0 12px', borderRadius: 10,
          border: `1px solid ${DS.n200}`, background: '#fff',
          display: 'flex', alignItems: 'center', gap: 8, fontSize: 13,
          fontFamily: 'Inter', fontWeight: 500, color: DS.navy, cursor: 'pointer',
        }}>
          <MI name="calendar_today" size={15} color={DS.n500} />
          <span>14 abr — 20 abr</span>
          <MI name="expand_more" size={18} color={DS.n500} />
        </button>
      </div>

      <div style={{ flex: 1 }} />

      <button style={{
        background: 'transparent', border: 0, color: DS.n500,
        fontSize: 12.5, fontWeight: 600, fontFamily: 'Inter',
        cursor: 'pointer', textDecoration: 'underline', textUnderlineOffset: 3,
      }}>Limpar filtros</button>
    </div>
  );
}

// ---------- Flag pill ----------
function FlagPill({ kind }) {
  const map = {
    noCheckin: { color: DS.danger,  bg: DS.danger50,  icon: 'location_off',        label: 'Sem check-in' },
    gps:       { color: DS.warning, bg: DS.warning50, icon: 'gps_not_fixed',       label: 'GPS divergente' },
    time:      { color: DS.orange,  bg: DS.orange50,  icon: 'schedule',            label: 'Fora da margem' },
    manual:    { color: DS.info,    bg: DS.info50,    icon: 'edit_location_alt',   label: 'Check-in manual' },
  };
  const f = map[kind];
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: 6,
      height: 26, padding: '0 10px', borderRadius: 9999,
      background: f.bg, color: f.color,
      fontSize: 11.5, fontWeight: 600, fontFamily: 'Inter',
      border: `1px solid ${f.color}22`,
    }}>
      <MI name={f.icon} size={13} weight={600} />
      {f.label}
    </span>
  );
}

// ---------- Base visit card ----------
function VisitCardShell({ severity = 'normal', children }) {
  const severityStyle = {
    critical: { borderLeft: `4px solid ${DS.danger}` },
    warning:  { borderLeft: `4px solid ${DS.warning}` },
    attention:{ borderLeft: `4px solid ${DS.orange}` },
    info:     { borderLeft: `4px solid ${DS.info}` },
    normal:   { borderLeft: `4px solid transparent` },
  }[severity];
  return (
    <div style={{
      background: '#fff', borderRadius: 12,
      border: `1px solid ${DS.n200}`,
      boxShadow: '0 1px 3px rgba(10,31,92,0.04)',
      padding: 20,
      ...severityStyle,
      display: 'flex', flexDirection: 'column', gap: 14,
    }}>
      {children}
    </div>
  );
}

function VisitHeader({ initials, name, hospital, dateTime, visitId, severityTag }) {
  return (
    <div style={{ display: 'flex', alignItems: 'flex-start', gap: 14 }}>
      <div style={{
        width: 44, height: 44, borderRadius: '50%',
        background: DS.navy100, color: DS.navy,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        fontFamily: 'Poppins', fontWeight: 700, fontSize: 14, flexShrink: 0,
      }}>{initials}</div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, flexWrap: 'wrap' }}>
          <div style={{ fontFamily: 'Poppins', fontWeight: 600, fontSize: 16, color: DS.navy }}>{name}</div>
          <span style={{ color: DS.n300, fontSize: 14 }}>·</span>
          <div style={{ fontSize: 14, color: DS.n700, fontWeight: 500 }}>{hospital}</div>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginTop: 4 }}>
          <div style={{ display: 'inline-flex', alignItems: 'center', gap: 5, fontSize: 12, color: DS.n500 }}>
            <MI name="event" size={14} color={DS.n400} />
            <span style={{ fontFamily: 'JetBrains Mono', fontSize: 12 }}>{dateTime}</span>
          </div>
          <div style={{ display: 'inline-flex', alignItems: 'center', gap: 4, fontSize: 11.5, color: DS.n400, fontFamily: 'JetBrains Mono' }}>
            {visitId}
          </div>
        </div>
      </div>
      {severityTag}
    </div>
  );
}

function VisitActions({ primaryLabel = 'Aprovar mesmo assim', primaryColor = DS.lime }) {
  return (
    <div style={{ display: 'flex', gap: 8, alignItems: 'center', paddingTop: 14, borderTop: `1px solid ${DS.n100}` }}>
      <button style={actionBtn('ghost')}>
        <MI name="visibility" size={16} />Ver detalhes
      </button>
      <div style={{ flex: 1 }} />
      <button style={actionBtn('secondary')}>
        <MI name="pause" size={16} />Manter em revisão
      </button>
      <button style={{ ...actionBtn('primary'), background: primaryColor }}>
        <MI name="check" size={16} />{primaryLabel}
      </button>
    </div>
  );
}

function actionBtn(kind) {
  const base = {
    height: 38, padding: '0 16px', borderRadius: 9999,
    fontSize: 13, fontWeight: 600, fontFamily: 'Inter',
    display: 'inline-flex', alignItems: 'center', gap: 6, cursor: 'pointer',
  };
  if (kind === 'primary') return { ...base, background: DS.lime, color: '#fff', border: 0 };
  if (kind === 'secondary') return { ...base, background: DS.navy, color: '#fff', border: 0 };
  if (kind === 'ghost') return { ...base, background: 'transparent', color: DS.n600, border: `1px solid ${DS.n200}` };
  return base;
}

// ---------- CARD 1 — Critical ----------
function VisitCard1() {
  return (
    <VisitCardShell severity="critical">
      <VisitHeader
        initials="MS" name="Maria Silva"
        hospital="Hospital Sírio Libanês"
        dateTime="Qui, 17 abr · 14:00"
        visitId="#VST-8421"
        severityTag={
          <span style={{
            background: DS.danger50, color: DS.danger, border: `1px solid ${DS.danger}33`,
            padding: '4px 10px', borderRadius: 9999, fontSize: 11, fontWeight: 700,
            textTransform: 'uppercase', letterSpacing: '0.05em',
          }}>3 flags · crítico</span>
        }
      />

      <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
        <FlagPill kind="noCheckin" />
        <FlagPill kind="gps" />
        <FlagPill kind="time" />
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 320px', gap: 16 }}>
        {/* Summary preview */}
        <div style={{
          background: DS.navy50, borderRadius: 10, padding: 14,
          border: `1px solid ${DS.n200}`,
        }}>
          <div style={{
            fontSize: 10.5, fontWeight: 700, color: DS.n500,
            textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: 6,
          }}>Resumo da visita</div>
          <div style={{ fontSize: 13, color: DS.n700, lineHeight: 1.55 }}>
            "Visita de padronização com a Dra. Helena. Discutimos os novos protocolos de
            dieta hiperproteica pós-operatória do setor de cardiologia. Equipe receptiva,
            pediu amostras da linha enteral pediátrica…"
          </div>
          <button style={{
            marginTop: 8, background: 'transparent', border: 0,
            color: DS.navy, fontSize: 12, fontWeight: 600, cursor: 'pointer',
            display: 'inline-flex', alignItems: 'center', gap: 4, padding: 0,
          }}>
            Ler completo <MI name="arrow_forward" size={14} />
          </button>
        </div>

        {/* Mini map */}
        <MiniMap distance="1.2 km" critical />
      </div>

      <VisitActions />
    </VisitCardShell>
  );
}

// ---------- CARD 2 — GPS warning ----------
function VisitCard2() {
  return (
    <VisitCardShell severity="warning">
      <VisitHeader
        initials="JP" name="João Pereira"
        hospital="Hospital Albert Einstein"
        dateTime="Qua, 16 abr · 10:30"
        visitId="#VST-8420"
        severityTag={
          <span style={{
            background: DS.warning50, color: '#B45309', border: `1px solid ${DS.warning}44`,
            padding: '4px 10px', borderRadius: 9999, fontSize: 11, fontWeight: 700,
            textTransform: 'uppercase', letterSpacing: '0.05em',
          }}>1 flag · atenção</span>
        }
      />

      <div style={{ display: 'flex', gap: 6 }}>
        <FlagPill kind="gps" />
        <span style={{ fontSize: 11.5, color: DS.n500, display: 'inline-flex', alignItems: 'center', gap: 4 }}>
          <MI name="straighten" size={13} color={DS.n400} />
          Distância do ponto de check-in:
          <strong style={{ color: DS.warning, fontFamily: 'JetBrains Mono' }}>780 m</strong>
        </span>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 320px', gap: 16, alignItems: 'stretch' }}>
        <div style={{
          background: DS.n50, borderRadius: 10, padding: 14,
          border: `1px solid ${DS.n200}`, display: 'flex', flexDirection: 'column', gap: 10,
        }}>
          <div>
            <div style={{ fontSize: 10.5, fontWeight: 700, color: DS.n500, textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: 6 }}>
              Possíveis causas
            </div>
            <div style={{ fontSize: 12.5, color: DS.n700, lineHeight: 1.5 }}>
              Check-in feito no estacionamento leste (torre 2). Instituição cadastrada aponta para torre principal.
            </div>
          </div>
          <div style={{ display: 'flex', gap: 16, paddingTop: 10, borderTop: `1px solid ${DS.n200}` }}>
            <MiniStat label="Check-in" value="10:32" />
            <MiniStat label="Check-out" value="11:48" />
            <MiniStat label="Duração" value="1h 16min" />
          </div>
        </div>

        <MiniMap distance="780 m" warning />
      </div>

      <VisitActions />
    </VisitCardShell>
  );
}

function MiniStat({ label, value }) {
  return (
    <div>
      <div style={{ fontSize: 10, color: DS.n500, textTransform: 'uppercase', fontWeight: 700, letterSpacing: '0.05em' }}>{label}</div>
      <div style={{ fontFamily: 'JetBrains Mono', fontSize: 13, fontWeight: 600, color: DS.navy, marginTop: 2 }}>{value}</div>
    </div>
  );
}

// ---------- CARD 3 — Time out of range ----------
function VisitCard3() {
  return (
    <VisitCardShell severity="attention">
      <VisitHeader
        initials="AC" name="Ana Costa"
        hospital="Hospital São Luiz"
        dateTime="Ter, 15 abr"
        visitId="#VST-8419"
        severityTag={
          <span style={{
            background: DS.orange50, color: DS.orange, border: `1px solid ${DS.orange}44`,
            padding: '4px 10px', borderRadius: 9999, fontSize: 11, fontWeight: 700,
            textTransform: 'uppercase', letterSpacing: '0.05em',
          }}>1 flag · atenção</span>
        }
      />

      <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
        <FlagPill kind="time" />
        <span style={{ fontSize: 11.5, color: DS.n500 }}>
          Visita declarada <strong style={{ color: DS.orange, fontFamily: 'JetBrains Mono' }}>2h 15min</strong> após o check-out
        </span>
        <span style={{ flex: 1 }} />
        <span style={{ display: 'inline-flex', alignItems: 'center', gap: 4, fontSize: 11.5, color: DS.success }}>
          <MI name="gps_fixed" size={13} color={DS.success} />
          GPS OK
        </span>
      </div>

      <div style={{
        background: DS.n50, borderRadius: 10, padding: '16px 18px',
        border: `1px solid ${DS.n200}`,
      }}>
        <div style={{ fontSize: 10.5, fontWeight: 700, color: DS.n500, textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: 14 }}>
          Timeline — 15 abr
        </div>
        <Timeline events={[
          { time: '09:00', label: 'Check-in', icon: 'login', color: DS.success, kind: 'ok' },
          { time: '10:15', label: 'Check-out', icon: 'logout', color: DS.success, kind: 'ok' },
          { time: '14:30', label: 'Visita declarada — início', icon: 'edit_note', color: DS.orange, kind: 'flag' },
          { time: '16:00', label: 'Visita declarada — fim', icon: 'check_circle', color: DS.orange, kind: 'flag' },
        ]} />
      </div>

      <VisitActions />
    </VisitCardShell>
  );
}

function Timeline({ events }) {
  return (
    <div style={{ position: 'relative', display: 'flex', justifyContent: 'space-between', padding: '0 4px' }}>
      {/* Line */}
      <div style={{ position: 'absolute', top: 16, left: 16, right: 16, height: 2, background: DS.n200 }} />
      <div style={{ position: 'absolute', top: 16, left: 16, width: '40%', height: 2, background: DS.success }} />
      <div style={{ position: 'absolute', top: 16, left: '40%', right: '20%', height: 2, background: DS.n200, backgroundImage: `repeating-linear-gradient(to right, ${DS.orange} 0 4px, transparent 4px 8px)` }} />

      {events.map((e, i) => (
        <div key={i} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6, position: 'relative', zIndex: 1 }}>
          <div style={{
            width: 32, height: 32, borderRadius: '50%', background: '#fff',
            border: `2px solid ${e.color}`,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            boxShadow: e.kind === 'flag' ? `0 0 0 3px ${e.color}22` : 'none',
          }}>
            <MI name={e.icon} size={16} color={e.color} weight={600} />
          </div>
          <div style={{ fontFamily: 'JetBrains Mono', fontSize: 12, fontWeight: 700, color: DS.navy }}>{e.time}</div>
          <div style={{ fontSize: 11, color: e.kind === 'flag' ? DS.orange : DS.n600, fontWeight: 500, textAlign: 'center', maxWidth: 140 }}>{e.label}</div>
        </div>
      ))}
    </div>
  );
}

// ---------- CARD 4 — Manual check-in ----------
function VisitCard4() {
  return (
    <VisitCardShell severity="info">
      <VisitHeader
        initials="PS" name="Pedro Santos"
        hospital="Hospital Oswaldo Cruz"
        dateTime="Seg, 14 abr"
        visitId="#VST-8418"
        severityTag={
          <span style={{
            background: DS.info50, color: DS.info, border: `1px solid ${DS.info}33`,
            padding: '4px 10px', borderRadius: 9999, fontSize: 11, fontWeight: 700,
            textTransform: 'uppercase', letterSpacing: '0.05em',
          }}>Revisão manual</span>
        }
      />

      <div style={{ display: 'flex', gap: 6, alignItems: 'center', flexWrap: 'wrap' }}>
        <FlagPill kind="manual" />
      </div>

      <div style={{
        background: DS.info50, borderRadius: 10, padding: '12px 14px',
        border: `1px solid ${DS.info}22`,
        display: 'flex', alignItems: 'flex-start', gap: 12,
      }}>
        <MI name="format_quote" size={22} color={DS.info} weight={600} />
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: 10.5, fontWeight: 700, color: DS.info, textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: 4 }}>
            Justificativa do nutricionista
          </div>
          <div style={{ fontSize: 13, color: DS.n700, lineHeight: 1.5, fontStyle: 'italic' }}>
            "GPS indisponível no subsolo do hospital. Visita realizada presencialmente
            na nutrição clínica — Dra. Patrícia confirmou presença via e-mail."
          </div>
          <div style={{ display: 'flex', gap: 14, marginTop: 10, paddingTop: 10, borderTop: `1px solid ${DS.info}22`, fontSize: 11.5, color: DS.n600 }}>
            <span style={{ display: 'inline-flex', alignItems: 'center', gap: 4 }}>
              <MI name="attach_email" size={14} color={DS.info} />
              <strong style={{ color: DS.navy, fontWeight: 600 }}>confirmacao-visita.pdf</strong>
            </span>
            <span style={{ display: 'inline-flex', alignItems: 'center', gap: 4 }}>
              <MI name="business" size={14} color={DS.n400} />
              Dra. Patrícia Mendes · Coord. Nutrição Clínica
            </span>
          </div>
        </div>
      </div>

      <VisitActions />
    </VisitCardShell>
  );
}

// ---------- Mini map ----------
function MiniMap({ distance, critical, warning }) {
  const lineColor = critical ? DS.danger : DS.warning;
  // Card 1: far pins; Card 2: closer pins
  const [p1x, p1y, p2x, p2y] = critical ? [60, 90, 230, 50] : [110, 100, 210, 70];
  return (
    <div style={{
      position: 'relative', borderRadius: 10, overflow: 'hidden',
      border: `1px solid ${DS.n200}`, height: 180,
      background: '#EAEEF2',
    }}>
      {/* Fake map */}
      <svg viewBox="0 0 320 180" width="100%" height="100%" preserveAspectRatio="xMidYMid slice">
        <defs>
          <pattern id="mapGrid" width="40" height="40" patternUnits="userSpaceOnUse">
            <path d="M 40 0 L 0 0 0 40" fill="none" stroke="#D7DCE2" strokeWidth="0.5" />
          </pattern>
        </defs>
        <rect width="320" height="180" fill="#E8EDF2" />
        <rect width="320" height="180" fill="url(#mapGrid)" />
        {/* Roads */}
        <path d="M -10 70 Q 100 50 200 80 T 340 90" stroke="#fff" strokeWidth="10" fill="none" />
        <path d="M -10 70 Q 100 50 200 80 T 340 90" stroke="#D7DCE2" strokeWidth="1" fill="none" />
        <path d="M 40 -10 L 90 200" stroke="#fff" strokeWidth="6" fill="none" />
        <path d="M 260 -10 L 210 200" stroke="#fff" strokeWidth="6" fill="none" />
        <path d="M -10 140 L 340 130" stroke="#fff" strokeWidth="6" fill="none" />
        {/* Green park */}
        <ellipse cx="260" cy="140" rx="50" ry="30" fill="#D4E9C7" opacity="0.8" />
        <ellipse cx="40" cy="40" rx="35" ry="20" fill="#D4E9C7" opacity="0.6" />

        {/* Dashed line between pins */}
        <line x1={p1x} y1={p1y} x2={p2x} y2={p2y} stroke={lineColor} strokeWidth="2" strokeDasharray="5 4" />
        {/* Distance label */}
        <g transform={`translate(${(p1x + p2x) / 2 - 28} ${(p1y + p2y) / 2 - 12})`}>
          <rect width="56" height="20" rx="10" fill="#fff" stroke={lineColor} strokeWidth="1" />
          <text x="28" y="13" fontSize="11" fontWeight="700" fill={lineColor} textAnchor="middle" fontFamily="JetBrains Mono">{distance}</text>
        </g>

        {/* Check-in pin (blue/danger) */}
        <g transform={`translate(${p1x} ${p1y})`}>
          <circle r="16" fill={DS.info} fillOpacity="0.18" />
          <circle r="9" fill={DS.info} stroke="#fff" strokeWidth="2.5" />
          <circle r="3" fill="#fff" />
        </g>
        {/* Institution pin (green) */}
        <g transform={`translate(${p2x} ${p2y})`}>
          <path d="M 0 -18 C -8 -18 -14 -12 -14 -5 C -14 3 0 14 0 14 C 0 14 14 3 14 -5 C 14 -12 8 -18 0 -18 Z" fill={DS.success} stroke="#fff" strokeWidth="2" />
          <circle r="4" cy="-5" fill="#fff" />
        </g>
      </svg>

      {/* Legend */}
      <div style={{
        position: 'absolute', top: 8, left: 8, background: 'rgba(255,255,255,0.95)',
        borderRadius: 6, padding: '5px 8px', fontSize: 10, color: DS.n700,
        display: 'flex', flexDirection: 'column', gap: 3, fontWeight: 500,
      }}>
        <span style={{ display: 'inline-flex', alignItems: 'center', gap: 5 }}>
          <span style={{ width: 7, height: 7, borderRadius: '50%', background: DS.info }} />Check-in
        </span>
        <span style={{ display: 'inline-flex', alignItems: 'center', gap: 5 }}>
          <span style={{ width: 7, height: 7, borderRadius: '50%', background: DS.success }} />Instituição
        </span>
      </div>

      <div style={{
        position: 'absolute', bottom: 8, right: 8,
        background: '#fff', borderRadius: 6,
        padding: '4px 6px', fontSize: 10, color: DS.n500, fontFamily: 'Inter',
        boxShadow: '0 1px 3px rgba(0,0,0,0.15)',
      }}>
        <MI name="open_in_new" size={11} style={{ verticalAlign: '-2px', marginRight: 2 }} />
        Abrir no mapa
      </div>
    </div>
  );
}

Object.assign(window, { ReviewQueueScreen });
