/* eslint-disable */
// Shell = Sidebar + Topbar shared by both screens
const DS = {
  navy: '#0A1F5C', navy800: '#0E2872', navy100: '#E3E7F1', navy50: '#F3F5FA',
  lime: '#8BC63F', limeH: '#7AB033', lime50: '#F4F9EA', lime100: '#E7F3D4',
  success: '#22A06B', success50: '#E6F6EF',
  warning: '#F59E0B', warning50: '#FEF4E1',
  danger: '#DC2626', danger50: '#FCE8E8',
  info: '#2563EB', info50: '#E4ECFD',
  orange: '#EA580C', orange50: '#FFF1E6',
  n0: '#FFFFFF', n50: '#FAFBFC', n100: '#F3F4F6', n200: '#E5E7EB',
  n300: '#D1D5DB', n400: '#9CA3AF', n500: '#6B7280', n600: '#4B5563',
  n700: '#374151', n800: '#1F2937', n900: '#111827',
};

function MI({ name, size = 20, color, weight = 500, fill = 0, style = {} }) {
  return (
    <span className="material-symbols-rounded" style={{
      fontSize: size, color: color || 'currentColor',
      fontVariationSettings: `'wght' ${weight}, 'FILL' ${fill}`,
      lineHeight: 1, display: 'inline-flex', userSelect: 'none', ...style,
    }}>{name}</span>
  );
}

function Sidebar({ active }) {
  const items = [
    { id: 'dashboard', icon: 'dashboard', label: 'Dashboard' },
    { id: 'review', icon: 'rule', label: 'Revisão', badge: { n: 7, color: DS.danger } },
    { id: 'team', icon: 'groups', label: 'Equipe' },
    { id: 'institutions', icon: 'local_hospital', label: 'Instituições' },
    { id: 'professions', icon: 'stethoscope', label: 'Profissionais', badge: { n: 3, color: DS.warning } },
    { id: 'visits', icon: 'location_on', label: 'Todas as visitas' },
    { id: 'agenda', icon: 'calendar_month', label: 'Agenda global' },
    { id: 'billing', icon: 'receipt_long', label: 'Faturamento' },
    { id: 'settings', icon: 'settings', label: 'Configurações', badge: { n: 2, color: DS.info } },
  ];
  return (
    <aside style={{
      width: 240, background: DS.navy, color: '#fff',
      display: 'flex', flexDirection: 'column', fontFamily: 'Inter, sans-serif',
      flexShrink: 0, minHeight: '100%',
    }}>
      {/* Logo */}
      <div style={{ padding: '22px 20px 16px', display: 'flex', alignItems: 'center', gap: 10 }}>
        <img src="ds/logo-white.png" alt="Nutricionais" style={{ height: 30, width: 'auto' }} />
      </div>
      <div style={{ height: 1, background: 'rgba(255,255,255,0.08)', margin: '0 16px 10px' }} />

      {/* Menu */}
      <nav style={{ display: 'flex', flexDirection: 'column', padding: '4px 8px', gap: 1 }}>
        {items.map(it => <SideItem key={it.id} item={it} active={active === it.id} />)}
      </nav>

      <div style={{ flex: 1 }} />

      {/* Footer user */}
      <div style={{ padding: '14px 14px 18px', borderTop: '1px solid rgba(255,255,255,0.08)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '6px 4px' }}>
          <div style={{
            width: 36, height: 36, borderRadius: '50%',
            background: `linear-gradient(135deg, ${DS.lime}, ${DS.limeH})`,
            color: DS.navy, display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontFamily: 'Poppins', fontWeight: 700, fontSize: 13,
          }}>AD</div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontSize: 13, fontWeight: 600, color: '#fff', lineHeight: 1.2, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>Admin Master</div>
            <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.5)', marginTop: 2 }}>admin@nutricionais.com.br</div>
          </div>
          <button style={{
            width: 28, height: 28, borderRadius: 8, background: 'transparent',
            border: 0, color: 'rgba(255,255,255,0.5)', cursor: 'pointer',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }} title="Sair">
            <MI name="logout" size={18} />
          </button>
        </div>
      </div>
    </aside>
  );
}

function SideItem({ item, active }) {
  const [hover, setHover] = React.useState(false);
  return (
    <button
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      style={{
        display: 'flex', alignItems: 'center', gap: 12,
        padding: '9px 12px', margin: 0,
        background: active ? 'rgba(139,198,63,0.14)' : hover ? 'rgba(255,255,255,0.06)' : 'transparent',
        color: active ? '#fff' : 'rgba(255,255,255,0.78)',
        border: 0, borderRadius: 8, cursor: 'pointer',
        fontSize: 13.5, fontWeight: active ? 600 : 500,
        textAlign: 'left', fontFamily: 'inherit',
        borderLeft: active ? `3px solid ${DS.lime}` : '3px solid transparent',
        paddingLeft: active ? 12 : 15, transition: 'background 120ms',
      }}>
      <MI name={item.icon} size={19} color={active ? DS.lime : undefined} weight={active ? 600 : 500} />
      <span style={{ flex: 1 }}>{item.label}</span>
      {item.badge && (
        <span style={{
          background: item.badge.color, color: '#fff', fontSize: 10.5,
          fontWeight: 700, padding: '2px 7px', borderRadius: 9999,
          minWidth: 20, textAlign: 'center', fontFamily: 'Inter',
          lineHeight: 1.3,
        }}>{item.badge.n}</span>
      )}
    </button>
  );
}

function Topbar({ title, breadcrumb, titleExtra }) {
  return (
    <header style={{
      height: 64, background: '#fff', borderBottom: `1px solid ${DS.n200}`,
      display: 'flex', alignItems: 'center', padding: '0 28px', gap: 16,
      flexShrink: 0,
    }}>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ display: 'flex', alignItems: 'baseline', gap: 10 }}>
          <div style={{ fontFamily: 'Poppins, sans-serif', fontSize: 20, fontWeight: 700, color: DS.navy, letterSpacing: '-0.01em' }}>{title}</div>
          {titleExtra}
        </div>
        {breadcrumb && (
          <div style={{ fontSize: 12, color: DS.n500, marginTop: 1, display: 'flex', alignItems: 'center', gap: 5 }}>
            {breadcrumb.map((b, i) => (
              <React.Fragment key={i}>
                <span style={{ color: i === breadcrumb.length - 1 ? DS.n600 : DS.n400 }}>{b}</span>
                {i < breadcrumb.length - 1 && <MI name="chevron_right" size={13} color={DS.n300} />}
              </React.Fragment>
            ))}
          </div>
        )}
      </div>

      {/* Search */}
      <div style={{
        height: 38, borderRadius: 9999, background: DS.n100, padding: '0 16px 0 14px',
        display: 'flex', alignItems: 'center', gap: 8, width: 340,
        border: `1px solid transparent`,
      }}>
        <MI name="search" size={17} color={DS.n500} />
        <input
          placeholder="Buscar hospital, nutricionista, visita…"
          style={{ flex: 1, background: 'transparent', border: 0, outline: 0, fontSize: 13, fontFamily: 'Inter', color: DS.navy }} />
        <kbd style={{
          fontFamily: 'Inter', fontSize: 10, fontWeight: 600, color: DS.n500,
          background: '#fff', padding: '1px 6px', borderRadius: 4,
          border: `1px solid ${DS.n200}`,
        }}>⌘K</kbd>
      </div>

      <div style={{ width: 1, height: 24, background: DS.n200 }} />

      {/* Notifications */}
      <button style={{
        height: 38, width: 38, borderRadius: 9999, background: 'transparent',
        border: 0, cursor: 'pointer', display: 'flex', alignItems: 'center',
        justifyContent: 'center', position: 'relative',
      }}>
        <MI name="notifications" size={20} color={DS.navy} />
        <span style={{
          position: 'absolute', top: 7, right: 9, minWidth: 15, height: 15,
          borderRadius: 9999, background: DS.danger, border: '2px solid #fff',
          color: '#fff', fontSize: 9, fontWeight: 700,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          padding: '0 3px',
        }}>4</span>
      </button>

      {/* Help */}
      <button style={{
        height: 38, width: 38, borderRadius: 9999, background: 'transparent',
        border: 0, cursor: 'pointer', display: 'flex', alignItems: 'center',
        justifyContent: 'center',
      }}>
        <MI name="help" size={20} color={DS.navy} />
      </button>

      {/* Avatar */}
      <div style={{
        display: 'flex', alignItems: 'center', gap: 10,
        padding: '4px 12px 4px 4px', borderRadius: 9999,
        background: DS.n100, cursor: 'pointer',
      }}>
        <div style={{
          width: 30, height: 30, borderRadius: '50%', background: DS.navy,
          color: '#fff', display: 'flex', alignItems: 'center',
          justifyContent: 'center', fontSize: 12, fontWeight: 700, fontFamily: 'Poppins',
        }}>RC</div>
        <div style={{ lineHeight: 1.1 }}>
          <div style={{ fontSize: 12.5, fontWeight: 600, color: DS.navy }}>Rafael C.</div>
          <div style={{ fontSize: 10.5, color: DS.n500 }}>Admin</div>
        </div>
        <MI name="expand_more" size={16} color={DS.n500} />
      </div>
    </header>
  );
}

Object.assign(window, { DS, MI, Sidebar, Topbar });
