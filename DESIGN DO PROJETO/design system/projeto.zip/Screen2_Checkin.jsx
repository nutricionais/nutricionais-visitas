/* eslint-disable */
// Tela 2 — Check-in GPS — 3 estados (A: Seleção, B: Confirmação, C: Em visita)

// ─── Estado A — Seleção ──────────────────────────────────────
function CheckinSelectScreen() {
  const institutions = [
    {
      name: 'Hospital São Luiz Morumbi',
      addr: 'R. Eng. Oscar Americano, 840 · Morumbi',
      dist: '120m',
      distNum: 120,
      zone: 'in',
    },
    {
      name: 'Hospital Albert Einstein',
      addr: 'Av. Albert Einstein, 627 · Morumbi',
      dist: '340m',
      distNum: 340,
      zone: 'in',
    },
    {
      name: 'Hospital Sírio-Libanês',
      addr: 'R. Dona Adma Jafet, 91 · Bela Vista',
      dist: '890m',
      distNum: 890,
      zone: 'out',
    },
  ];

  return (
    <div style={{
      height: '100%', display: 'flex', flexDirection: 'column',
      background: Nut.n50,
    }}>
      {/* Top bar */}
      <NavyTopBar title="Check-in" onBack={() => {}} />

      <div style={{ flex: 1, overflow: 'auto', padding: '14px 16px 28px' }}>
        {/* GPS status card */}
        <div style={{
          background: Nut.success50,
          border: `1px solid ${Nut.success}33`,
          borderRadius: 12,
          padding: '10px 14px',
          display: 'flex', alignItems: 'center', gap: 10,
          marginBottom: 16,
        }}>
          <span style={{
            width: 28, height: 28, borderRadius: '50%',
            background: Nut.success,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            flexShrink: 0,
          }}>
            <Icon name="gps_fixed" size={16} color="#fff" weight={600} />
          </span>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{
              fontSize: 13, fontWeight: 600, color: '#15803d',
              fontFamily: 'Inter, sans-serif',
            }}>GPS ativo</div>
            <div style={{
              fontSize: 11.5, color: '#166534',
              fontFamily: 'JetBrains Mono, monospace',
            }}>precisão ±8m · atualizado agora</div>
          </div>
        </div>

        {/* Search */}
        <div style={{
          background: '#fff',
          border: `1.5px solid ${Nut.n200}`,
          borderRadius: 12,
          height: 48,
          padding: '0 14px',
          display: 'flex', alignItems: 'center', gap: 10,
          marginBottom: 18,
        }}>
          <Icon name="search" size={20} color={Nut.n500} />
          <input placeholder="Buscar instituição..."
            style={{
              flex: 1, border: 0, outline: 0, background: 'transparent',
              fontFamily: 'Inter, sans-serif', fontSize: 15,
              color: Nut.navy,
            }} />
        </div>

        {/* List heading */}
        <div style={{
          display: 'flex', alignItems: 'baseline', justifyContent: 'space-between',
          marginBottom: 10,
        }}>
          <span style={{
            fontSize: 11, fontWeight: 700, letterSpacing: '0.08em',
            textTransform: 'uppercase', color: Nut.n500,
          }}>Mais próximas</span>
          <span style={{
            fontSize: 11, fontWeight: 600, color: Nut.n500,
            fontFamily: 'JetBrains Mono, monospace',
          }}>raio 500m</span>
        </div>

        {/* Institutions */}
        <div style={{
          background: '#fff', borderRadius: 14, overflow: 'hidden',
          boxShadow: '0 2px 8px rgba(10,31,92,0.05)',
          marginBottom: 18,
        }}>
          {institutions.map((inst, i, arr) => (
            <div key={inst.name} style={{
              display: 'flex', alignItems: 'center', gap: 12,
              padding: '14px 14px',
              borderBottom: i < arr.length - 1 ? `1px solid ${Nut.n100}` : 'none',
              cursor: 'pointer',
              background: i === 0 ? Nut.lime50 : '#fff',
              borderLeft: i === 0 ? `3px solid ${Nut.lime}` : '3px solid transparent',
            }}>
              {/* Pin */}
              <div style={{
                width: 40, height: 40, borderRadius: '50%',
                background: inst.zone === 'in' ? Nut.success : Nut.warning,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                flexShrink: 0,
                boxShadow: `0 4px 10px ${inst.zone === 'in' ? 'rgba(34,160,107,0.3)' : 'rgba(245,158,11,0.3)'}`,
              }}>
                <Icon name="location_on" size={22} color="#fff" weight={700} fill={1} />
              </div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{
                  fontFamily: 'Poppins, sans-serif', fontSize: 14.5, fontWeight: 600,
                  color: Nut.navy, lineHeight: 1.2,
                }}>{inst.name}</div>
                <div style={{
                  fontSize: 11.5, color: Nut.n500, marginTop: 3,
                  overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
                }}>{inst.addr}</div>
              </div>
              <div style={{ textAlign: 'right', flexShrink: 0 }}>
                <div style={{
                  fontFamily: 'JetBrains Mono, monospace',
                  fontSize: 14, fontWeight: 700,
                  color: inst.zone === 'in' ? Nut.success : Nut.warning,
                }}>{inst.dist}</div>
                {inst.zone === 'out' && (
                  <div style={{
                    fontSize: 9.5, color: Nut.warning, fontWeight: 700,
                    textTransform: 'uppercase', letterSpacing: '0.04em', marginTop: 2,
                  }}>fora do raio</div>
                )}
              </div>
            </div>
          ))}
        </div>

        {/* Manual check-in secondary */}
        <Btn variant="secondary" icon="edit_location_alt" full size="md">
          Check-in manual (sem GPS)
        </Btn>
      </div>
    </div>
  );
}

// ─── Estado B — Confirmação ──────────────────────────────────
function CheckinConfirmScreen() {
  return (
    <div style={{
      height: '100%', display: 'flex', flexDirection: 'column',
      background: Nut.n50,
    }}>
      <NavyTopBar title="Confirmar check-in" onBack={() => {}} />

      <div style={{ flex: 1, overflow: 'auto', padding: '14px 16px 28px' }}>
        {/* Stylized mini map */}
        <div style={{
          height: 180, borderRadius: 14, overflow: 'hidden',
          position: 'relative',
          background: 'linear-gradient(135deg, #E9EEF5 0%, #F3F5FA 100%)',
          marginBottom: 14,
          boxShadow: '0 2px 8px rgba(10,31,92,0.08)',
          border: `1px solid ${Nut.n200}`,
        }}>
          {/* map grid */}
          <svg width="100%" height="100%" style={{ position: 'absolute', inset: 0 }} preserveAspectRatio="none" viewBox="0 0 358 180">
            {/* streets */}
            <path d="M -10 120 Q 80 100, 180 130 T 370 110" stroke="#fff" strokeWidth="22" fill="none" opacity="0.9"/>
            <path d="M 60 -10 Q 80 80, 140 140 T 220 190" stroke="#fff" strokeWidth="14" fill="none" opacity="0.8"/>
            <path d="M 300 -10 L 260 180" stroke="#fff" strokeWidth="10" fill="none" opacity="0.8"/>
            <path d="M -10 40 Q 100 50, 200 30 T 380 50" stroke="#fff" strokeWidth="8" fill="none" opacity="0.7"/>
            {/* blocks */}
            <rect x="20" y="55" width="38" height="38" rx="3" fill="#DDE4EF" />
            <rect x="160" y="20" width="52" height="42" rx="3" fill="#DDE4EF" />
            <rect x="240" y="80" width="42" height="30" rx="3" fill="#DDE4EF" />
            <rect x="70" y="150" width="40" height="35" rx="3" fill="#DDE4EF" />
            {/* green zone (radius) */}
            <circle cx="220" cy="95" r="54" fill="rgba(139,198,63,0.16)" stroke={Nut.lime} strokeWidth="1.5" strokeDasharray="4 4" />
          </svg>

          {/* user pin (blue) */}
          <div style={{
            position: 'absolute', top: 108, left: 165,
            display: 'flex', flexDirection: 'column', alignItems: 'center',
          }}>
            <div style={{
              width: 18, height: 18, borderRadius: '50%',
              background: Nut.info,
              border: '3px solid #fff',
              boxShadow: '0 0 0 6px rgba(37,99,235,0.2), 0 2px 4px rgba(0,0,0,0.2)',
            }} />
          </div>

          {/* destination pin (green) */}
          <div style={{
            position: 'absolute', top: 62, left: 210,
            display: 'flex', flexDirection: 'column', alignItems: 'center',
          }}>
            <div style={{
              width: 34, height: 34, borderRadius: '50% 50% 50% 0',
              transform: 'rotate(-45deg)',
              background: Nut.success,
              border: '2.5px solid #fff',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              boxShadow: '0 4px 10px rgba(34,160,107,0.35)',
            }}>
              <Icon name="local_hospital" size={16} color="#fff" weight={600}
                style={{ transform: 'rotate(45deg)' }} />
            </div>
          </div>

          {/* dashed line between pins */}
          <svg style={{ position: 'absolute', inset: 0, pointerEvents: 'none' }} width="100%" height="100%" viewBox="0 0 358 180" preserveAspectRatio="none">
            <path d="M 174 117 Q 195 100, 221 79" stroke={Nut.navy} strokeWidth="1.5" strokeDasharray="3 3" fill="none" opacity="0.5"/>
          </svg>

          {/* legend */}
          <div style={{
            position: 'absolute', top: 10, left: 10,
            background: 'rgba(255,255,255,0.92)',
            padding: '6px 10px', borderRadius: 8,
            display: 'flex', gap: 10, alignItems: 'center',
            fontSize: 10.5, fontWeight: 600, color: Nut.n600,
            fontFamily: 'Inter, sans-serif',
            boxShadow: '0 2px 6px rgba(0,0,0,0.08)',
          }}>
            <span style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
              <span style={{ width: 8, height: 8, borderRadius: '50%', background: Nut.info }} /> Você
            </span>
            <span style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
              <span style={{ width: 8, height: 8, borderRadius: '50%', background: Nut.success }} /> Local
            </span>
          </div>
        </div>

        {/* Info card */}
        <div style={{
          background: '#fff',
          borderRadius: 14,
          padding: 18,
          marginBottom: 16,
          boxShadow: '0 4px 12px rgba(10,31,92,0.06)',
        }}>
          <div style={{ display: 'flex', gap: 12, alignItems: 'flex-start', marginBottom: 14 }}>
            <BrandCircle icon="local_hospital" size={44} bg={Nut.navy} />
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{
                fontFamily: 'Poppins, sans-serif', fontSize: 17, fontWeight: 700,
                color: Nut.navy, letterSpacing: '-0.01em', lineHeight: 1.2,
              }}>
                Hospital São Luiz Morumbi
              </div>
              <div style={{
                fontSize: 12.5, color: Nut.n600, marginTop: 4, lineHeight: 1.4,
              }}>
                R. Eng. Oscar Americano, 840<br />
                Morumbi · São Paulo · SP
              </div>
            </div>
          </div>

          <div style={{
            display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10,
            paddingTop: 14,
            borderTop: `1px solid ${Nut.n100}`,
          }}>
            <div>
              <div style={{
                fontSize: 10, fontWeight: 700, letterSpacing: '0.06em',
                textTransform: 'uppercase', color: Nut.n500,
              }}>Distância</div>
              <div style={{
                marginTop: 4,
                display: 'flex', alignItems: 'center', gap: 6,
              }}>
                <span style={{
                  fontFamily: 'JetBrains Mono, monospace',
                  fontSize: 18, fontWeight: 700, color: Nut.success,
                }}>120m</span>
                <Icon name="check_circle" size={16} color={Nut.success} fill={1} />
              </div>
              <div style={{
                fontSize: 10.5, color: Nut.n500, marginTop: 2,
              }}>do local cadastrado</div>
            </div>
            <div>
              <div style={{
                fontSize: 10, fontWeight: 700, letterSpacing: '0.06em',
                textTransform: 'uppercase', color: Nut.n500,
              }}>Horário</div>
              <div style={{
                fontFamily: 'JetBrains Mono, monospace',
                fontSize: 22, fontWeight: 700, color: Nut.navy,
                marginTop: 2, letterSpacing: '-0.02em',
              }}>14:32</div>
              <div style={{
                fontSize: 10.5, color: Nut.n500,
              }}>sáb · 18 abr</div>
            </div>
          </div>
        </div>

        {/* Giant confirm */}
        <button style={{
          width: '100%',
          minHeight: 64,
          padding: '16px 24px',
          borderRadius: 9999,
          border: 0,
          background: `linear-gradient(180deg, ${Nut.lime} 0%, ${Nut.limeP} 100%)`,
          color: '#fff',
          boxShadow: '0 10px 28px rgba(139,198,63,0.4), inset 0 1.5px 0 rgba(255,255,255,0.35)',
          display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 10,
          cursor: 'pointer',
          fontFamily: 'Poppins, sans-serif',
          fontSize: 18, fontWeight: 700,
          letterSpacing: '-0.01em',
          marginBottom: 12,
        }}>
          <Icon name="check_circle" size={24} color="#fff" weight={600} fill={1} />
          Confirmar check-in
        </button>

        <div style={{ textAlign: 'center' }}>
          <button style={{
            background: 'none', border: 0, cursor: 'pointer',
            color: Nut.n600, fontFamily: 'Inter, sans-serif',
            fontSize: 14, fontWeight: 600, padding: '10px 20px',
          }}>Cancelar</button>
        </div>
      </div>
    </div>
  );
}

// ─── Estado C — Em visita ────────────────────────────────────
function CheckinOngoingScreen() {
  return (
    <div style={{
      height: '100%', display: 'flex', flexDirection: 'column',
      background: Nut.n50,
    }}>
      {/* Navy top bar with pulse indicator */}
      <NavyTopBar>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, minHeight: 40 }}>
          <button style={{
            background: 'rgba(255,255,255,0.08)', border: 0, cursor: 'pointer',
            width: 36, height: 36, borderRadius: '50%',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            color: '#fff', flexShrink: 0,
          }}>
            <Icon name="arrow_back_ios_new" size={18} weight={600} />
          </button>
          <div style={{
            flex: 1, display: 'flex', alignItems: 'center', gap: 8,
          }}>
            <span className="pulse-dot" style={{
              width: 10, height: 10, borderRadius: '50%', background: Nut.lime,
              boxShadow: `0 0 0 0 ${Nut.lime}`,
              animation: 'pulseLime 1.6s infinite',
              flexShrink: 0,
            }} />
            <span style={{
              fontFamily: 'Poppins, sans-serif',
              fontSize: 17, fontWeight: 600, color: '#fff',
            }}>Em visita</span>
          </div>
        </div>
      </NavyTopBar>

      <div style={{
        flex: 1, overflow: 'auto',
        padding: '14px 16px 24px',
        display: 'flex', flexDirection: 'column',
      }}>
        {/* Fixed top card */}
        <div style={{
          background: '#fff',
          borderRadius: 14,
          padding: 14,
          boxShadow: '0 4px 12px rgba(10,31,92,0.06)',
          display: 'flex', alignItems: 'center', gap: 12,
          marginBottom: 20,
          borderLeft: `4px solid ${Nut.lime}`,
        }}>
          <div style={{
            width: 38, height: 38, borderRadius: 10,
            background: Nut.lime50,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            flexShrink: 0,
          }}>
            <Icon name="local_hospital" size={20} color={Nut.limeP} weight={600} />
          </div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{
              fontFamily: 'Poppins, sans-serif', fontSize: 14.5, fontWeight: 600,
              color: Nut.navy, lineHeight: 1.25,
            }}>Hospital São Luiz Morumbi</div>
            <div style={{
              fontSize: 12, color: Nut.n500, marginTop: 2,
              fontFamily: 'Inter, sans-serif',
            }}>Iniciada às <span style={{
              fontFamily: 'JetBrains Mono, monospace', fontWeight: 600, color: Nut.navy,
            }}>14:32</span></div>
          </div>
        </div>

        {/* GIANT timer */}
        <div style={{
          flex: 1,
          display: 'flex', flexDirection: 'column',
          alignItems: 'center', justifyContent: 'center',
          gap: 12, padding: '20px 0',
        }}>
          <div style={{
            fontSize: 10, fontWeight: 700, letterSpacing: '0.14em',
            textTransform: 'uppercase', color: Nut.n500,
          }}>Tempo de visita</div>
          <div style={{
            fontFamily: 'JetBrains Mono, monospace',
            fontSize: 72, fontWeight: 700,
            color: Nut.navy,
            letterSpacing: '-0.04em',
            lineHeight: 1,
            fontVariantNumeric: 'tabular-nums',
            textShadow: '0 2px 0 rgba(10,31,92,0.04)',
          }}>
            00:47:23
          </div>
          <div style={{
            marginTop: 6,
            display: 'inline-flex', alignItems: 'center', gap: 8,
            padding: '6px 14px', borderRadius: 9999,
            background: Nut.lime50,
            color: Nut.limeP,
            fontSize: 12, fontWeight: 700, letterSpacing: '0.02em',
            fontFamily: 'Inter, sans-serif',
          }}>
            <Icon name="bolt" size={15} weight={700} fill={1} />
            DENTRO DO RAIO · GPS OK
          </div>
        </div>

        {/* Actions */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          <Btn variant="secondary" icon="edit_note" full size="lg">
            Adicionar detalhes agora
          </Btn>

          <button style={{
            width: '100%',
            minHeight: 64,
            padding: '16px 24px',
            borderRadius: 9999,
            border: 0,
            background: `linear-gradient(180deg, #E94B4B 0%, ${Nut.danger} 100%)`,
            color: '#fff',
            boxShadow: '0 10px 28px rgba(220,38,38,0.35), inset 0 1.5px 0 rgba(255,255,255,0.25)',
            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 10,
            cursor: 'pointer',
            fontFamily: 'Poppins, sans-serif',
            fontSize: 18, fontWeight: 700,
            letterSpacing: '-0.01em',
          }}>
            <Icon name="stop_circle" size={24} color="#fff" weight={600} fill={1} />
            Fazer check-out
          </button>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { CheckinSelectScreen, CheckinConfirmScreen, CheckinOngoingScreen });
