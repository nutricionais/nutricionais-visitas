/* eslint-disable */
// Base components for the Nutricionais field mobile app
// Mobile-first: big hit targets, pill buttons, Material Symbols Rounded

const NutColors = {
  navy: '#0A1F5C', navy50: '#F3F5FA', navy100: '#E3E7F1',
  lime: '#8BC63F', limeH: '#7AB033', limeP: '#689628',
  success: '#22A06B', warning: '#F59E0B', danger: '#DC2626',
  n50: '#FAFBFC', n100: '#F3F4F6', n200: '#E5E7EB', n300: '#D1D5DB',
  n400: '#9CA3AF', n500: '#6B7280', n600: '#4B5563', n700: '#374151',
};

function MSIcon({ name, size = 24, color, weight = 500, style = {} }) {
  return (
    <span className="material-symbols-rounded"
      style={{
        fontSize: size, color: color || 'currentColor',
        fontVariationSettings: `'wght' ${weight}`,
        lineHeight: 1, display: 'inline-flex', ...style
      }}>{name}</span>
  );
}

function NutButton({ children, variant = 'primary', icon, onClick, disabled, full, size = 'md' }) {
  const h = size === 'lg' ? 60 : 52;
  const styles = {
    primary: { background: disabled ? NutColors.n300 : NutColors.lime, color: '#fff' },
    secondary: { background: '#fff', color: NutColors.navy, border: `1.5px solid ${disabled ? NutColors.n300 : NutColors.navy}` },
    ghost: { background: 'transparent', color: NutColors.navy },
  }[variant];
  return (
    <button onClick={disabled ? undefined : onClick} disabled={disabled}
      style={{
        height: h, padding: '0 28px', borderRadius: 9999, border: 0,
        fontFamily: 'Inter, sans-serif', fontWeight: 600, fontSize: 15,
        display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 8,
        cursor: disabled ? 'not-allowed' : 'pointer',
        width: full ? '100%' : undefined,
        transition: 'all 160ms cubic-bezier(0.22,0.61,0.36,1)',
        boxShadow: variant === 'primary' && !disabled ? '0 4px 12px rgba(139,198,63,0.28)' : 'none',
        ...styles,
      }}
      onMouseDown={(e) => !disabled && (e.currentTarget.style.transform = 'scale(0.98)')}
      onMouseUp={(e) => (e.currentTarget.style.transform = 'scale(1)')}
      onMouseLeave={(e) => (e.currentTarget.style.transform = 'scale(1)')}
    >
      {icon && <MSIcon name={icon} size={22} />}
      {children}
    </button>
  );
}

function NutInput({ label, placeholder, icon, value, onChange, type = 'text', mono }) {
  const [focus, setFocus] = React.useState(false);
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
      {label && <label style={{ fontSize: 13, fontWeight: 600, color: NutColors.n700 }}>{label}</label>}
      <div style={{
        height: 48, borderRadius: 10, padding: '0 14px',
        border: `1.5px solid ${focus ? NutColors.lime : NutColors.n300}`,
        boxShadow: focus ? '0 0 0 3px rgba(139,198,63,0.25)' : 'none',
        background: '#fff', display: 'flex', alignItems: 'center', gap: 8,
        transition: 'all 120ms',
      }}>
        {icon && <MSIcon name={icon} size={20} color={NutColors.n500} />}
        <input type={type} placeholder={placeholder} {...(onChange ? { value: value || '', onChange } : { defaultValue: value || '' })}
          onFocus={() => setFocus(true)} onBlur={() => setFocus(false)}
          style={{
            flex: 1, border: 0, outline: 0, fontSize: 15, background: 'transparent',
            fontFamily: mono ? 'JetBrains Mono, monospace' : 'Inter, sans-serif',
            color: NutColors.navy,
          }} />
      </div>
    </div>
  );
}

function StatusBadge({ status }) {
  const map = {
    approved: { bg: '#E6F6EF', fg: '#15803d', dot: NutColors.success, text: 'Aprovado' },
    pending:  { bg: '#FEF4E1', fg: '#B45309', dot: NutColors.warning, text: 'Divergência' },
    rejected: { bg: '#FCE8E8', fg: '#B91C1C', dot: NutColors.danger,  text: 'Rejeitado' },
    review:   { bg: '#E4ECFD', fg: '#1D4ED8', dot: '#2563EB',         text: 'Em revisão' },
    draft:    { bg: NutColors.n100, fg: NutColors.n600, dot: NutColors.n400, text: 'Rascunho' },
  };
  const s = map[status] || map.draft;
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: 6,
      height: 24, padding: '0 10px', borderRadius: 9999,
      background: s.bg, color: s.fg, fontSize: 11.5, fontWeight: 600,
    }}>
      <span style={{ width: 6, height: 6, borderRadius: '50%', background: s.dot }} />
      {s.text}
    </span>
  );
}

function VisitCard({ hospital, time, doctor, status, cnpj, onClick }) {
  return (
    <div onClick={onClick} style={{
      background: '#fff', borderRadius: 12, padding: 16,
      boxShadow: '0 4px 12px rgba(10,31,92,0.06)',
      display: 'flex', flexDirection: 'column', gap: 8, cursor: 'pointer',
    }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
        <div style={{ fontFamily: 'Poppins, sans-serif', fontWeight: 600, fontSize: 16, color: NutColors.navy, lineHeight: 1.25 }}>
          {hospital}
        </div>
        <StatusBadge status={status} />
      </div>
      <div style={{ fontSize: 13, color: NutColors.n600, display: 'flex', gap: 8, alignItems: 'center' }}>
        <MSIcon name="schedule" size={15} color={NutColors.n500} /> {time}
        <span style={{ opacity: 0.5 }}>·</span>
        <MSIcon name="person" size={15} color={NutColors.n500} /> {doctor}
      </div>
      {cnpj && <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 11.5, color: NutColors.n500 }}>{cnpj}</div>}
    </div>
  );
}

function BottomNav({ active, onChange }) {
  const items = [
    { id: 'home', icon: 'home', label: 'Início' },
    { id: 'visits', icon: 'location_on', label: 'Visitas' },
    { id: 'agenda', icon: 'calendar_month', label: 'Agenda' },
    { id: 'profile', icon: 'person', label: 'Perfil' },
  ];
  return (
    <div style={{
      position: 'absolute', bottom: 0, left: 0, right: 0,
      background: '#fff', borderTop: `1px solid ${NutColors.n200}`,
      display: 'flex', justifyContent: 'space-around', padding: '8px 0 28px',
      zIndex: 5,
    }}>
      {items.map(it => {
        const isActive = active === it.id;
        return (
          <button key={it.id} onClick={() => onChange(it.id)} style={{
            background: 'transparent', border: 0, cursor: 'pointer',
            display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 3,
            padding: '6px 14px',
            color: isActive ? NutColors.lime : NutColors.n500,
          }}>
            <MSIcon name={it.icon} size={26} weight={isActive ? 600 : 400} />
            <span style={{ fontSize: 11, fontWeight: isActive ? 600 : 500, fontFamily: 'Inter, sans-serif' }}>{it.label}</span>
          </button>
        );
      })}
    </div>
  );
}

function AppHeader({ title, onBack, action }) {
  return (
    <div style={{
      background: NutColors.navy, color: '#fff',
      padding: '14px 16px', display: 'flex', alignItems: 'center', gap: 10,
      minHeight: 56, paddingTop: 18,
    }}>
      {onBack && (
        <button onClick={onBack} style={{
          background: 'transparent', border: 0, color: '#fff', cursor: 'pointer',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          width: 36, height: 36, borderRadius: 9999,
        }}>
          <MSIcon name="arrow_back" size={24} />
        </button>
      )}
      <div style={{ flex: 1, fontFamily: 'Poppins, sans-serif', fontSize: 18, fontWeight: 600 }}>{title}</div>
      {action}
    </div>
  );
}

Object.assign(window, { NutColors, MSIcon, NutButton, NutInput, StatusBadge, VisitCard, BottomNav, AppHeader });
