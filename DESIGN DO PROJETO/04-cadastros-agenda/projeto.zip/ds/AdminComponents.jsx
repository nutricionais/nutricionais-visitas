/* eslint-disable */
const AdmColors = {
  navy: '#0A1F5C', navy50: '#F3F5FA', navy100: '#E3E7F1', navy800: '#0E2872',
  lime: '#8BC63F', limeH: '#7AB033',
  success: '#22A06B', warning: '#F59E0B', danger: '#DC2626',
  n50: '#FAFBFC', n100: '#F3F4F6', n200: '#E5E7EB', n300: '#D1D5DB',
  n400: '#9CA3AF', n500: '#6B7280', n600: '#4B5563', n700: '#374151', n900: '#111827',
};

function AIcon({ name, size = 20, color, weight = 500, style = {} }) {
  return (
    <span className="material-symbols-rounded" style={{
      fontSize: size, color: color || 'currentColor',
      fontVariationSettings: `'wght' ${weight}`,
      lineHeight: 1, display: 'inline-flex', ...style
    }}>{name}</span>
  );
}

function Sidebar({ active, onChange }) {
  const items = [
    { id: 'dashboard', icon: 'dashboard', label: 'Dashboard' },
    { id: 'review', icon: 'rule', label: 'Fila de revisão', badge: 7 },
    { id: 'visits', icon: 'location_on', label: 'Todas as visitas' },
    { id: 'agenda', icon: 'calendar_month', label: 'Agenda' },
    { id: 'institutions', icon: 'apartment', label: 'Instituições' },
    { id: 'team', icon: 'groups', label: 'Equipe' },
    { id: 'billing', icon: 'receipt_long', label: 'Faturamento' },
    { id: 'reports', icon: 'insights', label: 'Relatórios' },
  ];
  const bottom = [
    { id: 'settings', icon: 'settings', label: 'Configurações' },
    { id: 'help', icon: 'help', label: 'Ajuda' },
  ];
  return (
    <aside style={{
      width: 240, background: AdmColors.navy, color: '#fff',
      display: 'flex', flexDirection: 'column',
      fontFamily: 'Inter, sans-serif',
    }}>
      <div style={{ padding: '20px 20px 12px', display: 'flex', alignItems: 'center', gap: 10 }}>
        <img src="ds/nutri-logo-white.png" alt="" style={{ height: 32 }} />
        <div style={{ fontFamily: 'Poppins, sans-serif', fontWeight: 700, fontSize: 16 }}>Nutricionais</div>
      </div>
      <div style={{ fontSize: 10.5, fontWeight: 600, letterSpacing: '0.08em', color: 'rgba(255,255,255,0.5)', padding: '14px 20px 8px', textTransform: 'uppercase' }}>Operação</div>
      <nav style={{ display: 'flex', flexDirection: 'column', padding: '0 8px' }}>
        {items.map(it => <SideItem key={it.id} item={it} active={active === it.id} onClick={() => onChange(it.id)} />)}
      </nav>
      <div style={{ flex: 1 }} />
      <nav style={{ display: 'flex', flexDirection: 'column', padding: '0 8px 16px' }}>
        {bottom.map(it => <SideItem key={it.id} item={it} active={active === it.id} onClick={() => onChange(it.id)} />)}
      </nav>
    </aside>
  );
}

function SideItem({ item, active, onClick }) {
  return (
    <button onClick={onClick} style={{
      display: 'flex', alignItems: 'center', gap: 12,
      padding: '10px 12px', margin: '1px 0',
      background: active ? 'rgba(139,198,63,0.14)' : 'transparent',
      color: active ? '#fff' : 'rgba(255,255,255,0.75)',
      border: 0, borderRadius: 8, cursor: 'pointer', fontSize: 14, fontWeight: 500,
      position: 'relative', textAlign: 'left', fontFamily: 'inherit',
      borderLeft: active ? `3px solid ${AdmColors.lime}` : '3px solid transparent',
      paddingLeft: active ? 12 : 15,
    }}>
      <AIcon name={item.icon} size={20} color={active ? AdmColors.lime : undefined} />
      <span style={{ flex: 1 }}>{item.label}</span>
      {item.badge && (
        <span style={{ background: AdmColors.danger, color: '#fff', fontSize: 11, fontWeight: 700, padding: '2px 7px', borderRadius: 9999 }}>{item.badge}</span>
      )}
    </button>
  );
}

function Topbar({ title, subtitle }) {
  return (
    <header style={{
      height: 64, background: '#fff', borderBottom: `1px solid ${AdmColors.n200}`,
      display: 'flex', alignItems: 'center', padding: '0 28px', gap: 16, flexShrink: 0,
    }}>
      <div style={{ flex: 1 }}>
        <div style={{ fontFamily: 'Poppins, sans-serif', fontSize: 18, fontWeight: 700, color: AdmColors.navy }}>{title}</div>
        {subtitle && <div style={{ fontSize: 12.5, color: AdmColors.n500 }}>{subtitle}</div>}
      </div>
      <div style={{
        height: 40, borderRadius: 9999, background: AdmColors.n100, padding: '0 14px 0 12px',
        display: 'flex', alignItems: 'center', gap: 8, width: 300,
      }}>
        <AIcon name="search" size={18} color={AdmColors.n500} />
        <input placeholder="Buscar hospital, nutricionista, visita…"
          style={{ flex: 1, background: 'transparent', border: 0, outline: 0, fontSize: 13.5, fontFamily: 'Inter', color: AdmColors.navy }} />
      </div>
      <button style={{ height: 40, width: 40, borderRadius: 9999, background: AdmColors.n100, border: 0, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', position: 'relative' }}>
        <AIcon name="notifications" size={20} color={AdmColors.navy} />
        <span style={{ position: 'absolute', top: 8, right: 10, width: 8, height: 8, borderRadius: '50%', background: AdmColors.danger, border: '2px solid #fff' }} />
      </button>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '4px 10px 4px 4px', borderRadius: 9999, background: AdmColors.n100 }}>
        <div style={{ width: 32, height: 32, borderRadius: '50%', background: AdmColors.navy, color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 13, fontWeight: 700, fontFamily: 'Poppins' }}>RC</div>
        <div style={{ fontSize: 13, fontWeight: 600, color: AdmColors.navy }}>Rafael C.</div>
      </div>
    </header>
  );
}

function KPICard({ icon, label, value, delta, deltaSign = 'up', accent = 'lime' }) {
  const deltaColor = deltaSign === 'up' ? AdmColors.success : AdmColors.danger;
  const circleBg = accent === 'lime' ? AdmColors.lime : AdmColors.navy;
  return (
    <div style={{
      background: '#fff', borderRadius: 12, padding: 20,
      boxShadow: '0 2px 8px rgba(10,31,92,0.05)',
      display: 'flex', flexDirection: 'column', gap: 12,
    }}>
      <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between' }}>
        <div style={{
          width: 44, height: 44, borderRadius: '50%', background: circleBg,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}><AIcon name={icon} size={22} color="#fff" /></div>
        {delta && <div style={{ fontSize: 12, fontWeight: 600, color: deltaColor, display: 'flex', alignItems: 'center', gap: 2 }}>
          <AIcon name={deltaSign === 'up' ? 'trending_up' : 'trending_down'} size={14} />{delta}
        </div>}
      </div>
      <div>
        <div style={{ fontFamily: 'Poppins, sans-serif', fontSize: 28, fontWeight: 700, color: AdmColors.navy, lineHeight: 1, fontVariantNumeric: 'tabular-nums' }}>{value}</div>
        <div style={{ fontSize: 12, fontWeight: 600, color: AdmColors.n500, textTransform: 'uppercase', letterSpacing: '0.05em', marginTop: 6 }}>{label}</div>
      </div>
    </div>
  );
}

function AStatusBadge({ status }) {
  const map = {
    approved: { bg: '#E6F6EF', fg: '#15803d', dot: AdmColors.success, text: 'Aprovado' },
    pending:  { bg: '#FEF4E1', fg: '#B45309', dot: AdmColors.warning, text: 'Divergência' },
    rejected: { bg: '#FCE8E8', fg: '#B91C1C', dot: AdmColors.danger,  text: 'Rejeitado' },
    review:   { bg: '#E4ECFD', fg: '#1D4ED8', dot: '#2563EB',         text: 'Em revisão' },
    paid:     { bg: '#E6F6EF', fg: '#15803d', dot: AdmColors.success, text: 'Pago' },
    draft:    { bg: AdmColors.n100, fg: AdmColors.n600, dot: AdmColors.n400, text: 'Rascunho' },
  };
  const s = map[status] || map.draft;
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: 5,
      height: 22, padding: '0 9px', borderRadius: 9999,
      background: s.bg, color: s.fg, fontSize: 11, fontWeight: 600,
    }}>
      <span style={{ width: 6, height: 6, borderRadius: '50%', background: s.dot }} />
      {s.text}
    </span>
  );
}

function AButton({ children, variant = 'primary', icon, onClick, size = 'md' }) {
  const h = size === 'sm' ? 34 : 40;
  const styles = {
    primary: { background: AdmColors.lime, color: '#fff' },
    secondary: { background: '#fff', color: AdmColors.navy, border: `1.5px solid ${AdmColors.navy}` },
    ghost: { background: 'transparent', color: AdmColors.navy },
  }[variant];
  return (
    <button onClick={onClick} style={{
      height: h, padding: `0 ${size === 'sm' ? 14 : 18}px`, borderRadius: 9999, border: 0,
      fontFamily: 'Inter, sans-serif', fontWeight: 600, fontSize: size === 'sm' ? 13 : 14,
      display: 'inline-flex', alignItems: 'center', gap: 6, cursor: 'pointer',
      ...styles,
    }}>
      {icon && <AIcon name={icon} size={size === 'sm' ? 16 : 18} />}
      {children}
    </button>
  );
}

function DivergenceFlag({ type }) {
  const map = {
    gps: { icon: 'location_off', color: AdmColors.danger, text: 'GPS 240m fora' },
    time: { icon: 'schedule', color: AdmColors.warning, text: '23min antes' },
    duration: { icon: 'hourglass_empty', color: AdmColors.warning, text: 'Duração 3min' },
    ok: { icon: 'check_circle', color: AdmColors.success, text: 'OK' },
  };
  const f = map[type] || map.ok;
  return (
    <span style={{ display: 'inline-flex', alignItems: 'center', gap: 4, color: f.color, fontSize: 12, fontWeight: 600 }}>
      <AIcon name={f.icon} size={14} />
      {f.text}
    </span>
  );
}

Object.assign(window, { AdmColors, AIcon, Sidebar, SideItem, Topbar, KPICard, AStatusBadge, AButton, DivergenceFlag });
