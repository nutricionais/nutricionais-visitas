/* eslint-disable */
// Tela 2 — Cadastro rápido de profissional (modal desktop + bottom sheet mobile)

// Autocomplete select simples (mock)
function IAutocomplete({ value, onChange, placeholder, options = [] }) {
  const [focus, setFocus] = React.useState(false);
  const [open, setOpen] = React.useState(false);
  return (
    <div style={{ position: 'relative' }}>
      <div style={{
        height: 42, borderRadius: 10, padding: '0 12px',
        border: `1.5px solid ${focus ? AdmColors.lime : AdmColors.n300}`,
        boxShadow: focus ? '0 0 0 3px rgba(139,198,63,0.22)' : 'none',
        background: '#fff', display: 'flex', alignItems: 'center', gap: 8,
      }}>
        <AIcon name="apartment" size={17} color={AdmColors.n500} />
        <input value={value || ''} onChange={e => { onChange(e.target.value); setOpen(true); }}
          onFocus={() => { setFocus(true); setOpen(true); }} onBlur={() => { setFocus(false); setTimeout(() => setOpen(false), 120); }}
          placeholder={placeholder}
          style={{ flex: 1, border: 0, outline: 0, fontSize: 14, fontFamily: 'Inter', color: AdmColors.navy, background: 'transparent', minWidth: 0 }} />
        <span style={{ fontSize: 11, color: AdmColors.n500, background: AdmColors.navy50, padding: '2px 8px', borderRadius: 9999, fontWeight: 600 }}>vinculado</span>
      </div>
      {open && value && (
        <div style={{ position: 'absolute', top: 46, left: 0, right: 0, background: '#fff', borderRadius: 10, boxShadow: '0 8px 24px rgba(10,31,92,0.14)', border: `1px solid ${AdmColors.n200}`, maxHeight: 180, overflow: 'auto', zIndex: 20 }}>
          {options.filter(o => o.toLowerCase().includes(value.toLowerCase())).map(o => (
            <button key={o} onMouseDown={() => { onChange(o); setOpen(false); }} style={{ width: '100%', padding: '10px 14px', border: 0, background: 'transparent', textAlign: 'left', cursor: 'pointer', fontSize: 13.5, color: AdmColors.navy, fontFamily: 'Inter', display: 'flex', alignItems: 'center', gap: 8 }}>
              <AIcon name="apartment" size={15} color={AdmColors.n400} /> {o}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

function ProfessionalModalContent({ form, set, layout = 'desktop' }) {
  const isOther = form.profissao === 'Outro';
  const emailOk = !form.email || /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email);
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: layout === 'mobile' ? 14 : 16 }}>
      <IField label="Instituição vinculada" required hint="Já pré-selecionada pelo contexto">
        <IAutocomplete value={form.hospital} onChange={v => set('hospital', v)}
          placeholder="Buscar hospital…"
          options={['Hospital São Camilo', 'Hospital Sírio-Libanês', 'Hospital Albert Einstein', 'Hospital Samaritano', 'Hospital 9 de Julho']} />
      </IField>
      <IField label="Nome completo" required>
        <ITextInput value={form.nome} onChange={e => set('nome', e.target.value)} placeholder="Nome e sobrenome" icon="person" />
      </IField>
      <div style={{ display: 'grid', gridTemplateColumns: layout === 'mobile' ? '1fr' : '1fr 1fr', gap: layout === 'mobile' ? 14 : 14 }}>
        <IField label="Profissão" required>
          <ISelect value={form.profissao} onChange={e => set('profissao', e.target.value)}
            placeholder="Selecione…"
            options={['Nutricionista', 'Farmacêutico', 'Médico', 'Enfermeiro', 'Comprador', 'Outro']} />
        </IField>
        <IField label="Número do conselho" hint="Aceita letras + números">
          <ITextInput value={form.conselho} onChange={e => set('conselho', e.target.value)}
            placeholder="Ex: CRN-3 12345 ou 'Não se aplica'" mono />
        </IField>
      </div>

      {isOther && (
        <div style={{ padding: 12, background: AdmColors.navy50, borderRadius: 10, border: `1px dashed ${AdmColors.navy}`, display: 'flex', flexDirection: 'column', gap: 8 }}>
          <IField label="Especificar profissão" required>
            <ITextInput value={form.outro} onChange={e => set('outro', e.target.value)} placeholder="Qual profissão?" icon="edit" />
          </IField>
          <div style={{ fontSize: 11.5, color: AdmColors.navy, display: 'flex', alignItems: 'center', gap: 6 }}>
            <AIcon name="info" size={14} color={AdmColors.warning} />
            Admin padronizará esta profissão depois.
          </div>
        </div>
      )}

      <div style={{ display: 'grid', gridTemplateColumns: layout === 'mobile' ? '1fr' : '1fr 1fr', gap: 14 }}>
        <IField label="E-mail" hint="Opcional" error={form.email && !emailOk ? 'E-mail inválido' : null}>
          <ITextInput value={form.email} onChange={e => set('email', e.target.value)} placeholder="profissional@hospital.com.br" icon="mail" />
        </IField>
        <IField label="Telefone" hint="Opcional">
          <ITextInput value={form.tel} onChange={e => set('tel', maskPhone(e.target.value))} placeholder="(00) 00000-0000" mono icon="call" />
        </IField>
      </div>

      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '10px 14px', background: form.ativo ? (AdmColors.lime50 || '#F4F9EA') : AdmColors.n50, borderRadius: 10, border: `1px solid ${form.ativo ? AdmColors.lime : AdmColors.n200}` }}>
        <div>
          <div style={{ fontSize: 13.5, fontWeight: 600, color: AdmColors.navy }}>Profissional ativo</div>
          <div style={{ fontSize: 11.5, color: AdmColors.n600 }}>
            {form.ativo ? 'Aparece nas opções ao registrar visita' : 'Oculto nas listas'}
          </div>
        </div>
        <IToggle checked={form.ativo} onChange={v => set('ativo', v)} />
      </div>
    </div>
  );
}

// ────────────────── Variant A — Desktop Modal ──────────────────
function NewProfessionalDesktop() {
  const [form, setForm] = React.useState({
    hospital: 'Hospital São Camilo', nome: 'Dr. Rogério Campos', profissao: 'Farmacêutico',
    conselho: 'CRF-SP 48210', email: 'rogerio.campos@saocamilo.com.br', tel: '(11) 99812-4430',
    ativo: true, outro: '',
  });
  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));

  return (
    <div style={{ width: '100%', height: '100%', position: 'relative', background: '#fff', overflow: 'hidden' }}>
      {/* Blurred background — team screen */}
      <div style={{ position: 'absolute', inset: 0, filter: 'blur(2.5px)', opacity: 0.65, pointerEvents: 'none' }}>
        <div style={{ display: 'flex', height: '100%' }}>
          <Sidebar active="team" onChange={() => {}} />
          <div style={{ flex: 1, background: AdmColors.n50, display: 'flex', flexDirection: 'column' }}>
            <div style={{ height: 64, background: '#fff', borderBottom: `1px solid ${AdmColors.n200}`, display: 'flex', alignItems: 'center', padding: '0 28px' }}>
              <div style={{ fontFamily: 'Poppins', fontSize: 18, fontWeight: 700, color: AdmColors.navy }}>Profissionais</div>
            </div>
            <div style={{ padding: 28, display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 16 }}>
              {[1,2,3,4,5,6].map(i => (
                <div key={i} style={{ background: '#fff', borderRadius: 12, padding: 20, height: 120 }} />
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Overlay */}
      <div style={{ position: 'absolute', inset: 0, background: 'rgba(10,31,92,0.5)', backdropFilter: 'blur(4px)', zIndex: 5 }} />

      {/* Modal */}
      <div style={{
        position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%, -50%)',
        width: 480, maxHeight: '90%', background: '#fff', borderRadius: 16,
        boxShadow: '0 24px 64px rgba(10,31,92,0.35)', zIndex: 10,
        display: 'flex', flexDirection: 'column', overflow: 'hidden',
      }}>
        <div style={{ padding: '18px 22px', borderBottom: `1px solid ${AdmColors.n100}`, display: 'flex', alignItems: 'center', gap: 12 }}>
          <div style={{ width: 36, height: 36, borderRadius: 10, background: AdmColors.lime, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <AIcon name="person_add" size={20} color="#fff" />
          </div>
          <div style={{ flex: 1 }}>
            <div style={{ fontFamily: 'Poppins', fontSize: 17, fontWeight: 700, color: AdmColors.navy }}>Novo profissional</div>
            <div style={{ fontSize: 12, color: AdmColors.n500 }}>Cadastro rápido · vinculado à instituição</div>
          </div>
          <button style={{ width: 32, height: 32, borderRadius: '50%', background: AdmColors.n100, border: 0, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <AIcon name="close" size={18} color={AdmColors.n600} />
          </button>
        </div>
        <div style={{ padding: '18px 22px', overflow: 'auto', flex: 1 }}>
          <ProfessionalModalContent form={form} set={set} layout="desktop" />
        </div>
        <div style={{ padding: '14px 22px', borderTop: `1px solid ${AdmColors.n100}`, background: AdmColors.n50, display: 'flex', gap: 10, justifyContent: 'flex-end' }}>
          <AButton variant="secondary">Cancelar</AButton>
          <AButton variant="primary" icon="check">Salvar profissional</AButton>
        </div>
      </div>
    </div>
  );
}

// ────────────────── Variant B — Mobile Bottom Sheet ──────────────────
function NewProfessionalMobile() {
  const [form, setForm] = React.useState({
    hospital: 'Hospital São Camilo', nome: 'Dr. Rogério Campos', profissao: 'Farmacêutico',
    conselho: 'CRF-SP 48210', email: '', tel: '(11) 99812-4430',
    ativo: true, outro: '',
  });
  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));

  return (
    <div style={{ width: '100%', height: '100%', position: 'relative', background: '#F3F5FA', overflow: 'hidden' }}>
      {/* Faux page behind */}
      <div style={{ position: 'absolute', inset: 0, filter: 'blur(1.5px)', opacity: 0.75 }}>
        <div style={{ background: AdmColors.navy, color: '#fff', padding: '14px 16px', paddingTop: 26 }}>
          <div style={{ fontFamily: 'Poppins', fontSize: 18, fontWeight: 600 }}>Profissionais</div>
        </div>
        <div style={{ padding: 16, display: 'flex', flexDirection: 'column', gap: 10 }}>
          {[1,2,3,4].map(i => <div key={i} style={{ background: '#fff', borderRadius: 12, height: 72 }} />)}
        </div>
      </div>

      {/* Overlay */}
      <div style={{ position: 'absolute', inset: 0, background: 'rgba(10,31,92,0.55)', zIndex: 5 }} />

      {/* Bottom sheet */}
      <div style={{
        position: 'absolute', bottom: 0, left: 0, right: 0,
        background: '#fff', borderRadius: '20px 20px 0 0', zIndex: 10,
        maxHeight: '92%', display: 'flex', flexDirection: 'column',
        boxShadow: '0 -12px 40px rgba(10,31,92,0.25)',
      }}>
        {/* handle */}
        <div style={{ padding: '10px 0 0', display: 'flex', justifyContent: 'center' }}>
          <div style={{ width: 40, height: 5, borderRadius: 3, background: AdmColors.n300 }} />
        </div>
        <div style={{ padding: '14px 18px 8px', display: 'flex', alignItems: 'center', gap: 12 }}>
          <div style={{ width: 36, height: 36, borderRadius: 10, background: AdmColors.lime, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <AIcon name="person_add" size={20} color="#fff" />
          </div>
          <div style={{ flex: 1 }}>
            <div style={{ fontFamily: 'Poppins', fontSize: 17, fontWeight: 700, color: AdmColors.navy }}>Novo profissional</div>
            <div style={{ fontSize: 11.5, color: AdmColors.n500 }}>Vinculado a Hospital São Camilo</div>
          </div>
          <button style={{ width: 32, height: 32, borderRadius: '50%', background: AdmColors.n100, border: 0 }}>
            <AIcon name="close" size={18} color={AdmColors.n600} />
          </button>
        </div>
        <div style={{ padding: '10px 18px 14px', overflow: 'auto', flex: 1 }}>
          <ProfessionalModalContent form={form} set={set} layout="mobile" />
        </div>
        <div style={{ padding: '12px 18px 22px', borderTop: `1px solid ${AdmColors.n100}`, background: '#fff' }}>
          <button style={{ width: '100%', height: 52, borderRadius: 9999, background: AdmColors.lime, color: '#fff', border: 0, fontSize: 15, fontWeight: 700, fontFamily: 'Inter', boxShadow: '0 4px 12px rgba(139,198,63,0.28)', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 8 }}>
            <span className="material-symbols-rounded" style={{ fontSize: 20 }}>check</span>
            Salvar profissional
          </button>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { NewProfessionalDesktop, NewProfessionalMobile, IAutocomplete });
