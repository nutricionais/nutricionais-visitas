/* eslint-disable */
// Tela 3 — Agenda (desktop + mobile)

// ──────────────────────── Calendar ────────────────────────
const MONTHS_PT = ['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'];
const DOW_PT = ['Dom','Seg','Ter','Qua','Qui','Sex','Sáb'];
const DOW_SHORT = ['D','S','T','Q','Q','S','S'];

// Dados mock de visitas — abril/2026 (hoje = 18/abr, sexta)
const VISIT_DATA = {
  3:  [{ s: 'past' }],
  6:  [{ s: 'past' }, { s: 'past' }],
  8:  [{ s: 'past' }],
  10: [{ s: 'past' }, { s: 'cancel' }],
  13: [{ s: 'past' }],
  14: [{ s: 'past' }, { s: 'past' }, { s: 'past' }, { s: 'past' }], // +1
  15: [{ s: 'past' }, { s: 'resc' }],
  16: [{ s: 'past' }],
  17: [{ s: 'past' }, { s: 'past' }, { s: 'past' }],
  18: [{ s: 'ok' }, { s: 'ok' }], // hoje
  19: [{ s: 'ok' }],
  22: [{ s: 'ok' }, { s: 'ok' }],
  23: [{ s: 'resc' }],
  24: [{ s: 'ok' }],
  27: [{ s: 'ok' }, { s: 'ok' }, { s: 'ok' }, { s: 'ok' }, { s: 'ok' }], // +2
  29: [{ s: 'ok' }, { s: 'cancel' }],
  30: [{ s: 'ok' }],
};

const PILL_COLOR = {
  ok:    AdmColors.lime,
  resc:  AdmColors.warning,
  cancel: AdmColors.n400,
  past:  '#2563EB',
};

function CalendarMonth({ mobile = false }) {
  // Abril 2026: começa numa quarta-feira (dia 1 = Qua)
  // Week starts on Sunday.
  const startOffset = 3; // Apr 1 is Wed
  const daysInMonth = 30;
  const cells = [];
  for (let i = 0; i < startOffset; i++) cells.push({ blank: true, prev: 31 - startOffset + 1 + i });
  for (let d = 1; d <= daysInMonth; d++) cells.push({ day: d, visits: VISIT_DATA[d] || [] });
  while (cells.length < 42) cells.push({ blank: true, next: cells.length - startOffset - daysInMonth + 1 });
  const today = 18;

  const cellH = mobile ? 48 : 100;

  return (
    <div>
      {/* Day-of-week header */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', borderBottom: `1px solid ${AdmColors.n200}` }}>
        {(mobile ? DOW_SHORT : DOW_PT).map((d, i) => (
          <div key={i} style={{ padding: '10px 8px', fontSize: 11, fontWeight: 700, color: AdmColors.n500, textTransform: 'uppercase', letterSpacing: '0.06em', textAlign: mobile ? 'center' : 'left' }}>{d}</div>
        ))}
      </div>
      {/* Cells */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', gridAutoRows: cellH }}>
        {cells.map((c, i) => {
          const isToday = c.day === today;
          const isPast = c.day && c.day < today;
          return (
            <div key={i} style={{
              borderRight: (i % 7 !== 6) ? `1px solid ${AdmColors.n100}` : 'none',
              borderBottom: `1px solid ${AdmColors.n100}`,
              padding: mobile ? 4 : 8,
              background: c.blank ? AdmColors.n50 : (isToday ? 'rgba(139,198,63,0.06)' : '#fff'),
              position: 'relative',
              display: 'flex', flexDirection: 'column',
              overflow: 'hidden',
            }}>
              <div style={{
                fontFamily: 'Poppins', fontSize: mobile ? 12 : 13,
                fontWeight: isToday ? 700 : 600,
                color: c.blank ? AdmColors.n300 : isPast ? AdmColors.n500 : AdmColors.navy,
                display: 'flex', alignItems: 'center', justifyContent: mobile ? 'center' : 'flex-start',
                marginBottom: mobile ? 2 : 4,
              }}>
                {isToday ? (
                  <span style={{ width: mobile ? 20 : 26, height: mobile ? 20 : 26, borderRadius: '50%', background: AdmColors.navy, color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: mobile ? 11 : 12, fontWeight: 700 }}>{c.day}</span>
                ) : (c.blank ? (mobile ? '' : (c.prev || c.next)) : c.day)}
              </div>
              {!c.blank && c.visits && !mobile && (
                <div style={{ display: 'flex', flexDirection: 'column', gap: 3, marginTop: 'auto' }}>
                  {c.visits.slice(0, 3).map((v, vi) => (
                    <div key={vi} style={{
                      height: 18, borderRadius: 4, padding: '0 6px',
                      background: `${PILL_COLOR[v.s]}22`,
                      borderLeft: `3px solid ${PILL_COLOR[v.s]}`,
                      fontSize: 10.5, fontWeight: 600,
                      color: v.s === 'past' ? '#1D4ED8' : v.s === 'ok' ? '#4B7A1E' : v.s === 'resc' ? '#B45309' : AdmColors.n600,
                      display: 'flex', alignItems: 'center', textDecoration: v.s === 'cancel' ? 'line-through' : 'none',
                      overflow: 'hidden', whiteSpace: 'nowrap', textOverflow: 'ellipsis',
                    }}>
                      {v.s === 'ok' ? '14:30 São Luiz' : v.s === 'resc' ? '15:00 Sírio' : v.s === 'cancel' ? 'Cancelada' : '09:00 Visita'}
                    </div>
                  ))}
                  {c.visits.length > 3 && (
                    <div style={{ fontSize: 10.5, fontWeight: 700, color: AdmColors.navy, paddingLeft: 6 }}>
                      +{c.visits.length - 3}
                    </div>
                  )}
                </div>
              )}
              {!c.blank && c.visits.length > 0 && mobile && (
                <div style={{ display: 'flex', gap: 2, justifyContent: 'center', marginTop: 2 }}>
                  {c.visits.slice(0, 3).map((v, vi) => (
                    <span key={vi} style={{ width: 5, height: 5, borderRadius: '50%', background: PILL_COLOR[v.s] }} />
                  ))}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ──────────────────────── Visit card (side list) ────────────────────────
function VisitListCard({ when, hospital, nutri, goal, badge, note }) {
  const badgeMap = {
    ok:   { bg: '#E6F6EF', fg: '#15803d', dot: AdmColors.success, t: 'Confirmada' },
    resc: { bg: '#FEF4E1', fg: '#B45309', dot: AdmColors.warning, t: badge === 'resc2' ? 'Reagendada 2x' : 'Reagendada' },
  };
  const b = badgeMap[badge === 'resc2' ? 'resc' : badge];
  return (
    <div style={{ background: '#fff', borderRadius: 12, padding: 14, border: `1px solid ${AdmColors.n200}`, display: 'flex', flexDirection: 'column', gap: 8, transition: 'all 120ms', cursor: 'pointer' }}>
      <div style={{ display: 'flex', alignItems: 'flex-start', gap: 10 }}>
        <div style={{ flex: 1 }}>
          <div style={{ fontFamily: 'JetBrains Mono', fontSize: 11, fontWeight: 600, color: AdmColors.navy, textTransform: 'uppercase', letterSpacing: '0.04em' }}>{when}</div>
          <div style={{ fontFamily: 'Poppins', fontSize: 15, fontWeight: 700, color: AdmColors.navy, marginTop: 3 }}>{hospital}</div>
        </div>
        <button style={{ width: 28, height: 28, borderRadius: '50%', background: AdmColors.n100, border: 0, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
          <AIcon name="more_vert" size={17} color={AdmColors.n600} />
        </button>
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
        <span style={{ display: 'inline-flex', alignItems: 'center', gap: 5, height: 22, padding: '0 10px', borderRadius: 9999, background: b.bg, color: b.fg, fontSize: 11.5, fontWeight: 600 }}>
          <span style={{ width: 6, height: 6, borderRadius: '50%', background: b.dot }} />
          {b.t}
        </span>
        <span style={{ fontSize: 12, color: AdmColors.n500, display: 'inline-flex', alignItems: 'center', gap: 4 }}>
          <AIcon name="person" size={13} /> {nutri}
        </span>
      </div>
      {goal && <div style={{ fontSize: 12.5, color: AdmColors.n600, lineHeight: 1.4 }}>{goal}</div>}
      {note && (
        <div style={{ fontSize: 11.5, color: AdmColors.warning, display: 'flex', alignItems: 'center', gap: 4 }}>
          <AIcon name="history" size={13} /> {note}
        </div>
      )}
    </div>
  );
}

// ──────────────────────── Desktop ────────────────────────
function AgendaDesktop() {
  const [filter, setFilter] = React.useState('all');
  return (
    <div style={{ display: 'flex', height: '100%', background: AdmColors.n50, fontFamily: 'Inter' }}>
      <Sidebar active="agenda" onChange={() => {}} />
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', minWidth: 0 }}>
        <Topbar title="Agenda" subtitle="Visitas agendadas · abril/2026" />
        <div style={{ flex: 1, overflow: 'auto', padding: 24 }}>
          <div style={{ display: 'grid', gridTemplateColumns: '1.9fr 1fr', gap: 20, height: '100%' }}>
            {/* Calendar card */}
            <div style={{ background: '#fff', borderRadius: 12, boxShadow: '0 2px 8px rgba(10,31,92,0.05)', display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
              <div style={{ padding: '18px 22px', display: 'flex', alignItems: 'center', gap: 16, borderBottom: `1px solid ${AdmColors.n100}` }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                  <button style={{ width: 32, height: 32, borderRadius: 9999, background: AdmColors.n100, border: 0, cursor: 'pointer' }}>
                    <AIcon name="chevron_left" size={18} color={AdmColors.navy} />
                  </button>
                  <div style={{ fontFamily: 'Poppins', fontSize: 18, fontWeight: 700, color: AdmColors.navy, minWidth: 150, textAlign: 'center' }}>Abril 2026</div>
                  <button style={{ width: 32, height: 32, borderRadius: 9999, background: AdmColors.n100, border: 0, cursor: 'pointer' }}>
                    <AIcon name="chevron_right" size={18} color={AdmColors.navy} />
                  </button>
                  <button style={{ height: 32, padding: '0 14px', borderRadius: 9999, background: AdmColors.navy50, color: AdmColors.navy, border: 0, fontSize: 12.5, fontWeight: 600, marginLeft: 6, cursor: 'pointer', fontFamily: 'Inter' }}>Hoje</button>
                </div>
                <div style={{ marginLeft: 'auto', display: 'flex', gap: 6 }}>
                  {[{k:'all', l:'Todos nutricionistas'}, {k:'mine', l:'Minhas visitas'}].map(f => (
                    <button key={f.k} onClick={() => setFilter(f.k)} style={{
                      height: 30, padding: '0 12px', borderRadius: 9999,
                      background: filter === f.k ? AdmColors.navy : '#fff',
                      color: filter === f.k ? '#fff' : AdmColors.navy,
                      border: filter === f.k ? 'none' : `1px solid ${AdmColors.n300}`,
                      fontSize: 12, fontWeight: 600, cursor: 'pointer', fontFamily: 'Inter',
                    }}>{f.l}</button>
                  ))}
                </div>
              </div>
              {/* Legend */}
              <div style={{ padding: '10px 22px', display: 'flex', gap: 16, fontSize: 11.5, color: AdmColors.n600, borderBottom: `1px solid ${AdmColors.n100}` }}>
                {[['ok','Confirmada'],['resc','Reagendada'],['past','Realizada'],['cancel','Cancelada']].map(([k,l]) => (
                  <span key={k} style={{ display: 'inline-flex', alignItems: 'center', gap: 5 }}>
                    <span style={{ width: 10, height: 10, borderRadius: 2, background: PILL_COLOR[k] }} /> {l}
                  </span>
                ))}
              </div>
              <div style={{ flex: 1, overflow: 'auto' }}>
                <CalendarMonth />
              </div>
            </div>

            {/* Side list */}
            <div style={{ background: '#fff', borderRadius: 12, boxShadow: '0 2px 8px rgba(10,31,92,0.05)', display: 'flex', flexDirection: 'column', position: 'relative', overflow: 'hidden' }}>
              <div style={{ padding: '18px 20px', borderBottom: `1px solid ${AdmColors.n100}`, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <div>
                  <div style={{ fontFamily: 'Poppins', fontSize: 16, fontWeight: 700, color: AdmColors.navy }}>Próximas visitas</div>
                  <div style={{ fontSize: 12, color: AdmColors.n500, marginTop: 2 }}><b style={{ color: AdmColors.navy, fontFamily: 'JetBrains Mono' }}>12</b> próximas</div>
                </div>
                <button style={{ height: 30, padding: '0 12px', borderRadius: 9999, background: '#fff', border: `1px solid ${AdmColors.n300}`, fontSize: 12, fontWeight: 600, color: AdmColors.navy, cursor: 'pointer', fontFamily: 'Inter' }}>
                  Ver todas
                </button>
              </div>
              <div style={{ flex: 1, overflow: 'auto', padding: 14, display: 'flex', flexDirection: 'column', gap: 10 }}>
                <VisitListCard when="HOJE · 14:30" hospital="Hospital São Luiz" badge="ok" nutri="Ana Ribeiro" goal="Follow-up do protocolo de nutrição enteral no CTI." />
                <VisitListCard when="AMANHÃ · 09:00" hospital="Hospital Einstein" badge="ok" nutri="Bruno Costa" goal="Apresentação de novo fórmula pediátrica à equipe EMTN." note="Reagendada de 15/abr" />
                <VisitListCard when="TER 22/abr · 15:00" hospital="Hospital Sírio-Libanês" badge="ok" nutri="Ana Ribeiro" goal="Revisão trimestral de consumo + pedido de amostras." />
                <VisitListCard when="QUA 23/abr · 10:30" hospital="Hospital Oswaldo Cruz" badge="resc2" nutri="Carla Mendes" goal="Treinamento supervisor · agendar com antecedência." />
                <VisitListCard when="QUI 24/abr · 11:00" hospital="Hospital Samaritano" badge="ok" nutri="Diego Alves" />
              </div>
              {/* FAB */}
              <button style={{
                position: 'absolute', bottom: 18, right: 18,
                height: 52, padding: '0 20px', borderRadius: 9999,
                background: AdmColors.lime, border: 0, color: '#fff',
                fontSize: 14, fontWeight: 700, cursor: 'pointer',
                display: 'inline-flex', alignItems: 'center', gap: 8,
                boxShadow: '0 8px 20px rgba(139,198,63,0.45)', fontFamily: 'Inter',
              }}>
                <AIcon name="add" size={20} /> Nova visita
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ──────────────────────── Mobile ────────────────────────
function AgendaMobile({ showNewVisitSheet = false }) {
  const [tab, setTab] = React.useState('list');
  return (
    <div style={{ width: '100%', height: '100%', position: 'relative', background: '#F3F5FA', overflow: 'hidden', fontFamily: 'Inter' }}>
      {/* Navy top bar */}
      <div style={{ background: AdmColors.navy, color: '#fff', padding: '14px 16px 12px', paddingTop: 18 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 12 }}>
          <div style={{ fontFamily: 'Poppins', fontSize: 20, fontWeight: 700, flex: 1 }}>Agenda</div>
          <button style={{ width: 36, height: 36, borderRadius: '50%', background: 'rgba(255,255,255,0.12)', border: 0, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <AIcon name="filter_list" size={20} color="#fff" />
          </button>
        </div>
        {/* Chips */}
        <div style={{ display: 'flex', gap: 6, overflowX: 'auto' }}>
          {['Todas', 'Confirmadas', 'Reagendadas'].map((c, i) => (
            <span key={c} style={{
              padding: '5px 12px', borderRadius: 9999, fontSize: 12, fontWeight: 600,
              background: i === 0 ? AdmColors.lime : 'rgba(255,255,255,0.12)',
              color: i === 0 ? '#fff' : 'rgba(255,255,255,0.8)',
              whiteSpace: 'nowrap', flexShrink: 0,
            }}>{c}</span>
          ))}
        </div>
      </div>

      {/* List/calendar toggle */}
      <div style={{ padding: '12px 16px 8px', background: '#F3F5FA' }}>
        <div style={{ display: 'flex', background: AdmColors.n200, borderRadius: 10, padding: 3 }}>
          {[{k:'list', l:'Lista', ic:'view_list'}, {k:'cal', l:'Calendário', ic:'calendar_month'}].map(t => (
            <button key={t.k} onClick={() => setTab(t.k)} style={{
              flex: 1, height: 36, borderRadius: 8, border: 0,
              background: tab === t.k ? '#fff' : 'transparent',
              color: tab === t.k ? AdmColors.navy : AdmColors.n600,
              fontSize: 13, fontWeight: 600, cursor: 'pointer',
              display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 6,
              boxShadow: tab === t.k ? '0 1px 3px rgba(10,31,92,0.1)' : 'none',
              fontFamily: 'Inter',
            }}>
              <span className="material-symbols-rounded" style={{ fontSize: 16 }}>{t.ic}</span>{t.l}
            </button>
          ))}
        </div>
      </div>

      <div style={{ height: 'calc(100% - 180px)', overflow: 'auto', padding: '0 16px 100px' }}>
        {tab === 'list' ? (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            <div>
              <div style={{ fontSize: 11, fontWeight: 700, color: AdmColors.n500, textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 8, padding: '0 4px' }}>
                HOJE · SEX 18 ABR
              </div>
              <VisitListCard when="14:30" hospital="Hospital São Luiz" badge="ok" nutri="Ana Ribeiro" goal="Follow-up do protocolo de nutrição enteral no CTI." />
            </div>
            <div>
              <div style={{ fontSize: 11, fontWeight: 700, color: AdmColors.n500, textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 8, padding: '0 4px' }}>
                AMANHÃ · SÁB 19 ABR
              </div>
              <VisitListCard when="09:00" hospital="Hospital Einstein" badge="ok" nutri="Bruno Costa" note="Reagendada de 15/abr" />
            </div>
            <div>
              <div style={{ fontSize: 11, fontWeight: 700, color: AdmColors.n500, textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 8, padding: '0 4px' }}>
                TER 22 ABR
              </div>
              <VisitListCard when="15:00" hospital="Hospital Sírio-Libanês" badge="ok" nutri="Ana Ribeiro" goal="Revisão trimestral de consumo." />
            </div>
            <div>
              <div style={{ fontSize: 11, fontWeight: 700, color: AdmColors.n500, textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 8, padding: '0 4px' }}>
                QUA 23 ABR
              </div>
              <VisitListCard when="10:30" hospital="Hospital Oswaldo Cruz" badge="resc2" nutri="Carla Mendes" />
            </div>
          </div>
        ) : (
          <div style={{ background: '#fff', borderRadius: 12, overflow: 'hidden', border: `1px solid ${AdmColors.n200}` }}>
            <div style={{ padding: '12px 14px', display: 'flex', alignItems: 'center', gap: 10, borderBottom: `1px solid ${AdmColors.n100}` }}>
              <button style={{ width: 28, height: 28, borderRadius: 9999, background: AdmColors.n100, border: 0 }}><AIcon name="chevron_left" size={16} color={AdmColors.navy} /></button>
              <div style={{ flex: 1, textAlign: 'center', fontFamily: 'Poppins', fontSize: 14, fontWeight: 700, color: AdmColors.navy }}>Abril 2026</div>
              <button style={{ width: 28, height: 28, borderRadius: 9999, background: AdmColors.n100, border: 0 }}><AIcon name="chevron_right" size={16} color={AdmColors.navy} /></button>
            </div>
            <CalendarMonth mobile />
          </div>
        )}
      </div>

      {/* FAB */}
      {!showNewVisitSheet && (
        <button style={{
          position: 'absolute', bottom: 90, right: 16,
          width: 56, height: 56, borderRadius: '50%',
          background: AdmColors.lime, border: 0, color: '#fff',
          cursor: 'pointer', boxShadow: '0 8px 20px rgba(139,198,63,0.45)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>
          <span className="material-symbols-rounded" style={{ fontSize: 28 }}>add</span>
        </button>
      )}

      {/* Bottom nav */}
      <div style={{
        position: 'absolute', bottom: 0, left: 0, right: 0, height: 72,
        background: '#fff', borderTop: `1px solid ${AdmColors.n200}`,
        display: 'flex', justifyContent: 'space-around', padding: '8px 0 20px', zIndex: 5,
      }}>
        {[
          { i: 'home', l: 'Início', a: false },
          { i: 'location_on', l: 'Visitas', a: false },
          { i: 'calendar_month', l: 'Agenda', a: true },
          { i: 'person', l: 'Perfil', a: false },
        ].map(x => (
          <button key={x.i} style={{
            background: 'transparent', border: 0, cursor: 'pointer',
            display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 2,
            color: x.a ? AdmColors.lime : AdmColors.n500, padding: '4px 12px',
          }}>
            <span className="material-symbols-rounded" style={{ fontSize: 24, fontVariationSettings: x.a ? `'wght' 600` : `'wght' 400` }}>{x.i}</span>
            <span style={{ fontSize: 10.5, fontWeight: x.a ? 700 : 500 }}>{x.l}</span>
          </button>
        ))}
      </div>

      {/* New visit bottom sheet */}
      {showNewVisitSheet && (
        <>
          <div style={{ position: 'absolute', inset: 0, background: 'rgba(10,31,92,0.55)', zIndex: 10 }} />
          <div style={{
            position: 'absolute', bottom: 0, left: 0, right: 0, zIndex: 11,
            background: '#fff', borderRadius: '20px 20px 0 0',
            boxShadow: '0 -12px 40px rgba(10,31,92,0.25)',
            padding: '10px 0 24px',
            display: 'flex', flexDirection: 'column',
          }}>
            <div style={{ display: 'flex', justifyContent: 'center' }}>
              <div style={{ width: 40, height: 5, borderRadius: 3, background: AdmColors.n300 }} />
            </div>
            <div style={{ padding: '14px 18px 8px', display: 'flex', alignItems: 'center', gap: 12 }}>
              <div style={{ width: 36, height: 36, borderRadius: 10, background: AdmColors.lime, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <AIcon name="event_available" size={20} color="#fff" />
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontFamily: 'Poppins', fontSize: 17, fontWeight: 700, color: AdmColors.navy }}>Nova visita agendada</div>
                <div style={{ fontSize: 11.5, color: AdmColors.n500 }}>Preencha os campos abaixo</div>
              </div>
              <button style={{ width: 32, height: 32, borderRadius: '50%', background: AdmColors.n100, border: 0 }}>
                <AIcon name="close" size={18} color={AdmColors.n600} />
              </button>
            </div>
            <div style={{ padding: '10px 18px 14px', display: 'flex', flexDirection: 'column', gap: 14 }}>
              <IField label="Instituição" required>
                <IAutocomplete value="Hospital São Luiz" onChange={() => {}}
                  options={['Hospital São Luiz','Hospital Sírio-Libanês','Hospital Einstein']} />
              </IField>
              <div style={{ display: 'grid', gridTemplateColumns: '1.2fr 1fr', gap: 10 }}>
                <IField label="Data" required>
                  <div style={{ height: 42, borderRadius: 10, padding: '0 12px', border: `1.5px solid ${AdmColors.n300}`, background: '#fff', display: 'flex', alignItems: 'center', gap: 8 }}>
                    <AIcon name="calendar_today" size={16} color={AdmColors.n500} />
                    <span style={{ fontFamily: 'JetBrains Mono', fontSize: 13.5, color: AdmColors.navy, fontWeight: 600 }}>22/04/2026</span>
                  </div>
                </IField>
                <IField label="Horário" required>
                  <div style={{ height: 42, borderRadius: 10, padding: '0 12px', border: `1.5px solid ${AdmColors.n300}`, background: '#fff', display: 'flex', alignItems: 'center', gap: 8 }}>
                    <AIcon name="schedule" size={16} color={AdmColors.n500} />
                    <span style={{ fontFamily: 'JetBrains Mono', fontSize: 13.5, color: AdmColors.navy, fontWeight: 600 }}>15:00</span>
                  </div>
                </IField>
              </div>
              <IField label="Objetivo planejado" hint="Ajuda a equipe a se preparar">
                <div style={{ borderRadius: 10, padding: 12, border: `1.5px solid ${AdmColors.n300}`, background: '#fff', minHeight: 70 }}>
                  <div style={{ fontSize: 13.5, color: AdmColors.navy, lineHeight: 1.5 }}>
                    Revisão trimestral de consumo. Apresentar novos itens e discutir pedido de amostras com equipe EMTN.
                  </div>
                </div>
              </IField>
              <button style={{ width: '100%', height: 52, borderRadius: 9999, background: AdmColors.lime, color: '#fff', border: 0, fontSize: 15, fontWeight: 700, fontFamily: 'Inter', boxShadow: '0 4px 12px rgba(139,198,63,0.28)', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 8, marginTop: 4 }}>
                <span className="material-symbols-rounded" style={{ fontSize: 20 }}>event_available</span>
                Agendar visita
              </button>
            </div>
          </div>
        </>
      )}
    </div>
  );
}

Object.assign(window, { AgendaDesktop, AgendaMobile });
