/* eslint-disable */
// Tela 1 — Cadastro de Instituição
// Versão DESKTOP (1440x900) em tela cheia + versão MOBILE (390x844) empilhada

// ──────────────────────── helpers ────────────────────────
function maskCNPJ(v) {
  const d = (v || '').replace(/\D/g, '').slice(0, 14);
  return d
    .replace(/^(\d{2})(\d)/, '$1.$2')
    .replace(/^(\d{2})\.(\d{3})(\d)/, '$1.$2.$3')
    .replace(/\.(\d{3})(\d)/, '.$1/$2')
    .replace(/(\d{4})(\d)/, '$1-$2');
}
function maskPhone(v) {
  const d = (v || '').replace(/\D/g, '').slice(0, 11);
  if (d.length <= 2) return d;
  if (d.length <= 7) return `(${d.slice(0,2)}) ${d.slice(2)}`;
  return `(${d.slice(0,2)}) ${d.slice(2,7)}-${d.slice(7)}`;
}
function maskCEP(v) {
  const d = (v || '').replace(/\D/g, '').slice(0, 8);
  if (d.length <= 5) return d;
  return `${d.slice(0,5)}-${d.slice(5)}`;
}

// ──────────────────────── Form primitives ────────────────────────
function IField({ label, required, children, hint, error, half, mono, grow = 1 }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 6, flex: grow, minWidth: 0 }}>
      <label style={{ fontSize: 12.5, fontWeight: 600, color: AdmColors.navy, display: 'flex', alignItems: 'center', gap: 4 }}>
        {label}
        {required && <span style={{ color: AdmColors.danger, fontWeight: 700 }}>*</span>}
      </label>
      {children}
      {hint && !error && <div style={{ fontSize: 11.5, color: AdmColors.n500 }}>{hint}</div>}
      {error && <div style={{ fontSize: 11.5, color: AdmColors.danger, display: 'flex', alignItems: 'center', gap: 4 }}>
        <AIcon name="error" size={12} /> {error}
      </div>}
    </div>
  );
}

function ITextInput({ value, onChange, placeholder, icon, mono, suffix, type = 'text' }) {
  const [focus, setFocus] = React.useState(false);
  return (
    <div style={{
      height: 42, borderRadius: 10, padding: '0 12px',
      border: `1.5px solid ${focus ? AdmColors.lime : AdmColors.n300}`,
      boxShadow: focus ? '0 0 0 3px rgba(139,198,63,0.22)' : 'none',
      background: '#fff', display: 'flex', alignItems: 'center', gap: 8,
      transition: 'all 120ms',
    }}>
      {icon && <AIcon name={icon} size={17} color={AdmColors.n500} />}
      <input type={type} placeholder={placeholder} value={value || ''} onChange={onChange}
        onFocus={() => setFocus(true)} onBlur={() => setFocus(false)}
        style={{
          flex: 1, border: 0, outline: 0, fontSize: 14, background: 'transparent',
          fontFamily: mono ? 'JetBrains Mono, monospace' : 'Inter, sans-serif',
          color: AdmColors.navy, minWidth: 0,
        }} />
      {suffix}
    </div>
  );
}

function ISelect({ value, onChange, options, placeholder }) {
  const [focus, setFocus] = React.useState(false);
  return (
    <div style={{
      height: 42, borderRadius: 10, padding: '0 12px',
      border: `1.5px solid ${focus ? AdmColors.lime : AdmColors.n300}`,
      background: '#fff', display: 'flex', alignItems: 'center', gap: 8,
      position: 'relative',
    }}>
      <select value={value || ''} onChange={onChange}
        onFocus={() => setFocus(true)} onBlur={() => setFocus(false)}
        style={{
          flex: 1, border: 0, outline: 0, fontSize: 14, background: 'transparent',
          fontFamily: 'Inter', color: value ? AdmColors.navy : AdmColors.n500,
          appearance: 'none', WebkitAppearance: 'none', cursor: 'pointer',
        }}>
        {placeholder && <option value="">{placeholder}</option>}
        {options.map(o => <option key={o.v || o} value={o.v || o}>{o.l || o}</option>)}
      </select>
      <AIcon name="expand_more" size={18} color={AdmColors.n500} />
    </div>
  );
}

function IToggle({ checked, onChange, label, size = 'md' }) {
  const w = size === 'sm' ? 34 : 42;
  const h = size === 'sm' ? 20 : 24;
  const d = size === 'sm' ? 14 : 18;
  return (
    <label style={{ display: 'inline-flex', alignItems: 'center', gap: 10, cursor: 'pointer', userSelect: 'none' }}>
      <div onClick={() => onChange(!checked)}
        style={{
          width: w, height: h, borderRadius: 9999,
          background: checked ? AdmColors.lime : AdmColors.n300,
          position: 'relative', transition: 'all 160ms',
        }}>
        <div style={{
          position: 'absolute', top: (h - d) / 2, left: checked ? w - d - (h - d) / 2 : (h - d) / 2,
          width: d, height: d, borderRadius: '50%', background: '#fff',
          boxShadow: '0 1px 3px rgba(0,0,0,0.2)', transition: 'all 160ms',
        }} />
      </div>
      {label && <span style={{ fontSize: 13.5, color: AdmColors.navy, fontWeight: 500 }}>{label}</span>}
    </label>
  );
}

// ──────────────────────── Stepper ────────────────────────
function Stepper({ current, setCurrent, steps, orientation = 'h' }) {
  if (orientation === 'v') {
    return (
      <div style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
        {steps.map((s, i) => {
          const done = i < current;
          const active = i === current;
          return (
            <button key={s.id} onClick={() => setCurrent(i)} style={{
              display: 'flex', alignItems: 'center', gap: 12, padding: '10px 12px',
              background: active ? AdmColors.navy50 : 'transparent',
              border: 0, borderRadius: 10, cursor: 'pointer', textAlign: 'left',
              fontFamily: 'Inter', width: '100%',
            }}>
              <div style={{
                width: 28, height: 28, borderRadius: '50%',
                background: active ? AdmColors.lime : done ? AdmColors.success : AdmColors.n200,
                color: active || done ? '#fff' : AdmColors.n600,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontSize: 12, fontWeight: 700, flexShrink: 0,
              }}>
                {done ? <AIcon name="check" size={16} /> : i + 1}
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 13, fontWeight: active ? 700 : 600, color: AdmColors.navy }}>{s.label}</div>
                <div style={{ fontSize: 11.5, color: AdmColors.n500 }}>{s.sub}</div>
              </div>
            </button>
          );
        })}
      </div>
    );
  }
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 0, padding: '20px 28px', background: '#fff', borderBottom: `1px solid ${AdmColors.n200}` }}>
      {steps.map((s, i) => {
        const done = i < current;
        const active = i === current;
        return (
          <React.Fragment key={s.id}>
            <button onClick={() => setCurrent(i)} style={{
              display: 'flex', alignItems: 'center', gap: 10, padding: '6px 10px',
              background: 'transparent', border: 0, cursor: 'pointer', fontFamily: 'Inter',
            }}>
              <div style={{
                width: 32, height: 32, borderRadius: '50%',
                background: active ? AdmColors.lime : done ? AdmColors.success : AdmColors.n200,
                color: active || done ? '#fff' : AdmColors.n600,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontSize: 13, fontWeight: 700, flexShrink: 0,
                boxShadow: active ? '0 0 0 4px rgba(139,198,63,0.18)' : 'none',
              }}>
                {done ? <AIcon name="check" size={18} /> : <AIcon name={s.icon} size={16} color={active || done ? '#fff' : AdmColors.n500} />}
              </div>
              <div style={{ textAlign: 'left' }}>
                <div style={{ fontSize: 10.5, fontWeight: 600, color: AdmColors.n500, textTransform: 'uppercase', letterSpacing: '0.05em' }}>Seção {i + 1}</div>
                <div style={{ fontSize: 13.5, fontWeight: active ? 700 : 600, color: active || done ? AdmColors.navy : AdmColors.n500 }}>{s.label}</div>
              </div>
            </button>
            {i < steps.length - 1 && (
              <div style={{ flex: 1, height: 2, background: done ? AdmColors.success : AdmColors.n200, margin: '0 8px', borderRadius: 2 }} />
            )}
          </React.Fragment>
        );
      })}
    </div>
  );
}

// ──────────────────────── Mini map ────────────────────────
function MiniMap({ hasCoords }) {
  return (
    <div style={{
      position: 'relative', borderRadius: 12, overflow: 'hidden',
      height: 200, background: hasCoords ? '#E6EDF5' : AdmColors.n100,
      border: `1px solid ${AdmColors.n200}`,
    }}>
      {hasCoords ? (
        <>
          {/* faux map */}
          <svg width="100%" height="100%" viewBox="0 0 400 200" preserveAspectRatio="xMidYMid slice">
            <rect width="400" height="200" fill="#E8EEF5" />
            {/* streets */}
            <path d="M0 60 L400 80" stroke="#fff" strokeWidth="8" />
            <path d="M0 140 L400 120" stroke="#fff" strokeWidth="6" />
            <path d="M80 0 L120 200" stroke="#fff" strokeWidth="10" />
            <path d="M240 0 L280 200" stroke="#fff" strokeWidth="6" />
            <path d="M340 0 L360 200" stroke="#fff" strokeWidth="4" />
            {/* parks */}
            <rect x="140" y="20" width="80" height="35" rx="6" fill="#D6E7C5" />
            <rect x="290" y="135" width="70" height="50" rx="6" fill="#D6E7C5" />
            {/* buildings */}
            <rect x="20" y="80" width="50" height="55" fill="#DCE3EE" />
            <rect x="160" y="95" width="70" height="40" fill="#DCE3EE" />
            <rect x="300" y="45" width="45" height="75" fill="#DCE3EE" />
          </svg>
          {/* pin */}
          <div style={{ position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%, -100%)' }}>
            <svg width="32" height="40" viewBox="0 0 32 40">
              <path d="M16 0C7.2 0 0 7 0 15.7 0 27 16 40 16 40s16-13 16-24.3C32 7 24.8 0 16 0z" fill={AdmColors.lime} />
              <circle cx="16" cy="15" r="5.5" fill="#fff" />
            </svg>
          </div>
          <div style={{
            position: 'absolute', bottom: 10, left: 10, right: 10,
            background: 'rgba(255,255,255,0.95)', borderRadius: 8, padding: '8px 12px',
            fontSize: 12, display: 'flex', gap: 14,
          }}>
            <span style={{ fontFamily: 'JetBrains Mono', color: AdmColors.navy, fontWeight: 600 }}>
              −23.5505, −46.6333
            </span>
            <span style={{ color: AdmColors.n500 }}>· precisão ±8m</span>
          </div>
        </>
      ) : (
        <div style={{ height: '100%', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 10, color: AdmColors.n500 }}>
          <AIcon name="map" size={32} color={AdmColors.n400} />
          <div style={{ fontSize: 13 }}>Coordenadas aparecerão aqui após captura</div>
        </div>
      )}
    </div>
  );
}

// ──────────────────────── Sections ────────────────────────
function SectionIdentification({ form, set }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
        <IField label="Nome fantasia" required>
          <ITextInput value={form.nomeFantasia} onChange={e => set('nomeFantasia', e.target.value)} placeholder="Ex: Hospital São Camilo" />
        </IField>
        <IField label="Razão social" required>
          <ITextInput value={form.razao} onChange={e => set('razao', e.target.value)} placeholder="Razão social completa" />
        </IField>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
        <IField label="CNPJ" required hint="Formato: 00.000.000/0000-00">
          <ITextInput value={form.cnpj} onChange={e => set('cnpj', maskCNPJ(e.target.value))} placeholder="00.000.000/0000-00" mono icon="badge" />
        </IField>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8, paddingTop: 2 }}>
          <label style={{ fontSize: 12.5, fontWeight: 600, color: AdmColors.navy }}>Status da instituição</label>
          <div style={{ height: 42, display: 'flex', alignItems: 'center', gap: 12, padding: '0 14px', background: form.ativa ? AdmColors.lime50 || '#F4F9EA' : AdmColors.n100, borderRadius: 10, border: `1.5px solid ${form.ativa ? AdmColors.lime : AdmColors.n300}` }}>
            <IToggle checked={form.ativa} onChange={v => set('ativa', v)} />
            <span style={{ fontSize: 14, fontWeight: 600, color: form.ativa ? AdmColors.navy : AdmColors.n600 }}>
              {form.ativa ? 'Ativa' : 'Inativa'}
            </span>
            <span style={{ marginLeft: 'auto', fontSize: 11.5, color: AdmColors.n500 }}>
              {form.ativa ? 'Recebe visitas' : 'Não agenda novas visitas'}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}

function SectionAddress({ form, set }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      <div style={{ display: 'grid', gridTemplateColumns: '180px 1fr', gap: 16 }}>
        <IField label="CEP" required>
          <ITextInput value={form.cep} onChange={e => set('cep', maskCEP(e.target.value))} placeholder="00000-000" mono
            suffix={
              <button onClick={() => set('cepFilled', true)} style={{ height: 28, borderRadius: 9999, padding: '0 10px', background: AdmColors.navy50, color: AdmColors.navy, border: 0, fontSize: 11.5, fontWeight: 600, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 4, fontFamily: 'Inter' }}>
                <AIcon name="search" size={13} /> Buscar
              </button>
            } />
        </IField>
        <IField label="Logradouro" required>
          <ITextInput value={form.log} onChange={e => set('log', e.target.value)} placeholder="Rua, avenida, alameda…" />
        </IField>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: '120px 1fr 1fr', gap: 16 }}>
        <IField label="Número">
          <ITextInput value={form.num} onChange={e => set('num', e.target.value)} placeholder="Nº" />
        </IField>
        <IField label="Complemento">
          <ITextInput value={form.compl} onChange={e => set('compl', e.target.value)} placeholder="Sala, bloco, andar…" />
        </IField>
        <IField label="Bairro" required>
          <ITextInput value={form.bairro} onChange={e => set('bairro', e.target.value)} placeholder="Bairro" />
        </IField>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: '2fr 120px', gap: 16 }}>
        <IField label="Cidade" required>
          <ITextInput value={form.cidade} onChange={e => set('cidade', e.target.value)} placeholder="Cidade" />
        </IField>
        <IField label="Estado" required>
          <ISelect value={form.uf} onChange={e => set('uf', e.target.value)} placeholder="UF"
            options={['AC','AL','AM','AP','BA','CE','DF','ES','GO','MA','MG','MS','MT','PA','PB','PE','PI','PR','RJ','RN','RO','RR','RS','SC','SE','SP','TO']} />
        </IField>
      </div>
      {/* GPS coords */}
      <div style={{ marginTop: 8, padding: 20, background: AdmColors.n50, borderRadius: 12, border: `1px dashed ${AdmColors.n300}` }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 4 }}>
          <AIcon name="my_location" size={18} color={AdmColors.navy} />
          <div style={{ fontFamily: 'Poppins', fontWeight: 600, fontSize: 15, color: AdmColors.navy }}>Coordenadas GPS</div>
        </div>
        <div style={{ fontSize: 12.5, color: AdmColors.n500, marginBottom: 16 }}>
          Usadas para validar o raio de check-in dos nutricionistas em campo.
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 16 }}>
          <div style={{ background: '#fff', borderRadius: 10, padding: 14, border: `1px solid ${AdmColors.n200}` }}>
            <div style={{ fontSize: 11, fontWeight: 700, color: AdmColors.n500, textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: 6 }}>Latitude</div>
            <div style={{ fontFamily: 'JetBrains Mono', fontSize: 18, fontWeight: 600, color: form.lat ? AdmColors.navy : AdmColors.n400 }}>
              {form.lat || '—'}
            </div>
          </div>
          <div style={{ background: '#fff', borderRadius: 10, padding: 14, border: `1px solid ${AdmColors.n200}` }}>
            <div style={{ fontSize: 11, fontWeight: 700, color: AdmColors.n500, textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: 6 }}>Longitude</div>
            <div style={{ fontFamily: 'JetBrains Mono', fontSize: 18, fontWeight: 600, color: form.lng ? AdmColors.navy : AdmColors.n400 }}>
              {form.lng || '—'}
            </div>
          </div>
        </div>

        <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', marginBottom: 16 }}>
          <button onClick={() => { set('lat', '−23.5505'); set('lng', '−46.6333'); }}
            style={{ height: 38, padding: '0 14px', background: AdmColors.navy, color: '#fff', border: 0, borderRadius: 9999, fontSize: 13, fontWeight: 600, cursor: 'pointer', display: 'inline-flex', alignItems: 'center', gap: 6, fontFamily: 'Inter' }}>
            <AIcon name="location_searching" size={16} />
            Capturar via endereço
          </button>
          <button onClick={() => { set('lat', '−23.5509'); set('lng', '−46.6340'); }}
            style={{ height: 38, padding: '0 14px', background: '#fff', color: AdmColors.navy, border: `1.5px solid ${AdmColors.navy}`, borderRadius: 9999, fontSize: 13, fontWeight: 600, cursor: 'pointer', display: 'inline-flex', alignItems: 'center', gap: 6, fontFamily: 'Inter' }}>
            <AIcon name="gps_fixed" size={16} />
            Capturar GPS atual
          </button>
          <div style={{ marginLeft: 'auto', fontSize: 11.5, color: AdmColors.n500, display: 'flex', alignItems: 'center', gap: 4 }}>
            <AIcon name="info" size={13} /> Use "GPS atual" só se estiver no local
          </div>
        </div>

        <MiniMap hasCoords={!!form.lat} />
      </div>
    </div>
  );
}

function NumInput({ value, onChange, placeholder }) {
  const [focus, setFocus] = React.useState(false);
  return (
    <div style={{
      height: 42, borderRadius: 10, padding: '0 12px',
      border: `1.5px solid ${focus ? AdmColors.lime : AdmColors.n300}`,
      boxShadow: focus ? '0 0 0 3px rgba(139,198,63,0.22)' : 'none',
      background: '#fff', display: 'flex', alignItems: 'center', gap: 8,
    }}>
      <input type="number" placeholder={placeholder || '0'} value={value || ''} onChange={onChange}
        onFocus={() => setFocus(true)} onBlur={() => setFocus(false)}
        style={{ flex: 1, border: 0, outline: 0, fontSize: 15, background: 'transparent',
          fontFamily: 'JetBrains Mono, monospace', fontWeight: 600,
          color: AdmColors.navy, minWidth: 0 }} />
    </div>
  );
}

function SectionStructure({ form, set }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 24 }}>
      <div>
        <div style={{ fontSize: 11, fontWeight: 700, color: AdmColors.n500, textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 10 }}>Leitos</div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 16 }}>
          <IField label="Leitos total" required>
            <NumInput value={form.leitos} onChange={e => set('leitos', e.target.value)} placeholder="Ex: 320" />
          </IField>
          <IField label="UTI Adulto">
            <NumInput value={form.utiA} onChange={e => set('utiA', e.target.value)} />
          </IField>
          <IField label="UTI Pediátrica">
            <NumInput value={form.utiP} onChange={e => set('utiP', e.target.value)} />
          </IField>
        </div>
      </div>

      <div style={{ padding: 16, background: AdmColors.n50, borderRadius: 12, border: `1px solid ${AdmColors.n200}` }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 16 }}>
          <div>
            <div style={{ fontSize: 14, fontWeight: 600, color: AdmColors.navy, display: 'flex', alignItems: 'center', gap: 8 }}>
              <AIcon name="surgical" size={18} color={AdmColors.navy} />
              Hospital cirúrgico?
            </div>
            <div style={{ fontSize: 12, color: AdmColors.n500, marginTop: 2 }}>Ativa o campo "Salas cirúrgicas"</div>
          </div>
          <IToggle checked={form.cirurgico} onChange={v => set('cirurgico', v)} label={form.cirurgico ? 'Sim' : 'Não'} />
        </div>
        {form.cirurgico && (
          <div style={{ marginTop: 14, paddingTop: 14, borderTop: `1px solid ${AdmColors.n200}`, display: 'grid', gridTemplateColumns: '200px 1fr', gap: 16, alignItems: 'end' }}>
            <IField label="Salas cirúrgicas">
              <NumInput value={form.salas} onChange={e => set('salas', e.target.value)} placeholder="Ex: 8" />
            </IField>
          </div>
        )}
      </div>

      <div>
        <div style={{ fontSize: 11, fontWeight: 700, color: AdmColors.n500, textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 10 }}>Equipe de nutrição da instituição</div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 16 }}>
          <IField label="Nutricionistas total" required>
            <NumInput value={form.nutT} onChange={e => set('nutT', e.target.value)} placeholder="Ex: 14" />
          </IField>
          <IField label="Clínicos">
            <NumInput value={form.nutC} onChange={e => set('nutC', e.target.value)} />
          </IField>
          <IField label="EMTN">
            <NumInput value={form.nutE} onChange={e => set('nutE', e.target.value)} />
          </IField>
        </div>
      </div>
    </div>
  );
}

function SectionContact({ form, set }) {
  const emailOk = form.email && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email);
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      <div style={{ padding: 14, background: AdmColors.navy50, borderRadius: 10, fontSize: 13, color: AdmColors.navy, display: 'flex', gap: 10, alignItems: 'flex-start' }}>
        <AIcon name="badge" size={18} color={AdmColors.navy} />
        <div>
          <b>Supervisor da instituição:</b> pessoa responsável por autorizar as visitas
          dos nutricionistas. Recebe confirmações por e-mail.
        </div>
      </div>
      <IField label="Nome completo do supervisor" required>
        <ITextInput value={form.supNome} onChange={e => set('supNome', e.target.value)} placeholder="Nome e sobrenome" icon="person" />
      </IField>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
        <IField label="Telefone" required hint="Formato: (XX) XXXXX-XXXX">
          <ITextInput value={form.supTel} onChange={e => set('supTel', maskPhone(e.target.value))} placeholder="(00) 00000-0000" mono icon="call" />
        </IField>
        <IField label="E-mail" required error={form.email && !emailOk ? 'E-mail inválido' : null}>
          <ITextInput value={form.email} onChange={e => set('email', e.target.value)} placeholder="supervisor@hospital.com.br" icon="mail"
            suffix={form.email ? (
              <AIcon name={emailOk ? 'check_circle' : 'error'} size={18}
                color={emailOk ? AdmColors.success : AdmColors.danger} />
            ) : null} />
        </IField>
      </div>
    </div>
  );
}

// ──────────────────────── Desktop Screen ────────────────────────
function NewInstitutionDesktop() {
  const [step, setStep] = React.useState(0);
  const [form, setForm] = React.useState({
    nomeFantasia: 'Hospital São Camilo',
    razao: 'Soc. Benef. São Camilo Unidade Pompeia S/A',
    cnpj: '12.345.678/0001-90',
    ativa: true,
    cep: '05002-000', log: 'Rua Apinajés', num: '1285', compl: '',
    bairro: 'Perdizes', cidade: 'São Paulo', uf: 'SP',
    lat: '−23.5505', lng: '−46.6333',
    leitos: '320', utiA: '32', utiP: '12', cirurgico: true, salas: '8',
    nutT: '14', nutC: '10', nutE: '4',
    supNome: 'Dra. Mariana Fontes', supTel: '(11) 98765-4321', email: 'mariana.fontes@saocamilo.com.br',
  });
  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));

  const steps = [
    { id: 'id', label: 'Identificação', icon: 'badge', sub: 'Dados legais e fiscais' },
    { id: 'addr', label: 'Endereço', icon: 'location_on', sub: 'Localização e GPS' },
    { id: 'struct', label: 'Estrutura', icon: 'apartment', sub: 'Leitos e equipe' },
    { id: 'contact', label: 'Contato', icon: 'person', sub: 'Supervisor responsável' },
  ];

  return (
    <div style={{ display: 'flex', height: '100%', background: AdmColors.n50, fontFamily: 'Inter, sans-serif' }}>
      <Sidebar active="institutions" onChange={() => {}} />
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', minWidth: 0 }}>
        {/* Page header */}
        <div style={{ padding: '20px 28px', background: '#fff', borderBottom: `1px solid ${AdmColors.n200}`, display: 'flex', alignItems: 'center', gap: 20 }}>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 12, color: AdmColors.n500, display: 'flex', alignItems: 'center', gap: 6 }}>
              <AIcon name="apartment" size={13} />
              <span>Instituições</span>
              <AIcon name="chevron_right" size={13} />
              <span style={{ color: AdmColors.navy, fontWeight: 600 }}>Nova</span>
            </div>
            <div style={{ fontFamily: 'Poppins', fontSize: 22, fontWeight: 700, color: AdmColors.navy, marginTop: 4 }}>Nova instituição</div>
          </div>
          <AButton variant="secondary" icon="close">Cancelar</AButton>
          <AButton variant="primary" icon="check">Salvar instituição</AButton>
        </div>

        {/* Stepper */}
        <Stepper current={step} setCurrent={setStep} steps={steps} />

        {/* Form body */}
        <div style={{ flex: 1, overflow: 'auto', padding: '28px' }}>
          <div style={{ maxWidth: 900, margin: '0 auto', background: '#fff', borderRadius: 12, boxShadow: '0 2px 8px rgba(10,31,92,0.05)' }}>
            <div style={{ padding: '22px 28px 12px', borderBottom: `1px solid ${AdmColors.n100}`, display: 'flex', alignItems: 'center', gap: 10 }}>
              <div style={{ width: 36, height: 36, borderRadius: 10, background: AdmColors.lime, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <AIcon name={steps[step].icon} size={20} color="#fff" />
              </div>
              <div>
                <div style={{ fontFamily: 'Poppins', fontSize: 17, fontWeight: 700, color: AdmColors.navy }}>{steps[step].label}</div>
                <div style={{ fontSize: 12.5, color: AdmColors.n500 }}>{steps[step].sub}</div>
              </div>
              <div style={{ marginLeft: 'auto', fontSize: 12, color: AdmColors.n500 }}>
                <span style={{ color: AdmColors.danger }}>*</span> obrigatório
              </div>
            </div>
            <div style={{ padding: 28 }}>
              {step === 0 && <SectionIdentification form={form} set={set} />}
              {step === 1 && <SectionAddress form={form} set={set} />}
              {step === 2 && <SectionStructure form={form} set={set} />}
              {step === 3 && <SectionContact form={form} set={set} />}
            </div>
            <div style={{ padding: '18px 28px', borderTop: `1px solid ${AdmColors.n100}`, background: AdmColors.n50, display: 'flex', alignItems: 'center', gap: 12, borderRadius: '0 0 12px 12px' }}>
              <AButton variant="secondary" icon="arrow_back" onClick={() => setStep(Math.max(0, step - 1))}>
                Voltar
              </AButton>
              <div style={{ flex: 1, fontSize: 12, color: AdmColors.n500 }}>
                Passo {step + 1} de {steps.length}
              </div>
              {step < steps.length - 1 ? (
                <AButton variant="primary" icon="arrow_forward" onClick={() => setStep(step + 1)}>Próximo</AButton>
              ) : (
                <AButton variant="primary" icon="check">Salvar instituição</AButton>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ──────────────────────── Mobile Screen ────────────────────────
function NewInstitutionMobile() {
  const [openSections, setOpenSections] = React.useState({ 0: true, 1: false, 2: false, 3: false });
  const toggle = (i) => setOpenSections(o => ({ ...o, [i]: !o[i] }));
  const [form, setForm] = React.useState({
    nomeFantasia: 'Hospital São Camilo', razao: '', cnpj: '12.345.678/0001-90', ativa: true,
    cep: '05002-000', log: 'Rua Apinajés', num: '1285', bairro: 'Perdizes', cidade: 'São Paulo', uf: 'SP',
    lat: '−23.5505', lng: '−46.6333',
    leitos: '320', utiA: '32', utiP: '12', cirurgico: true, salas: '8',
    nutT: '14', nutC: '10', nutE: '4',
    supNome: 'Dra. Mariana Fontes', supTel: '(11) 98765-4321', email: 'mariana.fontes@saocamilo.com.br',
  });
  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));

  const secs = [
    { id: 'id', label: 'Identificação', icon: 'badge', count: '4 campos' },
    { id: 'addr', label: 'Endereço', icon: 'location_on', count: '7 + GPS' },
    { id: 'struct', label: 'Estrutura', icon: 'apartment', count: '7 campos' },
    { id: 'contact', label: 'Contato', icon: 'person', count: '3 campos' },
  ];

  return (
    <div style={{ background: '#F3F5FA', height: '100%', overflow: 'auto', fontFamily: 'Inter' }}>
      {/* Top navy header */}
      <div style={{ background: AdmColors.navy, color: '#fff', padding: '14px 16px 16px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 8 }}>
          <AIcon name="arrow_back" size={22} color="#fff" />
          <div style={{ fontSize: 12, opacity: 0.7 }}>Instituições › Nova</div>
        </div>
        <div style={{ fontFamily: 'Poppins', fontSize: 22, fontWeight: 700 }}>Nova instituição</div>
        <div style={{ fontSize: 12, opacity: 0.75, marginTop: 4 }}>4 seções · ~3 min para completar</div>
      </div>
      {/* Progress bar */}
      <div style={{ background: AdmColors.navy800, height: 3 }}>
        <div style={{ width: '75%', height: '100%', background: AdmColors.lime }} />
      </div>

      {/* Accordion sections */}
      <div style={{ padding: 12, display: 'flex', flexDirection: 'column', gap: 10 }}>
        {secs.map((s, i) => {
          const open = openSections[i];
          return (
            <div key={s.id} style={{ background: '#fff', borderRadius: 12, boxShadow: '0 2px 8px rgba(10,31,92,0.05)', overflow: 'hidden' }}>
              <button onClick={() => toggle(i)} style={{
                width: '100%', background: 'transparent', border: 0, padding: '14px 16px',
                display: 'flex', alignItems: 'center', gap: 12, cursor: 'pointer', textAlign: 'left', fontFamily: 'Inter',
              }}>
                <div style={{ width: 34, height: 34, borderRadius: '50%', background: open ? AdmColors.lime : AdmColors.navy50, color: open ? '#fff' : AdmColors.navy, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                  <AIcon name={s.icon} size={18} />
                </div>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 10.5, fontWeight: 700, color: AdmColors.n500, textTransform: 'uppercase', letterSpacing: '0.05em' }}>Seção {i + 1} · {s.count}</div>
                  <div style={{ fontFamily: 'Poppins', fontSize: 15, fontWeight: 600, color: AdmColors.navy }}>{s.label}</div>
                </div>
                {i < 2 && <AIcon name="check_circle" size={18} color={AdmColors.success} />}
                <AIcon name={open ? 'expand_less' : 'expand_more'} size={22} color={AdmColors.n500} />
              </button>
              {open && (
                <div style={{ padding: '8px 16px 18px', borderTop: `1px solid ${AdmColors.n100}` }}>
                  {i === 0 && (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: 14, paddingTop: 10 }}>
                      <IField label="Nome fantasia" required>
                        <ITextInput value={form.nomeFantasia} onChange={e => set('nomeFantasia', e.target.value)} placeholder="Hospital…" />
                      </IField>
                      <IField label="Razão social" required>
                        <ITextInput value={form.razao} onChange={e => set('razao', e.target.value)} placeholder="Razão social" />
                      </IField>
                      <IField label="CNPJ" required>
                        <ITextInput value={form.cnpj} onChange={e => set('cnpj', maskCNPJ(e.target.value))} mono placeholder="00.000.000/0000-00" />
                      </IField>
                      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '10px 12px', background: AdmColors.lime50 || '#F4F9EA', borderRadius: 10, border: `1px solid ${AdmColors.lime}` }}>
                        <div>
                          <div style={{ fontSize: 13.5, fontWeight: 600, color: AdmColors.navy }}>Instituição ativa</div>
                          <div style={{ fontSize: 11.5, color: AdmColors.n600 }}>Recebe visitas</div>
                        </div>
                        <IToggle checked={form.ativa} onChange={v => set('ativa', v)} />
                      </div>
                    </div>
                  )}
                  {i === 1 && (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: 14, paddingTop: 10 }}>
                      <IField label="CEP" required>
                        <ITextInput value={form.cep} onChange={e => set('cep', maskCEP(e.target.value))} mono placeholder="00000-000"
                          suffix={<button style={{ height: 26, borderRadius: 9999, padding: '0 10px', background: AdmColors.navy50, color: AdmColors.navy, border: 0, fontSize: 11, fontWeight: 600, fontFamily: 'Inter' }}>Buscar</button>} />
                      </IField>
                      <IField label="Logradouro" required>
                        <ITextInput value={form.log} onChange={e => set('log', e.target.value)} placeholder="Rua, avenida…" />
                      </IField>
                      <div style={{ display: 'grid', gridTemplateColumns: '100px 1fr', gap: 10 }}>
                        <IField label="Número"><ITextInput value={form.num} onChange={e => set('num', e.target.value)} placeholder="Nº" /></IField>
                        <IField label="Bairro" required><ITextInput value={form.bairro} onChange={e => set('bairro', e.target.value)} placeholder="Bairro" /></IField>
                      </div>
                      <div style={{ display: 'grid', gridTemplateColumns: '1fr 80px', gap: 10 }}>
                        <IField label="Cidade" required><ITextInput value={form.cidade} onChange={e => set('cidade', e.target.value)} placeholder="Cidade" /></IField>
                        <IField label="UF" required><ISelect value={form.uf} onChange={e => set('uf', e.target.value)} options={['SP','RJ','MG','PR','RS','SC','BA','PE','CE','DF']} /></IField>
                      </div>
                      <div style={{ padding: 12, background: AdmColors.n50, borderRadius: 10, border: `1px dashed ${AdmColors.n300}` }}>
                        <div style={{ fontSize: 11, fontWeight: 700, color: AdmColors.n500, textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: 8 }}>GPS</div>
                        <div style={{ display: 'flex', gap: 8, marginBottom: 10 }}>
                          <div style={{ flex: 1, background: '#fff', borderRadius: 8, padding: 10, border: `1px solid ${AdmColors.n200}` }}>
                            <div style={{ fontSize: 10, color: AdmColors.n500, fontWeight: 600 }}>LAT</div>
                            <div style={{ fontFamily: 'JetBrains Mono', fontSize: 13, color: AdmColors.navy, fontWeight: 600 }}>{form.lat}</div>
                          </div>
                          <div style={{ flex: 1, background: '#fff', borderRadius: 8, padding: 10, border: `1px solid ${AdmColors.n200}` }}>
                            <div style={{ fontSize: 10, color: AdmColors.n500, fontWeight: 600 }}>LNG</div>
                            <div style={{ fontFamily: 'JetBrains Mono', fontSize: 13, color: AdmColors.navy, fontWeight: 600 }}>{form.lng}</div>
                          </div>
                        </div>
                        <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                          <button style={{ height: 38, borderRadius: 9999, background: AdmColors.navy, color: '#fff', border: 0, fontSize: 12.5, fontWeight: 600, fontFamily: 'Inter' }}>Capturar via endereço</button>
                          <button style={{ height: 38, borderRadius: 9999, background: '#fff', color: AdmColors.navy, border: `1.5px solid ${AdmColors.navy}`, fontSize: 12.5, fontWeight: 600, fontFamily: 'Inter' }}>Usar GPS atual</button>
                        </div>
                      </div>
                    </div>
                  )}
                  {i === 2 && (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: 14, paddingTop: 10 }}>
                      <IField label="Leitos total" required><NumInput value={form.leitos} onChange={e => set('leitos', e.target.value)} /></IField>
                      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
                        <IField label="UTI Adulto"><NumInput value={form.utiA} onChange={e => set('utiA', e.target.value)} /></IField>
                        <IField label="UTI Pediátrica"><NumInput value={form.utiP} onChange={e => set('utiP', e.target.value)} /></IField>
                      </div>
                      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: 10, background: AdmColors.n50, borderRadius: 10 }}>
                        <div style={{ fontSize: 13, fontWeight: 600, color: AdmColors.navy }}>Hospital cirúrgico?</div>
                        <IToggle checked={form.cirurgico} onChange={v => set('cirurgico', v)} size="sm" />
                      </div>
                      {form.cirurgico && <IField label="Salas cirúrgicas"><NumInput value={form.salas} onChange={e => set('salas', e.target.value)} /></IField>}
                      <IField label="Nutricionistas total" required><NumInput value={form.nutT} onChange={e => set('nutT', e.target.value)} /></IField>
                      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
                        <IField label="Clínicos"><NumInput value={form.nutC} onChange={e => set('nutC', e.target.value)} /></IField>
                        <IField label="EMTN"><NumInput value={form.nutE} onChange={e => set('nutE', e.target.value)} /></IField>
                      </div>
                    </div>
                  )}
                  {i === 3 && (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: 14, paddingTop: 10 }}>
                      <IField label="Nome do supervisor" required><ITextInput value={form.supNome} onChange={e => set('supNome', e.target.value)} icon="person" /></IField>
                      <IField label="Telefone" required><ITextInput value={form.supTel} onChange={e => set('supTel', maskPhone(e.target.value))} mono icon="call" /></IField>
                      <IField label="E-mail" required><ITextInput value={form.email} onChange={e => set('email', e.target.value)} icon="mail" suffix={<AIcon name="check_circle" size={18} color={AdmColors.success} />} /></IField>
                    </div>
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Sticky footer */}
      <div style={{ position: 'sticky', bottom: 0, background: '#fff', padding: '12px 16px 20px', borderTop: `1px solid ${AdmColors.n200}`, display: 'flex', gap: 10 }}>
        <button style={{ height: 48, padding: '0 18px', borderRadius: 9999, background: '#fff', border: `1.5px solid ${AdmColors.navy}`, color: AdmColors.navy, fontWeight: 600, fontSize: 14, fontFamily: 'Inter' }}>Cancelar</button>
        <button style={{ flex: 1, height: 48, borderRadius: 9999, background: AdmColors.lime, border: 0, color: '#fff', fontWeight: 700, fontSize: 14.5, fontFamily: 'Inter', boxShadow: '0 4px 12px rgba(139,198,63,0.28)' }}>
          Salvar instituição
        </button>
      </div>
    </div>
  );
}

Object.assign(window, { NewInstitutionDesktop, NewInstitutionMobile, IField, ITextInput, ISelect, IToggle, NumInput, maskCNPJ, maskPhone, maskCEP });
