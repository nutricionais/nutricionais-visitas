/* eslint-disable */
// Shared components for Nutricionais auth screens

const AuthColors = {
  navy: '#0A1F5C', navy800: '#0E2872', navy700: '#143090',
  navy100: '#E3E7F1', navy50: '#F3F5FA',
  lime: '#8BC63F', limeH: '#7AB033', limeP: '#689628',
  lime100: '#E7F3D4', lime50: '#F4F9EA',
  success: '#22A06B', successBg: '#E6F6EF',
  warning: '#F59E0B', warningBg: '#FEF4E1',
  danger: '#DC2626', dangerBg: '#FCE8E8',
  info: '#2563EB', infoBg: '#E4ECFD',
  n0: '#FFFFFF', n50: '#FAFBFC', n100: '#F3F4F6', n200: '#E5E7EB',
  n300: '#D1D5DB', n400: '#9CA3AF', n500: '#6B7280', n600: '#4B5563',
  n700: '#374151', n800: '#1F2937', n900: '#111827',
};

function MsIcon({ name, size = 24, color, weight = 500, fill = 0, style = {} }) {
  return (
    <span className="material-symbols-rounded"
      style={{
        fontSize: size, color: color || 'currentColor',
        fontVariationSettings: `'FILL' ${fill}, 'wght' ${weight}, 'GRAD' 0, 'opsz' ${size}`,
        lineHeight: 1, display: 'inline-flex', userSelect: 'none',
        ...style
      }}>{name}</span>
  );
}

function AuthButton({ children, variant = 'primary', onClick, disabled, full, size = 'lg', icon, type = 'button' }) {
  const [hover, setHover] = React.useState(false);
  const [press, setPress] = React.useState(false);
  const h = size === 'lg' ? 56 : size === 'md' ? 48 : 40;

  let bg, fg, border = 'none', shadow = 'none';
  if (variant === 'primary') {
    bg = disabled ? AuthColors.n300 : press ? AuthColors.limeP : hover ? AuthColors.limeH : AuthColors.lime;
    fg = disabled ? AuthColors.n500 : '#fff';
    shadow = disabled ? 'none' : hover ? '0 6px 18px rgba(139,198,63,0.38)' : '0 4px 12px rgba(139,198,63,0.28)';
  } else if (variant === 'secondary') {
    bg = press ? AuthColors.navy100 : hover ? AuthColors.navy50 : '#fff';
    fg = AuthColors.navy;
    border = `1.5px solid ${AuthColors.navy}`;
  } else { // ghost
    bg = hover ? AuthColors.navy50 : 'transparent';
    fg = AuthColors.navy;
  }

  return (
    <button type={type} onClick={disabled ? undefined : onClick} disabled={disabled}
      onMouseEnter={() => setHover(true)} onMouseLeave={() => { setHover(false); setPress(false); }}
      onMouseDown={() => setPress(true)} onMouseUp={() => setPress(false)}
      style={{
        height: h, padding: '0 28px', borderRadius: 9999, border,
        background: bg, color: fg,
        fontFamily: 'Inter, sans-serif', fontWeight: 600, fontSize: 15,
        display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 8,
        cursor: disabled ? 'not-allowed' : 'pointer',
        width: full ? '100%' : undefined,
        transition: 'all 160ms cubic-bezier(0.22,0.61,0.36,1)',
        boxShadow: shadow,
        transform: press && !disabled ? 'scale(0.985)' : 'scale(1)',
      }}
    >
      {icon && <MsIcon name={icon} size={20} />}
      {children}
    </button>
  );
}

// Input with optional mask, icon, trailing action
function AuthInput({
  label, placeholder, icon, value, onChange, type = 'text',
  mono, trailing, error, autoFocus, mask, hint, required
}) {
  const [focus, setFocus] = React.useState(false);
  const applyMask = (raw) => {
    if (!mask) return raw;
    let v = raw.replace(/\D/g, '');
    if (mask === 'cpf') {
      v = v.slice(0, 11);
      if (v.length > 9) return `${v.slice(0,3)}.${v.slice(3,6)}.${v.slice(6,9)}-${v.slice(9)}`;
      if (v.length > 6) return `${v.slice(0,3)}.${v.slice(3,6)}.${v.slice(6)}`;
      if (v.length > 3) return `${v.slice(0,3)}.${v.slice(3)}`;
      return v;
    }
    if (mask === 'phone') {
      v = v.slice(0, 11);
      if (v.length > 10) return `(${v.slice(0,2)}) ${v.slice(2,7)}-${v.slice(7)}`;
      if (v.length > 6) return `(${v.slice(0,2)}) ${v.slice(2,6)}-${v.slice(6)}`;
      if (v.length > 2) return `(${v.slice(0,2)}) ${v.slice(2)}`;
      if (v.length > 0) return `(${v}`;
      return v;
    }
    return raw;
  };
  const handleChange = (e) => {
    const masked = applyMask(e.target.value);
    if (onChange) onChange({ target: { value: masked } });
  };

  const borderColor = error ? AuthColors.danger : focus ? AuthColors.lime : AuthColors.n300;
  const glow = error ? '0 0 0 3px rgba(220,38,38,0.18)' : focus ? '0 0 0 3px rgba(139,198,63,0.25)' : 'none';

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
      {label && (
        <label style={{ fontSize: 13, fontWeight: 600, color: AuthColors.n700, display: 'flex', alignItems: 'center', gap: 4 }}>
          {label}
          {required && <span style={{ color: AuthColors.danger }}>*</span>}
        </label>
      )}
      <div style={{
        height: 52, borderRadius: 10, padding: '0 14px',
        border: `1.5px solid ${borderColor}`,
        boxShadow: glow,
        background: '#fff', display: 'flex', alignItems: 'center', gap: 10,
        transition: 'all 140ms cubic-bezier(0.22,0.61,0.36,1)',
      }}>
        {icon && <MsIcon name={icon} size={20} color={focus ? AuthColors.navy : AuthColors.n500} />}
        <input
          type={type}
          placeholder={placeholder}
          value={value ?? ''}
          autoFocus={autoFocus}
          onChange={handleChange}
          onFocus={() => setFocus(true)}
          onBlur={() => setFocus(false)}
          style={{
            flex: 1, border: 0, outline: 0, fontSize: 15, background: 'transparent',
            fontFamily: mono ? 'JetBrains Mono, monospace' : 'Inter, sans-serif',
            color: AuthColors.navy, minWidth: 0,
          }}
        />
        {trailing}
      </div>
      {error && (
        <div style={{ fontSize: 12, color: AuthColors.danger, display: 'flex', alignItems: 'center', gap: 4, marginTop: 2 }}>
          <MsIcon name="error" size={14} fill={1} />
          {error}
        </div>
      )}
      {hint && !error && (
        <div style={{ fontSize: 12, color: AuthColors.n500 }}>{hint}</div>
      )}
    </div>
  );
}

// Password field with toggle visibility + optional strength meter
function PasswordField({ label, value, onChange, placeholder = '••••••••', showStrength, autoFocus, required, confirmAgainst }) {
  const [show, setShow] = React.useState(false);

  let strength = 0;
  if (value) {
    if (value.length >= 8) strength++;
    if (/[A-Z]/.test(value)) strength++;
    if (/[0-9]/.test(value)) strength++;
    if (/[^A-Za-z0-9]/.test(value)) strength++;
  }

  let mismatchErr;
  if (confirmAgainst !== undefined && value && confirmAgainst && value !== confirmAgainst) {
    mismatchErr = 'As senhas não conferem';
  }

  const strengthLabels = ['', 'Fraca', 'Média', 'Boa', 'Forte'];
  const strengthColors = ['', AuthColors.danger, AuthColors.warning, AuthColors.lime, AuthColors.success];

  const toggle = (
    <button type="button" onClick={() => setShow(!show)}
      style={{
        background: 'transparent', border: 0, cursor: 'pointer',
        color: AuthColors.n500, padding: 4, borderRadius: 6, display: 'inline-flex',
      }}>
      <MsIcon name={show ? 'visibility_off' : 'visibility'} size={20} />
    </button>
  );

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
      <AuthInput
        label={label || 'Senha'}
        type={show ? 'text' : 'password'}
        value={value}
        onChange={onChange}
        icon="lock"
        placeholder={placeholder}
        trailing={toggle}
        autoFocus={autoFocus}
        required={required}
        error={mismatchErr}
      />
      {showStrength && value && (
        <div>
          <div style={{ display: 'flex', gap: 4, marginBottom: 4 }}>
            {[1,2,3,4].map(i => (
              <div key={i} style={{
                flex: 1, height: 4, borderRadius: 2,
                background: i <= strength ? strengthColors[strength] : AuthColors.n200,
                transition: 'background 180ms',
              }} />
            ))}
          </div>
          <div style={{ fontSize: 12, color: AuthColors.n600, display: 'flex', justifyContent: 'space-between' }}>
            <span>Força da senha</span>
            <span style={{ color: strengthColors[strength], fontWeight: 600 }}>{strengthLabels[strength]}</span>
          </div>
        </div>
      )}
    </div>
  );
}

function Checkbox({ checked, onChange, children }) {
  return (
    <label style={{ display: 'inline-flex', alignItems: 'center', gap: 10, cursor: 'pointer', userSelect: 'none' }}>
      <div
        onClick={() => onChange(!checked)}
        style={{
          width: 20, height: 20, borderRadius: 6,
          border: `1.5px solid ${checked ? AuthColors.lime : AuthColors.n300}`,
          background: checked ? AuthColors.lime : '#fff',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          transition: 'all 140ms',
          flexShrink: 0,
        }}
      >
        {checked && <MsIcon name="check" size={16} color="#fff" weight={700} />}
      </div>
      <span style={{ fontSize: 14, color: AuthColors.n700 }}>{children}</span>
    </label>
  );
}

// OTP input — 6 separate boxes
function OTPInput({ value, onChange, length = 6, error, autoFocus }) {
  const inputsRef = React.useRef([]);
  const digits = value.padEnd(length, ' ').split('').slice(0, length);

  const handleChange = (i, v) => {
    const digit = v.replace(/\D/g, '').slice(-1);
    const arr = value.split('');
    while (arr.length < length) arr.push('');
    arr[i] = digit;
    const next = arr.join('').trimEnd();
    onChange(next);
    if (digit && i < length - 1) inputsRef.current[i + 1]?.focus();
  };

  const handleKey = (i, e) => {
    if (e.key === 'Backspace' && !digits[i].trim() && i > 0) {
      inputsRef.current[i - 1]?.focus();
    }
    if (e.key === 'ArrowLeft' && i > 0) inputsRef.current[i - 1]?.focus();
    if (e.key === 'ArrowRight' && i < length - 1) inputsRef.current[i + 1]?.focus();
  };

  const handlePaste = (e) => {
    const txt = (e.clipboardData.getData('text') || '').replace(/\D/g, '').slice(0, length);
    if (txt) {
      e.preventDefault();
      onChange(txt);
      inputsRef.current[Math.min(txt.length, length - 1)]?.focus();
    }
  };

  return (
    <div>
      <div style={{ display: 'flex', gap: 10, justifyContent: 'space-between' }}>
        {digits.map((d, i) => {
          const filled = d.trim().length > 0;
          const err = !!error;
          return (
            <input
              key={i}
              ref={el => inputsRef.current[i] = el}
              inputMode="numeric"
              maxLength={1}
              value={d.trim()}
              onChange={(e) => handleChange(i, e.target.value)}
              onKeyDown={(e) => handleKey(i, e)}
              onPaste={handlePaste}
              autoFocus={autoFocus && i === 0}
              style={{
                width: 48, height: 56, textAlign: 'center',
                fontFamily: 'Poppins, sans-serif', fontSize: 24, fontWeight: 700,
                color: AuthColors.navy,
                border: `1.5px solid ${err ? AuthColors.danger : filled ? AuthColors.lime : AuthColors.n300}`,
                borderRadius: 10,
                background: filled ? AuthColors.lime50 : '#fff',
                outline: 0,
                transition: 'all 140ms',
              }}
              onFocus={(e) => { e.target.style.boxShadow = `0 0 0 3px rgba(139,198,63,0.25)`; e.target.style.borderColor = AuthColors.lime; }}
              onBlur={(e) => { e.target.style.boxShadow = 'none'; e.target.style.borderColor = err ? AuthColors.danger : filled ? AuthColors.lime : AuthColors.n300; }}
            />
          );
        })}
      </div>
      {error && (
        <div style={{ fontSize: 12, color: AuthColors.danger, display: 'flex', alignItems: 'center', gap: 4, marginTop: 10 }}>
          <MsIcon name="error" size={14} fill={1} />
          {error}
        </div>
      )}
    </div>
  );
}

// Requirement list with live checks
function RequirementList({ items }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 6, padding: '4px 2px' }}>
      {items.map((it, i) => (
        <div key={i} style={{
          display: 'flex', alignItems: 'center', gap: 8,
          fontSize: 13, color: it.met ? AuthColors.success : AuthColors.n500,
          transition: 'color 140ms',
        }}>
          <div style={{
            width: 18, height: 18, borderRadius: '50%',
            background: it.met ? AuthColors.success : AuthColors.n200,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            transition: 'background 140ms',
            flexShrink: 0,
          }}>
            <MsIcon name={it.met ? 'check' : 'close'} size={12} color="#fff" weight={700} />
          </div>
          <span>{it.label}</span>
        </div>
      ))}
    </div>
  );
}

// Mobile frame — phone silhouette for mobile screenshots
function PhoneFrame({ children, label, width = 390, height = 844 }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 14 }}>
      <div style={{
        width: width + 14, height: height + 14, borderRadius: 48,
        background: '#0A0A0A', padding: 7,
        boxShadow: '0 30px 70px rgba(10,31,92,0.22), 0 0 0 1px rgba(0,0,0,0.08)',
        position: 'relative', flexShrink: 0,
      }}>
        <div style={{
          width: '100%', height: '100%', borderRadius: 42,
          overflow: 'hidden', background: '#fff', position: 'relative',
        }}>
          {/* Dynamic Island */}
          <div style={{
            position: 'absolute', top: 10, left: '50%', transform: 'translateX(-50%)',
            width: 110, height: 32, borderRadius: 20, background: '#000', zIndex: 50,
          }} />
          {/* Status bar */}
          <div style={{
            position: 'absolute', top: 0, left: 0, right: 0, height: 50,
            display: 'flex', alignItems: 'center', justifyContent: 'space-between',
            padding: '0 30px', zIndex: 40, pointerEvents: 'none',
          }}>
            <span style={{ fontFamily: '-apple-system, sans-serif', fontSize: 15, fontWeight: 600, color: AuthColors.navy }}>9:41</span>
            <span style={{ display: 'flex', gap: 5, alignItems: 'center', color: AuthColors.navy }}>
              <MsIcon name="signal_cellular_alt" size={15} />
              <MsIcon name="wifi" size={15} />
              <MsIcon name="battery_full" size={15} />
            </span>
          </div>
          {/* content */}
          <div style={{ position: 'absolute', inset: 0, overflow: 'hidden' }}>
            {children}
          </div>
          {/* Home indicator */}
          <div style={{
            position: 'absolute', bottom: 8, left: '50%', transform: 'translateX(-50%)',
            width: 134, height: 5, borderRadius: 3, background: 'rgba(0,0,0,0.3)', zIndex: 60,
          }} />
        </div>
      </div>
      {label && (
        <div style={{
          fontFamily: 'Poppins, sans-serif', fontSize: 13, fontWeight: 600,
          color: AuthColors.navy, letterSpacing: '-0.01em',
        }}>{label}</div>
      )}
    </div>
  );
}

// Mobile header with back + title
function MobileHeader({ title, onBack }) {
  return (
    <div style={{
      paddingTop: 56, paddingBottom: 16, padding: '56px 20px 16px',
      display: 'flex', alignItems: 'center', gap: 12,
      background: '#fff',
    }}>
      {onBack && (
        <button onClick={onBack} style={{
          width: 40, height: 40, borderRadius: 10,
          background: AuthColors.navy50, border: 0, cursor: 'pointer',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          color: AuthColors.navy,
        }}>
          <MsIcon name="arrow_back" size={22} />
        </button>
      )}
      <div style={{
        fontFamily: 'Poppins, sans-serif', fontSize: 18, fontWeight: 600,
        color: AuthColors.navy,
      }}>{title}</div>
    </div>
  );
}

Object.assign(window, {
  AuthColors, MsIcon, AuthButton, AuthInput, PasswordField,
  Checkbox, OTPInput, RequirementList, PhoneFrame, MobileHeader,
});
