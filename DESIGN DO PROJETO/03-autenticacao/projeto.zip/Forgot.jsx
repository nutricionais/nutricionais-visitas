/* eslint-disable */
// Forgot password — 3 states

function ForgotStateA({ onNext, onBack }) {
  const [email, setEmail] = React.useState('');
  return (
    <div style={{ width: '100%', height: '100%', background: '#fff', display: 'flex', flexDirection: 'column', fontFamily: 'Inter, sans-serif' }}>
      <MobileHeader title="Recuperar senha" onBack={onBack} />
      <div style={{ flex: 1, padding: '8px 24px 32px', display: 'flex', flexDirection: 'column', overflow: 'auto' }}>
        <div style={{
          width: 96, height: 96, borderRadius: '50%',
          background: AuthColors.lime50, border: `2px solid ${AuthColors.lime100}`,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          margin: '24px auto 20px',
        }}>
          <MsIcon name="lock_reset" size={48} color={AuthColors.lime} weight={500} />
        </div>
        <div style={{
          fontFamily: 'Poppins, sans-serif', fontSize: 22, fontWeight: 700,
          color: AuthColors.navy, textAlign: 'center', marginBottom: 8,
          letterSpacing: '-0.01em',
        }}>
          Esqueceu a senha?
        </div>
        <div style={{
          fontSize: 14, color: AuthColors.n600, textAlign: 'center',
          lineHeight: 1.5, marginBottom: 28, padding: '0 12px',
        }}>
          Digite o e-mail cadastrado. Enviaremos um código de 6 dígitos para você.
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 18 }}>
          <AuthInput label="E-mail" icon="mail" type="email"
            placeholder="seu@email.com" value={email}
            onChange={e => setEmail(e.target.value)} autoFocus />
          <AuthButton full size="lg" onClick={onNext} disabled={!email.includes('@')}>
            Enviar código
          </AuthButton>
          <button onClick={onBack} style={{
            background: 'transparent', border: 0, color: AuthColors.navy,
            fontSize: 14, fontWeight: 600, cursor: 'pointer', padding: 12,
            fontFamily: 'Inter, sans-serif',
          }}>
            Voltar ao login
          </button>
        </div>
      </div>
    </div>
  );
}

function ForgotStateB({ onNext, onBack, email = 'a******@nutricionais.com.br' }) {
  const [code, setCode] = React.useState('');
  const [seconds, setSeconds] = React.useState(165);

  React.useEffect(() => {
    if (seconds <= 0) return;
    const t = setTimeout(() => setSeconds(s => s - 1), 1000);
    return () => clearTimeout(t);
  }, [seconds]);

  const mm = String(Math.floor(seconds / 60)).padStart(1, '0');
  const ss = String(seconds % 60).padStart(2, '0');
  const canResend = seconds === 0;

  return (
    <div style={{ width: '100%', height: '100%', background: '#fff', display: 'flex', flexDirection: 'column', fontFamily: 'Inter, sans-serif' }}>
      <MobileHeader title="Recuperar senha" onBack={onBack} />
      <div style={{ flex: 1, padding: '8px 24px 32px', display: 'flex', flexDirection: 'column', overflow: 'auto' }}>
        {/* icon with badge */}
        <div style={{ position: 'relative', width: 96, height: 96, margin: '24px auto 20px' }}>
          <div style={{
            width: 96, height: 96, borderRadius: '50%',
            background: AuthColors.lime50, border: `2px solid ${AuthColors.lime100}`,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>
            <MsIcon name="mark_email_read" size={48} color={AuthColors.lime} weight={500} />
          </div>
          <div style={{
            position: 'absolute', top: -4, right: -4,
            width: 28, height: 28, borderRadius: '50%',
            background: AuthColors.success, color: '#fff',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            border: '3px solid #fff',
          }}>
            <MsIcon name="check" size={16} weight={700} />
          </div>
        </div>

        <div style={{
          fontFamily: 'Poppins, sans-serif', fontSize: 22, fontWeight: 700,
          color: AuthColors.navy, textAlign: 'center', marginBottom: 8,
          letterSpacing: '-0.01em',
        }}>
          Digite o código
        </div>
        <div style={{
          fontSize: 14, color: AuthColors.n600, textAlign: 'center',
          lineHeight: 1.5, marginBottom: 24, padding: '0 8px',
        }}>
          Enviamos um código para<br/>
          <span style={{ fontFamily: 'JetBrains Mono, monospace', color: AuthColors.navy, fontWeight: 600 }}>{email}</span>
        </div>

        <div style={{ marginBottom: 20 }}>
          <OTPInput value={code} onChange={setCode} autoFocus />
        </div>

        <div style={{
          textAlign: 'center', fontSize: 13, color: AuthColors.n600, marginBottom: 24,
        }}>
          {canResend ? (
            <button style={{
              background: 'transparent', border: 0, color: AuthColors.lime,
              fontWeight: 600, fontSize: 13, cursor: 'pointer', fontFamily: 'Inter, sans-serif',
            }} onClick={() => setSeconds(165)}>
              Reenviar código
            </button>
          ) : (
            <>
              Reenviar em <span style={{ fontFamily: 'JetBrains Mono, monospace', color: AuthColors.navy, fontWeight: 600 }}>{mm}:{ss}</span>
            </>
          )}
        </div>

        <AuthButton full size="lg" disabled={code.length < 6} onClick={onNext}>
          Verificar código
        </AuthButton>

        <button onClick={onBack} style={{
          background: 'transparent', border: 0, color: AuthColors.n600,
          fontSize: 13, cursor: 'pointer', padding: 14, marginTop: 8,
          fontFamily: 'Inter, sans-serif',
        }}>
          Não recebi, tentar outro e-mail
        </button>
      </div>
    </div>
  );
}

function ForgotStateC({ onDone, onBack }) {
  const [pwd, setPwd] = React.useState('');
  const [pwd2, setPwd2] = React.useState('');
  const reqs = [
    { label: 'Pelo menos 8 caracteres', met: pwd.length >= 8 },
    { label: '1 letra maiúscula', met: /[A-Z]/.test(pwd) },
    { label: '1 número', met: /[0-9]/.test(pwd) },
    { label: '1 caractere especial', met: /[^A-Za-z0-9]/.test(pwd) },
  ];
  const allMet = reqs.every(r => r.met);
  const matches = pwd === pwd2 && pwd2.length > 0;

  return (
    <div style={{ width: '100%', height: '100%', background: '#fff', display: 'flex', flexDirection: 'column', fontFamily: 'Inter, sans-serif' }}>
      <MobileHeader title="Nova senha" onBack={onBack} />
      <div style={{ flex: 1, padding: '8px 24px 32px', display: 'flex', flexDirection: 'column', overflow: 'auto' }}>
        <div style={{
          width: 96, height: 96, borderRadius: '50%',
          background: AuthColors.successBg, border: `2px solid #C5E9D6`,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          margin: '20px auto 16px',
        }}>
          <MsIcon name="lock_open" size={48} color={AuthColors.success} weight={500} />
        </div>

        <div style={{
          fontFamily: 'Poppins, sans-serif', fontSize: 22, fontWeight: 700,
          color: AuthColors.navy, textAlign: 'center', marginBottom: 6,
          letterSpacing: '-0.01em',
        }}>
          Criar nova senha
        </div>
        <div style={{
          fontSize: 14, color: AuthColors.n600, textAlign: 'center',
          marginBottom: 24,
        }}>
          Escolha uma senha forte e fácil de lembrar.
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          <PasswordField label="Nova senha" value={pwd} onChange={e => setPwd(e.target.value)} showStrength autoFocus />

          <div style={{
            background: AuthColors.n50, borderRadius: 10, padding: 14,
            border: `1px solid ${AuthColors.n200}`,
          }}>
            <RequirementList items={reqs} />
          </div>

          <PasswordField label="Confirmar nova senha" value={pwd2} onChange={e => setPwd2(e.target.value)} confirmAgainst={pwd} />

          <div style={{ height: 4 }} />
          <AuthButton full size="lg" disabled={!allMet || !matches} onClick={onDone}>
            Salvar nova senha
          </AuthButton>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { ForgotStateA, ForgotStateB, ForgotStateC });
