/* eslint-disable */
// Login screen — Desktop split + Mobile

function LoginDesktop({ settings = {} }) {
  const [cpf, setCpf] = React.useState('');
  const [pwd, setPwd] = React.useState('');
  const [keep, setKeep] = React.useState(true);
  const cpfClean = cpf.replace(/\D/g, '');
  const canSubmit = cpfClean.length === 11 && pwd.length >= 6;

  return (
    <div style={{
      width: 1440, height: 900, display: 'grid', gridTemplateColumns: '1fr 1fr',
      background: '#fff', fontFamily: 'Inter, sans-serif',
      borderRadius: 16, overflow: 'hidden',
      boxShadow: '0 30px 80px rgba(10,31,92,0.14)',
    }}>
      {/* LEFT — navy splash */}
      <div style={{
        background: `linear-gradient(155deg, ${AuthColors.navy} 0%, ${AuthColors.navy800} 55%, #081648 100%)`,
        color: '#fff', padding: '56px 64px',
        display: 'flex', flexDirection: 'column', justifyContent: 'space-between',
        position: 'relative', overflow: 'hidden',
      }}>
        {/* Decorative watermark — building silhouette + heart pattern */}
        <svg width="720" height="720" viewBox="0 0 720 720" style={{
          position: 'absolute', right: -180, bottom: -160, opacity: 0.11, pointerEvents: 'none',
        }}>
          {/* Heart (brand mark) watermark */}
          <g transform="translate(380, 180)" fill={AuthColors.lime}>
            <path d="M0,40 C0,10 -30,-10 -55,-10 C-85,-10 -110,15 -110,48 C-110,95 -55,135 0,170 C55,135 110,95 110,48 C110,15 85,-10 55,-10 C30,-10 0,10 0,40 Z"/>
          </g>
          {/* Hospital skyline outline */}
          <g stroke="#fff" strokeWidth="2" fill="none" transform="translate(40, 380)">
            <rect x="0" y="80" width="120" height="240" />
            <rect x="140" y="40" width="160" height="280" />
            <rect x="320" y="100" width="100" height="220" />
            <rect x="440" y="60" width="140" height="260" />
            {/* Cross on main building */}
            <g transform="translate(200, 100)">
              <rect x="-10" y="-30" width="20" height="60" fill="#fff" />
              <rect x="-30" y="-10" width="60" height="20" fill="#fff" />
            </g>
            {/* Windows pattern */}
            {[0,1,2,3,4,5].map(row => [0,1,2].map(col => (
              <rect key={`${row}-${col}`} x={10 + col * 35} y={100 + row * 30} width="18" height="18" fill="#fff" fillOpacity="0.3" stroke="none" />
            )))}
          </g>
          {/* Small geometric dots */}
          {[...Array(30)].map((_, i) => (
            <circle key={i}
              cx={80 + (i * 47) % 640}
              cy={60 + (i * 83) % 280}
              r="2" fill={AuthColors.lime} opacity="0.6" />
          ))}
        </svg>

        {/* subtle grid pattern */}
        <div style={{
          position: 'absolute', inset: 0,
          backgroundImage: 'radial-gradient(rgba(139,198,63,0.08) 1px, transparent 1px)',
          backgroundSize: '32px 32px', opacity: 0.5,
        }} />

        {/* Content */}
        <div style={{ position: 'relative', zIndex: 1 }}>
          <img src="assets/nutri-logo-white.png" alt="Nutricionais" style={{ height: 52 }} />
        </div>

        <div style={{ position: 'relative', zIndex: 1, maxWidth: 480 }}>
          <div style={{
            display: 'inline-flex', alignItems: 'center', gap: 8,
            background: 'rgba(139,198,63,0.16)', color: AuthColors.lime,
            padding: '6px 14px', borderRadius: 9999,
            fontSize: 12, fontWeight: 600, letterSpacing: '0.08em', textTransform: 'uppercase',
            marginBottom: 24,
            border: '1px solid rgba(139,198,63,0.3)',
          }}>
            <span style={{ width: 6, height: 6, borderRadius: '50%', background: AuthColors.lime }} />
            CRM de visitas comerciais
          </div>
          <div style={{
            fontFamily: 'Poppins, sans-serif', fontSize: 40, fontWeight: 700,
            lineHeight: 1.15, letterSpacing: '-0.02em', marginBottom: 16,
          }}>
            Cada visita,<br/>
            <span style={{ color: AuthColors.lime }}>cada hospital,</span><br/>
            na palma da mão.
          </div>
          <div style={{
            fontSize: 15, color: 'rgba(255,255,255,0.7)',
            lineHeight: 1.55, maxWidth: 420,
          }}>
            Registre check-ins por GPS, faça relatórios em segundos e acompanhe seu faturamento em um só lugar.
          </div>
        </div>

        <div style={{ position: 'relative', zIndex: 1, display: 'flex', justifyContent: 'space-between', alignItems: 'center', fontSize: 12, color: 'rgba(255,255,255,0.5)' }}>
          <span>© 2026 Nutricionais · v1.0</span>
          <span style={{ display: 'flex', gap: 16 }}>
            <span style={{ cursor: 'pointer' }}>Termos</span>
            <span style={{ cursor: 'pointer' }}>Privacidade</span>
            <span style={{ cursor: 'pointer' }}>Suporte</span>
          </span>
        </div>
      </div>

      {/* RIGHT — form */}
      <div style={{
        background: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center',
        padding: '56px 80px', position: 'relative',
      }}>
        {/* top helper */}
        <div style={{
          position: 'absolute', top: 40, right: 64,
          fontSize: 13, color: AuthColors.n500,
        }}>
          Novo por aqui? <a href="#cadastro" style={{ color: AuthColors.navy, fontWeight: 600, textDecoration: 'none', marginLeft: 6 }}>Cadastre-se</a>
        </div>

        <div style={{ width: '100%', maxWidth: 420, display: 'flex', flexDirection: 'column', gap: 28 }}>
          <div>
            <div style={{
              fontFamily: 'Poppins, sans-serif', fontSize: 32, fontWeight: 700,
              color: AuthColors.navy, letterSpacing: '-0.02em', marginBottom: 6,
            }}>Entrar</div>
            <div style={{ fontSize: 15, color: AuthColors.n600 }}>
              Acesse sua conta para começar o dia.
            </div>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: 18 }}>
            <AuthInput label="CPF" icon="badge" mask="cpf" mono placeholder="000.000.000-00" value={cpf} onChange={e => setCpf(e.target.value)} />
            <div>
              <PasswordField value={pwd} onChange={e => setPwd(e.target.value)} />
              <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 8 }}>
                <a href="#forgot" style={{ fontSize: 13, color: AuthColors.navy, fontWeight: 600, textDecoration: 'none' }}>
                  Esqueci minha senha
                </a>
              </div>
            </div>
            <Checkbox checked={keep} onChange={setKeep}>
              Manter conectado neste dispositivo
            </Checkbox>

            <AuthButton full size="lg" disabled={!canSubmit}>Entrar</AuthButton>

            <div style={{ display: 'flex', alignItems: 'center', gap: 14, margin: '4px 0' }}>
              <div style={{ flex: 1, height: 1, background: AuthColors.n200 }} />
              <span style={{ fontSize: 12, color: AuthColors.n500, textTransform: 'uppercase', letterSpacing: '0.1em', fontWeight: 600 }}>ou</span>
              <div style={{ flex: 1, height: 1, background: AuthColors.n200 }} />
            </div>

            <a href="#cadastro" style={{ textDecoration: 'none' }}>
              <AuthButton full size="lg" variant="secondary" icon="person_add">
                Primeiro acesso? Cadastre-se
              </AuthButton>
            </a>
          </div>

          <div style={{ textAlign: 'center', fontSize: 12, color: AuthColors.n400, marginTop: 8 }}>
            Problemas para entrar? Fale com <span style={{ color: AuthColors.navy, fontWeight: 600 }}>suporte@nutricionais.com.br</span>
          </div>
        </div>
      </div>
    </div>
  );
}

function LoginMobile() {
  const [cpf, setCpf] = React.useState('');
  const [pwd, setPwd] = React.useState('');
  const [keep, setKeep] = React.useState(true);

  return (
    <div style={{
      width: '100%', height: '100%', background: '#fff', overflow: 'auto',
      padding: '70px 24px 40px', display: 'flex', flexDirection: 'column',
      fontFamily: 'Inter, sans-serif',
    }}>
      <div style={{ display: 'flex', justifyContent: 'center', marginBottom: 30 }}>
        <img src="assets/nutri-logo-light.png" alt="Nutricionais" style={{ height: 44 }} />
      </div>

      <div style={{ marginBottom: 24 }}>
        <div style={{
          fontFamily: 'Poppins, sans-serif', fontSize: 26, fontWeight: 700,
          color: AuthColors.navy, letterSpacing: '-0.02em', marginBottom: 4,
        }}>Entrar</div>
        <div style={{ fontSize: 14, color: AuthColors.n600 }}>
          Acesse sua conta para começar o dia.
        </div>
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
        <AuthInput label="CPF" icon="badge" mask="cpf" mono placeholder="000.000.000-00" value={cpf} onChange={e => setCpf(e.target.value)} />
        <PasswordField value={pwd} onChange={e => setPwd(e.target.value)} />
        <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: -4 }}>
          <a href="#forgot" style={{ fontSize: 13, color: AuthColors.navy, fontWeight: 600, textDecoration: 'none' }}>
            Esqueci minha senha
          </a>
        </div>
        <Checkbox checked={keep} onChange={setKeep}>
          Manter conectado
        </Checkbox>
        <div style={{ height: 4 }} />
        <AuthButton full size="lg">Entrar</AuthButton>

        <div style={{ display: 'flex', alignItems: 'center', gap: 12, margin: '8px 0' }}>
          <div style={{ flex: 1, height: 1, background: AuthColors.n200 }} />
          <span style={{ fontSize: 12, color: AuthColors.n500, textTransform: 'uppercase', letterSpacing: '0.08em', fontWeight: 600 }}>ou</span>
          <div style={{ flex: 1, height: 1, background: AuthColors.n200 }} />
        </div>

        <AuthButton full size="lg" variant="secondary" icon="person_add">
          Primeiro acesso? Cadastre-se
        </AuthButton>
      </div>

      <div style={{ flex: 1 }} />
      <div style={{ textAlign: 'center', fontSize: 11, color: AuthColors.n400, marginTop: 32 }}>
        © 2026 Nutricionais · v1.0
      </div>
    </div>
  );
}

Object.assign(window, { LoginDesktop, LoginMobile });
