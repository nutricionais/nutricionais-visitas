/* eslint-disable */
// Signup — 2 states: form + waiting approval

function SignupFormMobile({ onSubmit, onBackToLogin }) {
  const [f, setF] = React.useState({ name: '', cpf: '', email: '', phone: '', pwd: '', pwd2: '' });
  const [terms, setTerms] = React.useState(false);
  const u = (k, v) => setF({ ...f, [k]: v });

  const cpfClean = f.cpf.replace(/\D/g, '');
  const reqs = [
    { label: 'Pelo menos 8 caracteres', met: f.pwd.length >= 8 },
    { label: '1 letra maiúscula', met: /[A-Z]/.test(f.pwd) },
    { label: '1 número', met: /[0-9]/.test(f.pwd) },
    { label: '1 caractere especial', met: /[^A-Za-z0-9]/.test(f.pwd) },
  ];
  const pwdOk = reqs.every(r => r.met);
  const canSubmit = f.name.trim().length > 3 && cpfClean.length === 11
    && f.email.includes('@') && f.phone.replace(/\D/g,'').length >= 10
    && pwdOk && f.pwd === f.pwd2 && terms;

  return (
    <div style={{ width: '100%', height: '100%', background: '#fff', display: 'flex', flexDirection: 'column', fontFamily: 'Inter, sans-serif' }}>
      <MobileHeader title="Criar conta" onBack={onBackToLogin} />
      <div style={{ flex: 1, padding: '8px 24px 32px', overflow: 'auto' }}>
        <div style={{
          background: AuthColors.navy50, border: `1px solid ${AuthColors.navy100}`,
          borderRadius: 12, padding: '14px 16px', display: 'flex', gap: 12,
          alignItems: 'flex-start', marginBottom: 22,
        }}>
          <div style={{ flexShrink: 0, color: AuthColors.navy }}>
            <MsIcon name="info" size={20} fill={1} />
          </div>
          <div style={{ fontSize: 13, color: AuthColors.navy, lineHeight: 1.5 }}>
            Sua conta precisará ser <b>aprovada pelo administrador</b> antes do primeiro login.
          </div>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          <AuthInput label="Nome completo" icon="person" placeholder="Ex: Ana Ribeiro"
            value={f.name} onChange={e => u('name', e.target.value)} required />
          <AuthInput label="CPF" icon="badge" mask="cpf" mono placeholder="000.000.000-00"
            value={f.cpf} onChange={e => u('cpf', e.target.value)} required />
          <AuthInput label="E-mail corporativo" icon="mail" type="email"
            placeholder="seu.nome@empresa.com.br" value={f.email}
            onChange={e => u('email', e.target.value)} required />
          <AuthInput label="Telefone" icon="phone" mask="phone" mono placeholder="(11) 99999-9999"
            value={f.phone} onChange={e => u('phone', e.target.value)} required />
          <PasswordField label="Senha" value={f.pwd} onChange={e => u('pwd', e.target.value)} showStrength required />
          <div style={{
            background: AuthColors.n50, borderRadius: 10, padding: 12,
            border: `1px solid ${AuthColors.n200}`,
          }}>
            <RequirementList items={reqs} />
          </div>
          <PasswordField label="Confirmar senha" value={f.pwd2} onChange={e => u('pwd2', e.target.value)} confirmAgainst={f.pwd} required />

          <div style={{ padding: '8px 0' }}>
            <Checkbox checked={terms} onChange={setTerms}>
              Li e aceito os <a href="#" style={{ color: AuthColors.navy, fontWeight: 600, textDecoration: 'underline' }}>termos de uso</a>
            </Checkbox>
          </div>

          <AuthButton full size="lg" disabled={!canSubmit} onClick={onSubmit}>
            Criar conta
          </AuthButton>
          <button onClick={onBackToLogin} style={{
            background: 'transparent', border: 0, color: AuthColors.navy,
            fontSize: 14, fontWeight: 600, cursor: 'pointer', padding: 12,
            fontFamily: 'Inter, sans-serif',
          }}>
            Já tenho conta, entrar
          </button>
        </div>
      </div>
    </div>
  );
}

function SignupFormDesktop({ onSubmit, onBackToLogin }) {
  const [f, setF] = React.useState({ name: '', cpf: '', email: '', phone: '', pwd: '', pwd2: '' });
  const [terms, setTerms] = React.useState(false);
  const u = (k, v) => setF({ ...f, [k]: v });

  const reqs = [
    { label: 'Pelo menos 8 caracteres', met: f.pwd.length >= 8 },
    { label: '1 letra maiúscula', met: /[A-Z]/.test(f.pwd) },
    { label: '1 número', met: /[0-9]/.test(f.pwd) },
    { label: '1 caractere especial', met: /[^A-Za-z0-9]/.test(f.pwd) },
  ];

  return (
    <div style={{
      width: 1440, height: 900, display: 'grid', gridTemplateColumns: '420px 1fr',
      background: '#fff', fontFamily: 'Inter, sans-serif',
      borderRadius: 16, overflow: 'hidden',
      boxShadow: '0 30px 80px rgba(10,31,92,0.14)',
    }}>
      {/* LEFT — steps + brand */}
      <div style={{
        background: `linear-gradient(180deg, ${AuthColors.navy} 0%, ${AuthColors.navy800} 100%)`,
        color: '#fff', padding: '48px 40px',
        display: 'flex', flexDirection: 'column',
      }}>
        <img src="assets/nutri-logo-white.png" alt="Nutricionais" style={{ height: 44, width: 'auto', maxWidth: 200, objectFit: 'contain', display: 'block', marginBottom: 48 }} />

        <div style={{
          fontFamily: 'Poppins, sans-serif', fontSize: 28, fontWeight: 700,
          lineHeight: 1.2, letterSpacing: '-0.02em', marginBottom: 12,
        }}>
          Bem-vindo ao time.
        </div>
        <div style={{ fontSize: 14, color: 'rgba(255,255,255,0.7)', lineHeight: 1.55, marginBottom: 40 }}>
          Preencha seus dados e o administrador liberará seu acesso em poucas horas.
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 18 }}>
          {[
            { n: 1, label: 'Preencha seus dados', active: true },
            { n: 2, label: 'Aguarde aprovação do admin' },
            { n: 3, label: 'Comece a registrar visitas' },
          ].map((s, i) => (
            <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
              <div style={{
                width: 36, height: 36, borderRadius: '50%',
                background: s.active ? AuthColors.lime : 'rgba(255,255,255,0.08)',
                border: `1.5px solid ${s.active ? AuthColors.lime : 'rgba(255,255,255,0.2)'}`,
                color: s.active ? '#fff' : 'rgba(255,255,255,0.6)',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontFamily: 'Poppins, sans-serif', fontWeight: 700, fontSize: 14,
                flexShrink: 0,
              }}>{s.n}</div>
              <div style={{ fontSize: 14, color: s.active ? '#fff' : 'rgba(255,255,255,0.6)', fontWeight: s.active ? 600 : 500 }}>
                {s.label}
              </div>
            </div>
          ))}
        </div>

        <div style={{ flex: 1 }} />

        <div style={{
          background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)',
          borderRadius: 12, padding: 16, display: 'flex', gap: 12, alignItems: 'flex-start',
        }}>
          <MsIcon name="support_agent" size={22} color={AuthColors.lime} />
          <div>
            <div style={{ fontSize: 13, fontWeight: 600, marginBottom: 2 }}>Precisa de ajuda?</div>
            <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.7)' }}>suporte@nutricionais.com.br</div>
          </div>
        </div>
      </div>

      {/* RIGHT — form */}
      <div style={{ padding: '48px 80px', overflow: 'auto', display: 'flex', flexDirection: 'column' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 28 }}>
          <div>
            <div style={{
              fontFamily: 'Poppins, sans-serif', fontSize: 32, fontWeight: 700,
              color: AuthColors.navy, letterSpacing: '-0.02em', marginBottom: 6,
            }}>Criar conta</div>
            <div style={{ fontSize: 14, color: AuthColors.n600 }}>
              Sua conta precisará ser aprovada pelo administrador antes do primeiro login.
            </div>
          </div>
          <button onClick={onBackToLogin} style={{
            background: 'transparent', border: 0, color: AuthColors.navy,
            fontSize: 13, fontWeight: 600, cursor: 'pointer', fontFamily: 'Inter, sans-serif',
            padding: '8px 14px', borderRadius: 9999,
          }}>
            Já tenho conta →
          </button>
        </div>

        <div style={{ maxWidth: 640, display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 18 }}>
          <div style={{ gridColumn: '1 / -1' }}>
            <AuthInput label="Nome completo" icon="person" placeholder="Ex: Ana Ribeiro"
              value={f.name} onChange={e => u('name', e.target.value)} required />
          </div>
          <AuthInput label="CPF" icon="badge" mask="cpf" mono placeholder="000.000.000-00"
            value={f.cpf} onChange={e => u('cpf', e.target.value)} required />
          <AuthInput label="Telefone" icon="phone" mask="phone" mono placeholder="(11) 99999-9999"
            value={f.phone} onChange={e => u('phone', e.target.value)} required />
          <div style={{ gridColumn: '1 / -1' }}>
            <AuthInput label="E-mail corporativo" icon="mail" type="email"
              placeholder="seu.nome@empresa.com.br" value={f.email}
              onChange={e => u('email', e.target.value)} required />
          </div>
          <div style={{ gridColumn: '1 / -1' }}>
            <PasswordField label="Senha" value={f.pwd} onChange={e => u('pwd', e.target.value)} showStrength required />
          </div>
          <div style={{ gridColumn: '1 / -1', background: AuthColors.n50, borderRadius: 10, padding: 14, border: `1px solid ${AuthColors.n200}` }}>
            <RequirementList items={reqs} />
          </div>
          <div style={{ gridColumn: '1 / -1' }}>
            <PasswordField label="Confirmar senha" value={f.pwd2} onChange={e => u('pwd2', e.target.value)} confirmAgainst={f.pwd} required />
          </div>
          <div style={{ gridColumn: '1 / -1', marginTop: 4 }}>
            <Checkbox checked={terms} onChange={setTerms}>
              Li e aceito os <a href="#" style={{ color: AuthColors.navy, fontWeight: 600, textDecoration: 'underline' }}>termos de uso</a> e a política de privacidade.
            </Checkbox>
          </div>
          <div style={{ gridColumn: '1 / -1', display: 'flex', gap: 12, marginTop: 8 }}>
            <AuthButton size="lg" onClick={onSubmit}>Criar conta</AuthButton>
            <AuthButton size="lg" variant="ghost" onClick={onBackToLogin}>Cancelar</AuthButton>
          </div>
        </div>
      </div>
    </div>
  );
}

function SignupWaiting({ onBackToLogin, email = 'ana.ribeiro@hospital.com.br' }) {
  return (
    <div style={{ width: '100%', height: '100%', background: '#fff', display: 'flex', flexDirection: 'column', fontFamily: 'Inter, sans-serif' }}>
      <MobileHeader title="Cadastro" />
      <div style={{ flex: 1, padding: '8px 24px 32px', display: 'flex', flexDirection: 'column', overflow: 'auto' }}>
        <div style={{
          width: 112, height: 112, borderRadius: '50%',
          background: AuthColors.successBg, border: `2px solid #C5E9D6`,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          margin: '28px auto 22px',
          position: 'relative',
        }}>
          <MsIcon name="hourglass_top" size={56} color={AuthColors.success} weight={500} />
          <div style={{
            position: 'absolute', top: -4, right: 4,
            width: 32, height: 32, borderRadius: '50%',
            background: AuthColors.lime, color: '#fff',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            border: '3px solid #fff',
            boxShadow: '0 4px 10px rgba(139,198,63,0.4)',
          }}>
            <MsIcon name="check" size={18} weight={700} />
          </div>
        </div>

        <div style={{
          fontFamily: 'Poppins, sans-serif', fontSize: 24, fontWeight: 700,
          color: AuthColors.navy, textAlign: 'center', marginBottom: 10,
          letterSpacing: '-0.02em',
        }}>
          Cadastro enviado!
        </div>
        <div style={{
          fontSize: 14, color: AuthColors.n600, textAlign: 'center',
          lineHeight: 1.55, marginBottom: 10, padding: '0 8px',
        }}>
          Seu cadastro foi enviado para aprovação. Você receberá um e-mail em
        </div>
        <div style={{
          fontFamily: 'JetBrains Mono, monospace', fontSize: 13,
          color: AuthColors.navy, textAlign: 'center', fontWeight: 600,
          marginBottom: 24,
        }}>
          {email}
        </div>

        {/* Timeline / next steps */}
        <div style={{
          background: AuthColors.n50, border: `1px solid ${AuthColors.n200}`,
          borderRadius: 14, padding: '18px 18px',
          marginBottom: 24,
        }}>
          <div style={{
            fontSize: 11, fontWeight: 700, color: AuthColors.n500,
            textTransform: 'uppercase', letterSpacing: '0.08em',
            marginBottom: 14,
          }}>Próximos passos</div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
            {[
              { icon: 'task_alt', label: 'Administrador recebeu seu pedido', done: true },
              { icon: 'mark_email_read', label: 'Você receberá e-mail quando aprovado', done: false, active: true, meta: 'Normalmente em menos de 24h' },
              { icon: 'login', label: 'Faça login e comece a usar', done: false },
            ].map((s, i, arr) => (
              <div key={i} style={{ display: 'flex', gap: 12, position: 'relative' }}>
                <div style={{ position: 'relative', flexShrink: 0 }}>
                  <div style={{
                    width: 32, height: 32, borderRadius: '50%',
                    background: s.done ? AuthColors.success : s.active ? AuthColors.lime : AuthColors.n200,
                    color: s.done || s.active ? '#fff' : AuthColors.n500,
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    boxShadow: s.active ? `0 0 0 4px ${AuthColors.lime50}` : 'none',
                  }}>
                    <MsIcon name={s.done ? 'check' : s.icon} size={16} weight={700} />
                  </div>
                  {i < arr.length - 1 && (
                    <div style={{
                      position: 'absolute', top: 32, left: '50%', transform: 'translateX(-50%)',
                      width: 2, height: 20, background: s.done ? AuthColors.success : AuthColors.n200,
                    }} />
                  )}
                </div>
                <div style={{ flex: 1, paddingTop: 5, paddingBottom: 4 }}>
                  <div style={{
                    fontSize: 14, fontWeight: s.active ? 600 : 500,
                    color: s.done ? AuthColors.navy : s.active ? AuthColors.navy : AuthColors.n600,
                  }}>
                    {s.label}
                  </div>
                  {s.meta && (
                    <div style={{ fontSize: 12, color: AuthColors.n500, marginTop: 2 }}>{s.meta}</div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        <AuthButton full size="lg" variant="secondary" icon="arrow_back" onClick={onBackToLogin}>
          Voltar ao login
        </AuthButton>
        <div style={{ textAlign: 'center', fontSize: 12, color: AuthColors.n500, marginTop: 14 }}>
          Recebeu por engano? <a href="#" style={{ color: AuthColors.navy, fontWeight: 600 }}>Cancelar cadastro</a>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { SignupFormMobile, SignupFormDesktop, SignupWaiting });
